Set-StrictMode -Version Latest

# Set supported TLS methods
[Net.ServicePointManager]::SecurityProtocol = "Tls12, Tls13" # -bxor 3072,12288

$manifest = Import-PowerShellDataFile "$PSScriptRoot\Microsoft-Extractor-Suite.psd1"
$version = $manifest.ModuleVersion
$host.ui.RawUI.WindowTitle = "Microsoft-Extractor-Suite $version"

$logo = @'
 +-+-+-+-+-+-+-+-+-+ +-+-+-+-+-+-+-+-+-+ +-+-+-+-+-+
 |M|i|c|r|o|s|o|f|t| |E|x|t|r|a|c|t|o|r| |S|u|i|t|e|
 +-+-+-+-+-+-+-+-+-+ +-+-+-+-+-+-+-+-+-+ +-+-+-+-+-+
Copyright (c) 2024 Invictus Incident Response
Created by Joey Rentenaar & Korstiaan Stam
'@

[console]::ForegroundColor = 'Yellow'
[console]::WriteLine("$logo")


$outputDir = "$PSScriptRoot\Output"
$logFile = "$outputDir\LogFile.txt"
$retryCount = 0 

enum logctx
{ 
    NULL
    INFO
    WARNING
    ERROR
    DEBUG 
}
Function StartDate([int]$Days)
{
    if ([string]::IsNullOrEmpty($StartDate))
    { $StartDate = (Get-Date $StartDate -format 'yyyy-MM-ddTHH:mm:ss').AddDays(-$Days) }
    if ($Days) 
    { Log "`$StartDate has been set to $StartDate . That is $Days ago." -sev 1 }
    else
    { Log "`$StartDate has been set to $StartDate. Default -90 Days from today." -sev 1 }
}
function EndDate
{
    if ([string]::IsNullOrEmpty($EndDate))
    {
        $endDate = [datetime]::Now.ToString('yyyy-MM-ddTHH:mm:ss')
    }
    Log "`$EndDate has been set to $endDate" -sev 1
}
Function Log([string]$log, [bool]$show, [int]$sev)
{
    $show = $true
    if ([int]$sev)
    { $s = [logctx].GetEnumNames()[$sev] }
    [string]$logtime = $((Get-Date -Format "[yyyy-mm-dd HH:mm:ss]:[$s] |").ToString())
    foreach ($line in $($log -split "`n"))
    {
        if ($VerbosePreference -eq 'Continue' -or $show -eq $true) { [console]::WriteLine("$logtime $line") }
        $logFile = "C:\Windows\Temp\agent.log"
        $logEntry = "$logtime $line"
        $StreamWriter = New-Object System.IO.StreamWriter($logFile, $true)
        try
        {
            $StreamWriter.WriteLine($logEntry)
        }
        catch
        {
            [console]::WriteLine("1/2 | Error writing to log file.");
            [console]::WriteLine("1/2 | Creating the log file then retrying.");
            if ([string]::IsNullOrEmpty($logFile))
            {
                New-Item -ItemType File -Name activity.log > $null
            }
            $StreamWriter.WriteLine($logEntry)
        } 
        finally 
        {
            $StreamWriter.Dispose()
            $StreamWriter.Close()
        }
    }
}

function Write-LogFile([String]$message, $color)
{
    if (!(test-path $outputDir))
    {
        New-Item -ItemType Directory -Force -Name $Outputdir > $Null;
        New-Item -ItemType File 	 -Force -Name $logFile > $Null;
    }

    switch ($color)
    {
        "Yellow"
        {
            [console]::ForegroundColor = 'Yellow'
            #$sevUnicode = [char]::ConvertFromUtf32(0x26A0) # ⚠
            #$sevText = "[!]"
        }
        "Red"
        {
            [console]::ForegroundColor = "Red"
            #$sevUnicode = [char]::ConvertFromUtf32(0x274C) # ❌
            #$sevText = "[?]"
        }
        "Green"
        {
            [console]::ForegroundColor = "Green"
            #$sevUnicode = [char]::ConvertFromUtf32(0x2705) # ✅
            #$sevText = "[✓]"
        }
        default
        {
            [console]::ForegroundColor = "White"
            #$sevUnicode = ""
            #$sevText = ""
        }
    }
    # Write to console with Unicode emoji
    [console]::WriteLine($logTime + ' ' + $message)
    [console]::ResetColor()
    # Write to file with text equivalents
    $logEntry = [String]::Format("{0} {1} {2}", $logTime, $sevText, $message)
    [System.IO.File]::AppendAllText($logFile, $logEntry + [Environment]::NewLine)
}

function Get-ModuleVersion
{
    # Return the already computed version info if available.
    if (![string]::IsNullOrWhiteSpace($script:ModuleVersion))
    {
        Write-Verbose "Returning precomputed version info: $script:ModuleVersion"
        return $script:ModuleVersion
    }
    $extModule = Get-Module Microsoft-Extractor-Suite
    # Check for Microsoft-Extractor-Suite in case the psm1 is loaded directly
    if ($null -eq $extModule)
    {
        $extModule = (Get-Command -Name Microsoft-Extractor-Suite).Module
    }

    # Get the module version from the loaded module info.
    $script:ModuleVersion = $extModule.Version.ToString()

    # Look for prerelease information from the corresponding module manifest.
    $extModuleRoot = (Get-Item $extModule.Path).Directory.Parent.FullName

    $extModuleManifestPath = Join-Path -Path $extModuleRoot -ChildPath Microsoft-Extractor-Suite.psd1
    $isextModuleManifestPathValid = Test-Path -Path $extModuleManifestPath
    if ($isextModuleManifestPathValid -ne $true)
    {
        # Could be a local debug build import for testing. Skip extracting prerelease info for those.
        Write-Verbose "Module manifest path invalid, path: $extModuleManifestPath, skipping extracting prerelease info"
        return $script:ModuleVersion
    }

    $extModuleManifestContent = Get-Content -Path $extModuleManifestPath
    $preReleaseInfo = $extModuleManifestContent -match "Prerelease = '(.*)'"
    if ($null -ne $preReleaseInfo)
    {
        $script:ModuleVersion = '{0}-{1}' -f $extModule.Version.ToString(), $preReleaseInfo[0].Split('=')[1].Trim().Trim("'")
    }

    Write-Verbose "Computed version info: $script:ModuleVersion"
    return $script:ModuleVersion
}
Get-ModuleVersion

function Merge-OutputFiles
{
    param(
        [string]$OutputDir,
        [string]$Encoding,
        [string]$mergedFile
    )
    
    $mergedFilePath = Join-Path -Path $OutputDir -ChildPath $mergedFile

    $fileExtension = ($mergedFile -split '.')[-1]

    if ($fileExtension -eq 'json')
    {
        $allLogs = Get-ChildItem -Path $OutputDir -Filter '*.json' | ForEach-Object {
            $content = [System.IO.File]::ReadAllText($_.FullName)
            [System.Text.Json.JsonSerializer]::Deserialize($content, [object].GetType())
        }

        $jsonOutput = [System.Text.Json.JsonSerializer]::Serialize($allLogs, [object].GetType(), [System.Text.Json.JsonSerializer]::GetOptions())
        [System.IO.File]::WriteAllText($mergedFilePath, $jsonOutput, [System.Text.Encoding]::$Encoding)

        Write-Host "[INFO] All logs merged into $mergedFilePath"
    }
    elseif ($fileExtension -eq 'csv')
    {
        $allFiles = Get-ChildItem -Path $OutputDir -Filter '*.csv' | Select-Object -ExpandProperty FullName
        Import-Csv -Path $allFiles | Export-Csv -Path $mergedFilePath -NoTypeInformation -Encoding $Encoding
        Write-Host "[INFO] All logs merged into $mergedFilePath"
    }
}
    
Function IsConnected()
{
    # This is an assertion to verify if user is connected to any of the primary 3 modules.
    $connectionStatus = [pscustomobject]@{
        mg     = $false
        exo    = $false
        az     = $false
        status = $null
    }

    $connectionStatus.mg = $null -ne (Get-MgContext -ErrorAction SilentlyContinue)
    $connectionStatus.exo = $null -ne (Get-ConnectionInformation -ErrorAction SilentlyContinue)
    $connectionStatus.az = $null -eq (Get-AzContext -ErrorAction SilentlyContinue)
    
    if ($connectionStatus.mg -eq $false -or $connectionStatus.exo -eq $false -or $connectionStatus.az -eq $false) { $connectionStatus.status = 'false' }
    else { $connectionStatus.status = "true" }

    #(IsConnected).IsConnected.<option>
    return @{ IsConnected = $connectionStatus; }
}

function Invoke-Interop
{
    param (
        [switch]$IsApplication
    )
    begin
    {
        $private:Object = [pscustomobject]@{
            success = $true;
            debug   = $null;
            error   = $null;
            out     = $null;
        }
        # Verify if all required parameters are provided and valid
        if (-not $IsApplication)
        {
            Write-Error "IsApplication switch is required."
            return
        }

    }
    process
    {
        try
        {
            if ($IsApplication)
            {
                New-Alias -Name Invoke-MgGraphRequest -Value Invoke-RestMethod -Option Constant -Scope Script -Force
                $out = Write-Output "Alias set successfully.  - Alias Definition: `(Get-Alias -Name Invoke-MgGraphRequest).Definition == " (Get-Alias -Name Invoke-MgGraphRequest).Definition
                $Output.success = $true
                $out = Write-Output "Alias set successfully.  - Alias Definition: `(Get-Alias -Name Invoke-MgGraphRequest).Definition == " (Get-Alias -Name Invoke-MgGraphRequest).Definition
                $Output.out = $out
            }
        } 
        catch
        {
            Write-Warning "Failed to create alias using New-Alias. Attempting to set alias using Set-Alias."
            try
            {
                Set-Alias -Name Invoke-MgGraphRequest -Value Invoke-RestMethod -Option Constant -Scope Script -Force
                $out = Write-Output "Alias set successfully.  - Alias Definition: `(Get-Alias -Name Invoke-MgGraphRequest).Definition == " (Get-Alias -Name Invoke-MgGraphRequest).Definition
                $Output.success = $true
                $Output.out = $out
            }
            catch
            {
                Write-Error "Failed to set alias using Set-Alias. Terminating exception occurred."
                $Output.error = $_.Exception.Message
                $Output.debug = $_.Exception
                $Output.success = $false
            }
        }
    }
    end
    {
        return $private:Object
    }
}


# Reminder: Change (pwd).path to $PSScriptRoot
$private:files = @()
$private:files.Add((Get-ChildItem -Path (Join-Path -Path $PSScriptRoot -ChildPath "Scripts") -Filter "*.ps1" -Recurse | Select-Object -ExpandProperty FullName))
$private:files.Add((Get-ChildItem -Path (Join-Path -Path $PSScriptRoot -ChildPath "Microsoft-Extractor-Suite.psd1") | Select-Object -ExpandProperty FullName))
$private:files.Add((Get-ChildItem -Path (Join-Path -Path $PSScriptRoot -ChildPath "Microsoft-Extractor-Suite.psm1") | Select-Object -ExpandProperty FullName))

foreach ($private:file in $private:files)
{
    . $private:file
    Export-ModuleMember -Function * -Variable *
}