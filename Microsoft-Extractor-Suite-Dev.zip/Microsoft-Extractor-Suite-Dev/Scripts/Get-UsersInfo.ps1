<#
    The delegated and application variations of the functions are seperate for the moment as I am too lazy for these functions. 
    It is not hard. 
    <inspirational quote>
#>

#region Delegated
function Get-Users
{
    <#
    .SYNOPSIS
        Retrieves the creation time and date of the last password change for all users.
    .DESCRIPTION
        Retrieves the creation time and date of the last password change for all users.
        The output will be written to: Output\UserInfo\

    .PARAMETER OutputDir
        OutputDir is the parameter specifying the output directory.
        Default: Output\UserInfo
    .PARAMETER Encoding
        Encoding is the parameter specifying the encoding of the CSV output file.
        Default: UTF8
    .PARAMETER Application
        Application is the parameter specifying App-only access (access without a user) for authentication and authorization.
        Default: Delegated access (access on behalf a user)
    .EXAMPLE
        Get-Users
        Retrieves the creation time and date of the last password change for all users.
    .EXAMPLE
        Get-Users -Application
        Retrieves the creation time and date of the last password change for all users via application authentication.
    .EXAMPLE
        Get-Users -Encoding utf32
        Retrieves the creation time and date of the last password change for all users and exports the output to a CSV file with UTF-32 encoding.
    .EXAMPLE
        Get-Users -OutputDir C:\Windows\Temp
        Retrieves the creation time and date of the last password change for all users and saves the output to the C:\Windows\Temp folder.
    #>
    [CmdletBinding()]
    param (
        [string]$OutputDir = "Output\UserInfo",
        [string]$Encoding = "UTF8",
        [switch]$Application,
        [int]$MaxRetries = 3
    )

    begin
    {
        # Validate parameters
        if ([string]::IsNullOrWhiteSpace($OutputDir))
        {
            $OutputDir = "Output\UserInfo"
        }
        if ([string]::IsNullOrWhiteSpace($Encoding))
        {
            $Encoding = "UTF8"
        }
        if ($MaxRetries -le 0)
        {
            throw "MaxRetries must be greater than 0."
        }

        # Ensure the output directory exists
        if (-not (Test-Path -Path $OutputDir))
        {
            New-Item -ItemType Directory -Force -Path $OutputDir | Out-Null
        }

        Write-LogFile -Message "[INFO] Running Get-Users" -Color "Green"

        $selectobjects = "Id", "AccountEnabled", "DisplayName", "UserPrincipalName", "Mail", "CreatedDateTime", "LastPasswordChangeDateTime", "DeletedDateTime", "JobTitle", "Department", "OfficeLocation", "City", "State", "Country"
    }

    process
    {
        $retryCount = 0
        $success = $false

        while (-not $success -and $retryCount -lt $MaxRetries)
        {
            try
            {
                $mgUsers = Get-MgUser -All -Select $selectobjects
                Write-LogFile -Message "[INFO] Successfully retrieved user data." -Color "Green"
                $success = $true
            }
            catch
            {
                $retryCount++
                $delay = [math]::Pow(2, $retryCount)
                Write-Warning "Error retrieving user data. Attempt $retryCount of $MaxRetries. Retrying in $delay seconds..."
                Start-Sleep -Seconds $delay
            }
        }

        if (-not $success)
        {
            Write-Error "Failed to retrieve user data after $MaxRetries attempts." -ForegroundColor Red
        }
        else
        {
            $date = Get-Date -Format "yyyyMMddHHmm"
            $filePath = "$OutputDir\Users_$date.csv"
            $mgUsers | Select-Object $selectobjects | Export-Csv -Path $filePath -NoTypeInformation -Encoding $Encoding
            Write-LogFile -Message "[INFO] Output written to $filePath" -Color "Green"
        }
    }

    end
    {
        Write-Host '[INFO] Process completed.' -ForegroundColor Green
    }
}

function Get-AdminUsers
{
    <#
    .SYNOPSIS
        Retrieves all Administrator directory roles.
    .DESCRIPTION
        Retrieves Administrator directory roles, including the identification of users associated with each specific role.
        The output will be written to: Output\UserInfo\
    .PARAMETER OutputDir
        OutputDir is the parameter specifying the output directory.
        Default: Output\UserInfo
    .PARAMETER Encoding
        Encoding is the parameter specifying the encoding of the CSV output file.
        Default: UTF8
    .PARAMETER Application
        Application is the parameter specifying App-only access (access without a user) for authentication and authorization.
        Default: Delegated access (access on behalf a user)
    .EXAMPLE
        Get-AdminUsers
        Retrieves Administrator directory roles, including the identification of users associated with each specific role.
    .EXAMPLE
        Get-AdminUsers -Application
        Retrieves Administrator directory roles, including the identification of users associated with each specific role via application authentication.
    .EXAMPLE
        Get-AdminUsers -Encoding utf32
        Retrieves Administrator directory roles, including the identification of users associated with each specific role and exports the output to a CSV file with UTF-32 encoding.
    .EXAMPLE
        Get-AdminUsers -OutputDir C:\Windows\Temp
        Retrieves Administrator directory roles, including the identification of users associated with each specific role and saves the output to the C:\Windows\Temp folder.
    #>
    [CmdletBinding()]
    param (
        [string]$OutputDir = "Output\UserInfo",
        [string]$Encoding = "UTF8",
        [switch]$Application,
        [int]$MaxRetries = 3
    )

    begin
    {
        # Validate parameters
        if ([string]::IsNullOrWhiteSpace($OutputDir))
        {
            $OutputDir = "Output\UserInfo"
        }
        if ([string]::IsNullOrWhiteSpace($Encoding))
        {
            $Encoding = "UTF8"
        }
        if ($MaxRetries -le 0)
        {
            throw "MaxRetries must be greater than 0."
        }

        # Ensure the output directory exists
        if (-not (Test-Path -Path $OutputDir))
        {
            New-Item -ItemType Directory -Force -Path $OutputDir | Out-Null
        }

        Write-LogFile -Message "[INFO] Running Get-AdminUsers" -Color "Green"
    }

    process
    {
        $retryCount = 0
        $success = $false

        while (-not $success -and $retryCount -lt $MaxRetries)
        {
            try
            {
                $getRoles = Get-MgDirectoryRole -All
                Write-LogFile -Message "[INFO] Successfully retrieved directory roles." -Color "Green"
                $success = $true
            }
            catch
            {
                $retryCount++
                $delay = [math]::Pow(2, $retryCount)
                Write-Warning "Error retrieving directory roles. Attempt $retryCount of $MaxRetries. Retrying in $delay seconds..."
                Start-Sleep -Seconds $delay
            }
        }

        if (-not $success)
        {
            Write-Error "Failed to retrieve directory roles after $MaxRetries attempts." -ForegroundColor Red
        }
        else
        {
            foreach ($role in $getRoles)
            {
                $roleId = $role.Id
                $roleName = $role.DisplayName

                if ($roleName -like "*Admin*")
                {
                    $retryCount = 0
                    $success = $false

                    while (-not $success -and $retryCount -lt $MaxRetries)
                    {
                        try
                        {
                            $areThereUsers = Get-MgDirectoryRoleMember -DirectoryRoleId $roleId
                            Write-LogFile -Message "[INFO] Successfully retrieved users for role $roleName." -Color "Green"
                            $success = $true
                        }
                        catch
                        {
                            $retryCount++
                            $delay = [math]::Pow(2, $retryCount)
                            Write-Warning "Error retrieving users for role $roleName. Attempt $retryCount of $MaxRetries. Retrying in $delay seconds..."
                            Start-Sleep -Seconds $delay
                        }
                    }

                    if (-not $success)
                    {
                        Write-Error "Failed to retrieve users for role $roleName after $MaxRetries attempts." -ForegroundColor Red
                    }
                    else
                    {
                        if ($null -eq $areThereUsers)
                        {
                            Write-LogFile -Message "[INFO] $roleName - No users found" -Color "Green"
                        }
                        else
                        {
                            $results = @()
                            $areThereUsers | ForEach-Object {
                                $userid = $_.Id
                                try
                                {
                                    $getUserName = Get-MgUser -Filter ("Id eq '$userid'")
                                    $userName = $getUserName.UserPrincipalName

                                    $myObject = [PSCustomObject]@{
                                        UserName = $userName
                                        UserId   = $userid
                                        Role     = $roleName
                                    }

                                    $results += $myObject
                                }
                                catch
                                {
                                    Write-LogFile -Message "[INFO] Resource $userid does not exist or one of its queried reference-property objects are not present." -Color "Yellow"
                                }
                            }

                            $date = Get-Date -Format "yyyyMMddHHmm"
                            $filePath = "$OutputDir\$date-$roleName.csv"
                            $results | Export-Csv -Path $filePath -NoTypeInformation -Encoding $Encoding
                            Write-LogFile -Message "[INFO] Output written to $filePath" -Color "Green"
                        }
                    }
                }
            }
        }
    }

    end
    {
        if ($MergeOutput)
        {
            Write-Host "[INFO] Merging output files into one file" -ForegroundColor Green
            $mergedFilePath = "$OutputDir\Merged\All-Administrators.csv"
            $allFiles = Get-ChildItem -Path $OutputDir -Filter "*.csv" | Select-Object -ExpandProperty FullName
            Import-Csv -Path $allFiles | Export-Csv -Path $mergedFilePath -NoTypeInformation -Encoding $Encoding
            Write-LogFile -Message "[INFO] All logs merged into $mergedFilePath" -Color "Green"
        }

        Write-Host '[INFO] Process completed.' -ForegroundColor Green
    }
}
#endregion Delegated

#region Application
function _Get-Users
{
    <#
    .SYNOPSIS
        Retrieves the creation time and date of the last password change for all users via API calls.
    .DESCRIPTION
        Retrieves the creation time and date of the last password change for all users.
        The output will be written to: Output\UserInfo\

    .PARAMETER OutputDir
        OutputDir is the parameter specifying the output directory.
        Default: Output\UserInfo
    .PARAMETER Encoding
        Encoding is the parameter specifying the encoding of the CSV output file.
        Default: UTF8
    .PARAMETER Token
        Token is the parameter specifying the API token for authentication.
    .PARAMETER MaxRetries
        Specifies the maximum number of retries for failed requests. Default: 3.
    .EXAMPLE
        Get-Users -Token $token
        Retrieves the creation time and date of the last password change for all users.
    .EXAMPLE
        Get-Users -Token $token -Encoding utf32
        Retrieves the creation time and date of the last password change for all users and exports the output to a CSV file with UTF-32 encoding.
    .EXAMPLE
        Get-Users -Token $token -OutputDir C:\Windows\Temp
        Retrieves the creation time and date of the last password change for all users and saves the output to the C:\Windows\Temp folder.
    #>
    [CmdletBinding()]
    param (
        [string]$OutputDir = "Output\UserInfo",
        [string]$Encoding = "UTF8",
        [Parameter(Mandatory = $true)][string]$Token,
        [int]$MaxRetries = 3
    )

    begin
    {
        # Validate parameters
        if ([string]::IsNullOrWhiteSpace($OutputDir))
        {
            $OutputDir = "Output\UserInfo"
        }
        if ([string]::IsNullOrWhiteSpace($Encoding))
        {
            $Encoding = "UTF8"
        }
        if ($MaxRetries -le 0)
        {
            throw "MaxRetries must be greater than 0."
        }

        # Ensure the output directory exists
        if (-not (Test-Path -Path $OutputDir))
        {
            New-Item -ItemType Directory -Force -Path $OutputDir | Out-Null
        }

        Write-LogFile -Message "[INFO] Running Get-Users" -Color "Green"

        $selectObjects = "id,displayName,userPrincipalName,onPremisesSamAccountName,mobilePhone,assignedLicenses,accountEnabled,createdDateTime,lastPasswordChangeDateTime,deletedDateTime,jobTitle,department,officeLocation,city,state,country"
        $url = "https://graph.microsoft.com/beta/users?`$select=$selectObjects"
    }

    process
    {
        $retryCount = 0
        $success = $false
        $pageNo = 1
        $allResults = @()

        while (-not $success -and $retryCount -lt $MaxRetries)
        {
            try
            {
                do
                {
                    Write-Host "Retrieving Page $pageNo of Users"
                    $results = Invoke-RestMethod -Uri $url -Headers @{Authorization = "Bearer $Token"; ConsistencyLevel = "eventual" } -Method Get

                    foreach ($result in $results.value)
                    {
                        $allResults += $result
                    }

                    if ($results."@odata.nextLink" -ne $null)
                    {
                        $url = $results."@odata.nextLink"
                        $pageNo++
                    }
                    else
                    {
                        $url = $null
                    }
                } while ($url -ne $null)

                Write-LogFile -Message "[INFO] Successfully retrieved user data." -Color "Green"
                $success = $true
            }
            catch
            {
                $retryCount++
                $delay = [math]::Pow(2, $retryCount)
                Write-Warning "Error retrieving user data. Attempt $retryCount of $MaxRetries. Retrying in $delay seconds..."
                Start-Sleep -Seconds $delay
            }
        }

        if (-not $success)
        {
            Write-Error "Failed to retrieve user data after $MaxRetries attempts." -ForegroundColor Red
        }
        else
        {
            $date = Get-Date -Format "yyyyMMddHHmm"
            $filePath = "$OutputDir\Users_$date.csv"
            $allResults | Export-Csv -Path $filePath -NoTypeInformation -Encoding $Encoding
            Write-LogFile -Message "[INFO] Output written to $filePath" -Color "Green"
        }
    }

    end
    {
        Write-Host '[INFO] Process completed.' -ForegroundColor Green
    }
}
function _Get-AdminUsers
{
    <#
    .SYNOPSIS
        Retrieves all Administrator directory roles via API calls.
    .DESCRIPTION
        Retrieves Administrator directory roles, including the identification of users associated with each specific role.
        The output will be written to: Output\UserInfo\
    .PARAMETER OutputDir
        OutputDir is the parameter specifying the output directory.
        Default: Output\UserInfo
    .PARAMETER Encoding
        Encoding is the parameter specifying the encoding of the CSV output file.
        Default: UTF8
    .PARAMETER Token
        Token is the parameter specifying the API token for authentication.
    .PARAMETER MaxRetries
        Specifies the maximum number of retries for failed requests. Default: 3.
    .EXAMPLE
        Get-AdminUsers -Token $token
        Retrieves Administrator directory roles, including the identification of users associated with each specific role.
    .EXAMPLE
        Get-AdminUsers -Token $token -Encoding utf32
        Retrieves Administrator directory roles, including the identification of users associated with each specific role and exports the output to a CSV file with UTF-32 encoding.
    .EXAMPLE
        Get-AdminUsers -Token $token -OutputDir C:\Windows\Temp
        Retrieves Administrator directory roles, including the identification of users associated with each specific role and saves the output to the C:\Windows\Temp folder.
    #>
    [CmdletBinding()]
    param (
        [string]$OutputDir = "Output\UserInfo",
        [string]$Encoding = "UTF8",
        [Parameter(Mandatory = $true)][string]$Token,
        [int]$MaxRetries = 3
    )

    begin
    {
        # Validate parameters
        if ([string]::IsNullOrWhiteSpace($OutputDir))
        {
            $OutputDir = "Output\UserInfo"
        }
        if ([string]::IsNullOrWhiteSpace($Encoding))
        {
            $Encoding = "UTF8"
        }
        if ($MaxRetries -le 0)
        {
            throw "MaxRetries must be greater than 0."
        }

        # Ensure the output directory exists
        if (-not (Test-Path -Path $OutputDir))
        {
            New-Item -ItemType Directory -Force -Path $OutputDir | Out-Null
        }

        Write-LogFile -Message "[INFO] Running Get-AdminUsers" -Color "Green"
        $rolesUrl = "https://graph.microsoft.com/beta/directoryRoles"
    }

    process
    {
        $retryCount = 0
        $success = $false

        while (-not $success -and $retryCount -lt $MaxRetries)
        {
            try
            {
                $roles = Invoke-RestMethod -Uri $rolesUrl -Headers @{Authorization = "Bearer $Token"; ConsistencyLevel = "eventual" } -Method Get
                Write-LogFile -Message "[INFO] Successfully retrieved directory roles." -Color "Green"
                $success = $true
            }
            catch
            {
                $retryCount++
                $delay = [math]::Pow(2, $retryCount)
                Write-Warning "Error retrieving directory roles. Attempt $retryCount of $MaxRetries. Retrying in $delay seconds..."
                Start-Sleep -Seconds $delay
            }
        }

        if (-not $success)
        {
            Write-Error "Failed to retrieve directory roles after $MaxRetries attempts." -ForegroundColor Red
        }
        else
        {
            foreach ($role in $roles.value)
            {
                $roleId = $role.id
                $roleName = $role.displayName

                if ($roleName -like "*Admin*")
                {
                    $retryCount = 0
                    $success = $false
                    $usersUrl = "https://graph.microsoft.com/beta/directoryRoles/$roleId/members"

                    while (-not $success -and $retryCount -lt $MaxRetries)
                    {
                        try
                        {
                            $users = Invoke-RestMethod -Uri $usersUrl -Headers @{Authorization = "Bearer $Token"; ConsistencyLevel = "eventual" } -Method Get
                            Write-LogFile -Message "[INFO] Successfully retrieved users for role $roleName." -Color "Green"
                            $success = $true
                        }
                        catch
                        {
                            $retryCount++
                            $delay = [math]::Pow(2, $retryCount)
                            Write-Warning "Error retrieving users for role $roleName. Attempt $retryCount of $MaxRetries. Retrying in $delay seconds..."
                            Start-Sleep -Seconds $delay
                        }
                    }

                    if (-not $success)
                    {
                        Write-Error "Failed to retrieve users for role $roleName after $MaxRetries attempts." -ForegroundColor Red
                    }
                    else
                    {
                        if ($null -eq $users.value)
                        {
                            Write-LogFile -Message "[INFO] $roleName - No users found" -Color "Green"
                        }
                        else
                        {
                            $results = @()
                            foreach ($user in $users.value)
                            {
                                $retryCount = 0
                                $success = $false
                                $userUrl = "https://graph.microsoft.com/beta/users/$($user.id)?`$select=userPrincipalName,id"

                                while (-not $success -and $retryCount -lt $MaxRetries)
                                {
                                    try
                                    {
                                        $userInfo = Invoke-RestMethod -Uri $userUrl -Headers @{Authorization = "Bearer $Token"; ConsistencyLevel = "eventual" } -Method Get
                                        $results += [PSCustomObject]@{
                                            UserName = $userInfo.userPrincipalName
                                            UserId   = $userInfo.id
                                            Role     = $roleName
                                        }
                                        $success = $true
                                    }
                                    catch
                                    {
                                        $retryCount++
                                        $delay = [math]::Pow(2, $retryCount)
                                        Write-Warning "Error retrieving user info for $($user.id). Attempt $retryCount of $MaxRetries. Retrying in $delay seconds..."
                                        Start-Sleep -Seconds $delay
                                    }
                                }
                            }

                            $date = Get-Date -Format "yyyyMMddHHmm"
                            $filePath = "$OutputDir\$date-$roleName.csv"
                            $results | Export-Csv -Path $filePath -NoTypeInformation -Encoding $Encoding
                            Write-LogFile -Message "[INFO] Output written to $filePath" -Color "Green"
                        }
                    }
                }
            }
        }
    }

    end
    {
        Write-Host '[INFO] Process completed.' -ForegroundColor Green
    }
}
#endregion Application