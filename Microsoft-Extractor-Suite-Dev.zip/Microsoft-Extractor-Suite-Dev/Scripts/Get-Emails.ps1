function Get-Email {
    <#
        .SYNOPSIS
        Get a specific email.
    
        .DESCRIPTION
        Get a specific email based on userId and Internet Message Id and saves the output to a msg or txt file.
    
        .PARAMETER OutputDir
        OutputDir is the parameter specifying the output directory.
        Default: Output\EmailExport
    
        .PARAMETER UserIds
        The unique identifier of the user.
    
        .PARAMETER internetMessageId
        The InternetMessageId parameter represents the Internet message identifier of an item.
    
        .PARAMETER output
        Output is the parameter specifying the msg or txt output type.
        Default: msg
    
        .PARAMETER attachment
        The attachment parameter specifies whether the attachment should be saved or not. 
        Default: False 
        
        .EXAMPLE
        Get-Email -userIds fortunahodan@bonacu.onmicrosoft.com -internetMessageId "<d6f15b97-e3e3-4871-adb2-e8d999d51f34@az.westeurope.microsoft.com>" 
        Retrieves an email from fortunahodan@bonacu.onmicrosoft.com with the internet message identifier <d6f15b97-e3e3-4871-adb2-e8d999d51f34@az.westeurope.microsoft.com> to a msg file.
        
        .EXAMPLE
        Get-Email -userIds fortunahodan@bonacu.onmicrosoft.com -internetMessageId "<d6f15b97-e3e3-4871-adb2-e8d999d51f34@az.westeurope.microsoft.com>" -attachment True
        Retrieves an email and the attachment from fortunahodan@bonacu.onmicrosoft.com with the internet message identifier <d6f15b97-e3e3-4871-adb2-e8d999d51f34@az.westeurope.microsoft.com> to a msg file.
            
        .EXAMPLE
        Get-Email -userIds fortunahodan@bonacu.onmicrosoft.com -internetMessageId "<d6f15b97-e3e3-4871-adb2-e8d999d51f34@az.westeurope.microsoft.com>" -OutputDir C:\Windows\Temp
        Retrieves an email and saves it to C:\Windows\Temp folder.
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]$userIds,
        [Parameter(Mandatory = $true)]$internetMessageId,
        [string]$output = 'msg',
        [string]$outputDir = 'Output\EmailExport',
        [switch]$attachment,
        [int]$MaxRetries = 3
    )
    
    begin {
        if (-not (Test-Path -Path $outputDir)) {
            Write-LogFile -Message "[INFO] Creating the directory: $outputDir" -Color 'Green'
            New-Item -ItemType Directory -Force -Path $outputDir | Out-Null
        }
    
        Write-LogFile -Message '[INFO] Starting Get-Email' -Color 'Green'
    
        if (-not (Get-MgContext)) {
            Connect-MgGraph -Scopes 'Mail.Read', 'Mail.ReadBasic', 'Mail.ReadBasic.All' -NoWelcome
        }
    }
    
    process {
        $retryCount = 0
        $success = $false
    
        while (-not $success -and $retryCount -lt $MaxRetries) {
            try {
                $getMessage = Get-MgUserMessage -UserId $userIds -Filter "internetMessageId eq '$internetMessageId'" -ErrorAction Stop
                $messageId = $getMessage.Id
                $subject = $getMessage.Subject -replace '[\\/:*?"<>|]', '_'
                $ReceivedDateTime = $getMessage.ReceivedDateTime.ToString('yyyyMMdd_HHmmss')
                $filePath = "$outputDir\$ReceivedDateTime-$subject.$output"
    
                Get-MgUserMessageContent -MessageId $messageId -UserId $userIds -OutFile $filePath
                Write-LogFile -Message "[INFO] Output written to $filePath" -Color 'Green'
    
                if ($attachment) {
                    Get-Attachment -userIds $userIds -internetMessageId $internetMessageId -outputDir $outputDir
                }
                    
                $success = $true
            } catch {
                $retryCount++
                $delay = [math]::Pow(2, $retryCount)
                Write-LogFile -Message "[WARNING] Error fetching data: $_. Attempt $retryCount of $MaxRetries. Retrying in $delay seconds..." -Color 'Yellow'
                Start-Sleep -Seconds $delay
            }
        }
    
        if (-not $success) {
            Write-LogFile -Message "[ERROR] Failed to retrieve email after $MaxRetries attempts." -Color 'Red'
        }
    }
}
    
function Get-Attachment {
    <#
        .SYNOPSIS
        Get a specific attachment.
    
        .DESCRIPTION
        Get a specific attachment based on userId and Internet Message Id and saves the output.
    
        .PARAMETER OutputDir
        OutputDir is the parameter specifying the output directory.
        Default: Output\Emails
    
        .PARAMETER UserIds
        The unique identifier of the user.
    
        .PARAMETER internetMessageId
        The InternetMessageId parameter represents the Internet message identifier of an item.
    
        .EXAMPLE
        Get-Attachment -userIds fortunahodan@bonacu.onmicrosoft.com -internetMessageId "<d6f15b97-e3e3-4871-adb2-e8d999d51f34@az.westeurope.microsoft.com>" 
        Retrieves the attachment from fortunahodan@bonacu.onmicrosoft.com with the internet message identifier <d6f15b97-e3e3-4871-adb2-e8d999d51f34@az.westeurope.microsoft.com>.
        
        .EXAMPLE
        Get-Attachment -userIds fortunahodan@bonacu.onmicrosoft.com -internetMessageId "<d6f15b97-e3e3-4871-adb2-e8d999d51f34@az.westeurope.microsoft.com>" -OutputDir C:\Windows\Temp
        Retrieves an attachment and saves it to C:\Windows\Temp folder.
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]$userIds,
        [Parameter(Mandatory = $true)]$internetMessageId,
        [string]$outputDir = 'Output\EmailExport',
        [int]$MaxRetries = 3
    )
    
    begin {
        if (-not (Test-Path -Path $outputDir)) {
            Write-LogFile -Message "[INFO] Creating the directory: $outputDir" -Color 'Green'
            New-Item -ItemType Directory -Force -Path $outputDir | Out-Null
        }
    
        Write-LogFile -Message '[INFO] Starting Get-Attachment' -Color 'Green'
    
        if (-not (Get-MgContext)) {
            Connect-MgGraph -Scopes 'Mail.Read', 'Mail.ReadBasic', 'Mail.ReadBasic.All' -NoWelcome
        }
    }
    
    process {
        $retryCount = 0
        $success = $false
    
        while (-not $success -and $retryCount -lt $MaxRetries) {
            try {
                $getMessage = Get-MgUserMessage -Filter "internetMessageId eq '$internetMessageId'" -UserId $userIds -ErrorAction Stop
                $messageId = $getMessage.Id
                $hasAttachment = $getMessage.HasAttachments
                $ReceivedDateTime = $getMessage.ReceivedDateTime.ToString('yyyyMMdd_HHmmss')
                $subject = $getMessage.Subject -replace '[\\/:*?"<>|]', '_'
    
                if ($hasAttachment) {
                    $attachment = Get-MgUserMessageAttachment -UserId $userIds -MessageId $messageId
                    $filename = $attachment.Name -replace '[\\/:*?"<>|]', '_'
                    $filePath = Join-Path -Path $outputDir -ChildPath "$ReceivedDateTime-$filename"
    
                    Write-LogFile -Message "[INFO] Downloading attachment: $filename" -Color 'Green'
    
                    $base64B = ($attachment).AdditionalProperties.contentBytes
                    $decoded = [System.Convert]::FromBase64String($base64B)
    
                    Set-Content -Path $filePath -Value $decoded -Encoding Byte
                    Write-LogFile -Message "[INFO] Attachment written to $filePath" -Color 'Green'
                } else {
                    Write-LogFile -Message "[WARNING] No attachment found for: $subject" -Color 'Yellow'
                }
    
                $success = $true
            } catch {
                $retryCount++
                $delay = [math]::Pow(2, $retryCount)
                Write-LogFile -Message "[WARNING] Error fetching data: $_. Attempt $retryCount of $MaxRetries. Retrying in $delay seconds..." -Color 'Yellow'
                Start-Sleep -Seconds $delay
            }
        }
    
        if (-not $success) {
            Write-LogFile -Message "[ERROR] Failed to retrieve attachment after $MaxRetries attempts." -Color 'Red'
        }
    }
}
    


Function Show-Email {
    <#
    .SYNOPSIS
    Show a specific email in the PowerShell Window.

    .DESCRIPTION
    Show a specific email in the PowerShell Window based on userId and Internet Message Id.

    .EXAMPLE
    Show-Email -userIds {userId} -internetMessageId {InternetMessageId}
    Show a specific email in the PowerShell Window.
	
#>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]$userIds,
        [Parameter(Mandatory = $true)]$internetMessageId
    )
    Write-logFile -Message '[INFO] Running Show-Email' -Color 'Green'

    try { 
        Get-MgUserMessage -Filter "internetMessageId eq '$internetMessageId'" -UserId $userIds | Format-List *
    } catch {
        break
    }
}