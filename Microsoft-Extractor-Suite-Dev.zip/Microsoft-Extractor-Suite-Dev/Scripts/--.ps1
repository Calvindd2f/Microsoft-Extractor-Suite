Function --
{
    param(
        [array]$variableProps,
        [array]$outputProps,
        [array]$in,
        [array]$OUTPUT
    )

    foreach ($inputLine in $input)
    {
        Write-Host $inputLine
        '$' + $inputLine + ' = "' + $inputLine + '";'
    }


    foreach ($outputVariable in $output)
    {
        $variableProps += '$' + $outputVariable + ' = $null;'
    }

    [console]::WriteLine(@"
    # read_only
    ####################################################
    ##########  INPUT
    #####################################################

    ####################################################
    ##########  OUTPUT
    #####################################################

    `$variableProps = @{
    }

    `$outputProps = @{
    out = $(New-Object psobject -Property `$variableProps);
    success = `$false;
    }

    `$activityOutput = New-Object psobject -Property `$outputProps;

    #/read_only
"@);

    [console]::WriteLine(@"
    Function VerifyActivity(){return $true}
    Function MainActivity(){$null}
    Function ExecuteActivity(){return MainActivity()}
"@);
}




<# read_only
####################################################
##########  INPUT
#####################################################

#appID		= "$appID";
#appSecret 	= "$appSecret";
#appCertThumb 	= "$appThumb";
#tenantID 	= "$tenantID";

####################################################
##########  OUTPUT
#####################################################

$variableProps = @{
     = ' ';
}

$outputProps = @{
   out = $(New-Object psobject -Property $variableProps);
   success = $false;
}

$activityOutput = New-Object psobject -Property $outputProps;

#/read_only
#>
