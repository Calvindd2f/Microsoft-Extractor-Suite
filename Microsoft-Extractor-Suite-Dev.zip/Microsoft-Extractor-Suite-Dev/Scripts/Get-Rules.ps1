<#
    All done over API calls need to introduce Invoke-MgGraphRequest Interop.
#>

function Get-TransportRules
{
	<#
    .SYNOPSIS
        Collects all transport rules in your organization via API calls.
    .DESCRIPTION
        Collects all transport rules in your organization.
        The output will be written to a CSV file called "TransportRules.csv".
    .PARAMETER OutputDir
        OutputDir is the parameter specifying the output directory.
        Default: Output\Rules
    .PARAMETER Encoding
        Encoding is the parameter specifying the encoding of the CSV output file.
        Default: UTF8
    .PARAMETER Token
        Token is the parameter specifying the API token for authentication.
    .PARAMETER MaxRetries
        Specifies the maximum number of retries for failed requests. Default: 3.
    .EXAMPLE
        Get-TransportRules -Token $token
    #>
	[CmdletBinding()]
	param (
		[string]$OutputDir = "Output\Rules",
		[string]$Encoding = "UTF8",
		[Parameter(Mandatory = $true)][string]$Token,
		[int]$MaxRetries = 3
	)

	begin
	{
		# Validate parameters
		if ([string]::IsNullOrWhiteSpace($OutputDir))
		{
			$OutputDir = "Output\Rules"
		}
		if ([string]::IsNullOrWhiteSpace($Encoding))
		{
			$Encoding = "UTF8"
		}
		if ($MaxRetries -le 0)
		{
			throw "MaxRetries must be greater than 0."
		}

		# Ensure the output directory exists
		if (-not (Test-Path -Path $OutputDir))
		{
			New-Item -ItemType Directory -Force -Path $OutputDir | Out-Null
		}

		Write-LogFile -Message "[INFO] Running Get-TransportRules" -Color "Green"

		$url = "https://graph.microsoft.com/v1.0/transportRules"
		$date = Get-Date -Format "yyyyMMddHHmm"
		$filename = "$($date)-TransportRules.csv"
		$outputDirectory = Join-Path $OutputDir $filename
	}

	process
	{
		$retryCount = 0
		$success = $false
		$allResults = @()

		while (-not $success -and $retryCount -lt $MaxRetries)
		{
			try
			{
				$results = Invoke-RestMethod -Uri $url -Headers @{Authorization = "Bearer $Token" } -Method Get
				Write-LogFile -Message "[INFO] Successfully retrieved transport rules." -Color "Green"
				$success = $true

				foreach ($result in $results.value)
				{
					$allResults += [PSCustomObject]@{
						Name        = $result.name
						Description = $result.description
						CreatedBy   = $result.createdBy
						WhenChanged = $result.whenChanged
						State       = $result.state
					}
				}
			}
			catch
			{
				$retryCount++
				$delay = [math]::Pow(2, $retryCount)
				Write-Warning "Error retrieving transport rules. Attempt $retryCount of $MaxRetries. Retrying in $delay seconds..."
				Start-Sleep -Seconds $delay
			}
		}

		if (-not $success)
		{
			Write-Error "Failed to retrieve transport rules after $MaxRetries attempts." -ForegroundColor Red
		}
		else
		{
			$allResults | Export-Csv -Path $outputDirectory -NoTypeInformation -Encoding $Encoding
			Write-LogFile -Message "[INFO] Transport rules are collected and written to: $outputDirectory" -Color "Green"
		}
	}

	end
	{
		Write-Host '[INFO] Process completed.' -ForegroundColor Green
	}
}
function Show-TransportRules
{
	<#
    .SYNOPSIS
        Shows the transport rules in your organization via API calls.
    .DESCRIPTION
        Shows the transport rules in your organization.
    .PARAMETER Token
        Token is the parameter specifying the API token for authentication.
    .PARAMETER MaxRetries
        Specifies the maximum number of retries for failed requests. Default: 3.
    .EXAMPLE
        Show-TransportRules -Token $token
    #>
	[CmdletBinding()]
	param (
		[Parameter(Mandatory = $true)][string]$Token,
		[int]$MaxRetries = 3
	)

	begin
	{
		# Validate parameters
		if ($MaxRetries -le 0)
		{
			throw "MaxRetries must be greater than 0."
		}

		Write-LogFile -Message "[INFO] Running Show-TransportRules" -Color "Green"
		$url = "https://graph.microsoft.com/v1.0/transportRules"
	}

	process
	{
		$retryCount = 0
		$success = $false

		while (-not $success -and $retryCount -lt $MaxRetries)
		{
			try
			{
				$results = Invoke-RestMethod -Uri $url -Headers @{Authorization = "Bearer $Token" } -Method Get
				Write-LogFile -Message "[INFO] Successfully retrieved transport rules." -Color "Green"
				$success = $true

				foreach ($rule in $results.value)
				{
					Write-LogFile -Message "[INFO] Found a TransportRule" -Color "Green"
					Write-LogFile -Message "Rule Name: $($rule.name)" -Color "Yellow"
					Write-LogFile -Message "Rule CreatedBy: $($rule.createdBy)" -Color "Yellow"
					Write-LogFile -Message "When Changed: $($rule.whenChanged)" -Color "Yellow"
					Write-LogFile -Message "Rule State: $($rule.state)" -Color "Yellow"
					Write-LogFile -Message "Description: $($rule.description)" -Color "Yellow"
				}
			}
			catch
			{
				$retryCount++
				$delay = [math]::Pow(2, $retryCount)
				Write-Warning "Error retrieving transport rules. Attempt $retryCount of $MaxRetries. Retrying in $delay seconds..."
				Start-Sleep -Seconds $delay
			}
		}

		if (-not $success)
		{
			Write-Error "Failed to retrieve transport rules after $MaxRetries attempts." -ForegroundColor Red
		}
	}

	end
	{
		Write-Host '[INFO] Process completed.' -ForegroundColor Green
	}
}
function Get-MailboxRules
{
	<#
    .SYNOPSIS
        Collects all the mailbox rules in your organization via API calls.
    .DESCRIPTION
        Collects all the mailbox rules in your organization.
        The output will be written to a CSV file called "InboxRules.csv".
    .PARAMETER UserIds
        UserIds is the Identity parameter specifying the Inbox rule that you want to view.
    .PARAMETER OutputDir
        OutputDir is the parameter specifying the output directory.
        Default: Output\Rules
    .PARAMETER Encoding
        Encoding is the parameter specifying the encoding of the CSV output file.
        Default: UTF8
    .PARAMETER Token
        Token is the parameter specifying the API token for authentication.
    .PARAMETER MaxRetries
        Specifies the maximum number of retries for failed requests. Default: 3.
    .EXAMPLE
        Get-MailboxRules -Token $token -UserIds Test@Invictus-ir.com
        Get-MailboxRules -Token $token -UserIds "HR@invictus-ir.com,Test@Invictus-ir.com"
    #>
	[CmdletBinding()]
	param (
		[string]$UserIds,
		[string]$OutputDir = "Output\Rules",
		[string]$Encoding = "UTF8",
		[Parameter(Mandatory = $true)][string]$Token,
		[int]$MaxRetries = 3
	)

	begin
	{
		# Validate parameters
		if ([string]::IsNullOrWhiteSpace($OutputDir))
		{
			$OutputDir = "Output\Rules"
		}
		if ([string]::IsNullOrWhiteSpace($Encoding))
		{
			$Encoding = "UTF8"
		}
		if ($MaxRetries -le 0)
		{
			throw "MaxRetries must be greater than 0."
		}

		# Ensure the output directory exists
		if (-not (Test-Path -Path $OutputDir))
		{
			New-Item -ItemType Directory -Force -Path $OutputDir | Out-Null
		}

		Write-LogFile -Message "[INFO] Running Get-MailboxRules" -Color "Green"
		$date = Get-Date -Format "yyyyMMddHHmm"
		$filename = "$($date)-MailboxRules.csv"
		$outputDirectory = Join-Path $OutputDir $filename
		$RuleList = @()
	}

	process
	{
		$retryCount = 0
		$success = $false

		if ($UserIds -eq "")
		{
			$mailboxesUrl = "https://graph.microsoft.com/v1.0/users"
			$mailboxes = @()

			while (-not $success -and $retryCount -lt $MaxRetries)
			{
				try
				{
					$mailboxes = Invoke-RestMethod -Uri $mailboxesUrl -Headers @{Authorization = "Bearer $Token" } -Method Get
					Write-LogFile -Message "[INFO] Successfully retrieved mailboxes." -Color "Green"
					$success = $true
				}
				catch
				{
					$retryCount++
					$delay = [math]::Pow(2, $retryCount)
					Write-Warning "Error retrieving mailboxes. Attempt $retryCount of $MaxRetries. Retrying in $delay seconds..."
					Start-Sleep -Seconds $delay
				}
			}

			if (-not $success)
			{
				Write-Error "Failed to retrieve mailboxes after $MaxRetries attempts." -ForegroundColor Red
			}
			else
			{
				foreach ($mailbox in $mailboxes.value)
				{
					$inboxRulesUrl = "https://graph.microsoft.com/v1.0/users/$($mailbox.id)/mailFolders/inbox/messageRules"
					$retryCount = 0
					$success = $false

					while (-not $success -and $retryCount -lt $MaxRetries)
					{
						try
						{
							$inboxRules = Invoke-RestMethod -Uri $inboxRulesUrl -Headers @{Authorization = "Bearer $Token" } -Method Get
							Write-LogFile -Message "[INFO] Successfully retrieved inbox rules for $($mailbox.userPrincipalName)." -Color "Green"
							$success = $true

							foreach ($rule in $inboxRules.value)
							{
								$RuleList += [PSCustomObject]@{
									UserName        = $mailbox.userPrincipalName
									RuleName        = $rule.name
									RuleEnabled     = $rule.enabled
									CopytoFolder    = $rule.actions.moveToFolder
									MovetoFolder    = $rule.actions.moveToFolder
									RedirectTo      = $rule.actions.redirectTo
									ForwardTo       = $rule.actions.forwardTo
									TextDescription = $rule.displayName
								}
							}
						}
						catch
						{
							$retryCount++
							$delay = [math]::Pow(2, $retryCount)
							Write-Warning "Error retrieving inbox rules for $($mailbox.userPrincipalName). Attempt $retryCount of $MaxRetries. Retrying in $delay seconds..."
							Start-Sleep -Seconds $delay
						}
					}

					if (-not $success)
					{
						Write-Error "Failed to retrieve inbox rules for $($mailbox.userPrincipalName) after $MaxRetries attempts." -ForegroundColor Red
					}
				}
			}
		}
		else
		{
			$userIdsArray = $UserIds.Split(",")

			foreach ($userId in $userIdsArray)
			{
				$inboxRulesUrl = "https://graph.microsoft.com/v1.0/users/$userId/mailFolders/inbox/messageRules"
				$retryCount = 0
				$success = $false

				while (-not $success -and $retryCount -lt $MaxRetries)
				{
					try
					{
						$inboxRules = Invoke-RestMethod -Uri $inboxRulesUrl -Headers @{Authorization = "Bearer $Token" } -Method Get
						Write-LogFile -Message "[INFO] Successfully retrieved inbox rules for $userId." -Color "Green"
						$success = $true

						foreach ($rule in $inboxRules.value)
						{
							$RuleList += [PSCustomObject]@{
								UserName        = $userId
								RuleName        = $rule.name
								RuleEnabled     = $rule.enabled
								CopytoFolder    = $rule.actions.moveToFolder
								MovetoFolder    = $rule.actions.moveToFolder
								RedirectTo      = $rule.actions.redirectTo
								ForwardTo       = $rule.actions.forwardTo
								TextDescription = $rule.displayName
							}
						}
					}
					catch
					{
						$retryCount++
						$delay = [math]::Pow(2, $retryCount)
						Write-Warning "Error retrieving inbox rules for $userId. Attempt $retryCount of $MaxRetries. Retrying in $delay seconds..."
						Start-Sleep -Seconds $delay
					}
				}

				if (-not $success)
				{
					Write-Error "Failed to retrieve inbox rules for $userId after $MaxRetries attempts." -ForegroundColor Red
				}
			}
		}

		if ($RuleList.Count -gt 0)
		{
			$RuleList | Export-Csv -Path $outputDirectory -NoTypeInformation -Encoding $Encoding
			Write-LogFile -Message "[INFO] Inbox rules are collected and written to: $outputDirectory" -Color "Green"
		}
	}

	end
	{
		Write-Host '[INFO] Process completed.' -ForegroundColor Green
	}
}
function Show-MailboxRules
{
	<#
    .SYNOPSIS
        Shows the mailbox rules in your organization via API calls.
    .DESCRIPTION
        Shows the mailbox rules in your organization.
    .PARAMETER UserIds
        UserIds is the Identity parameter specifying the Inbox rule that you want to view.
    .PARAMETER Token
        Token is the parameter specifying the API token for authentication.
    .PARAMETER MaxRetries
        Specifies the maximum number of retries for failed requests. Default: 3.
    .EXAMPLE
        Show-MailboxRules -Token $token -UserIds "HR@invictus-ir.com,Test@Invictus-ir.com"
    #>
	[CmdletBinding()]
	param (
		[string]$UserIds,
		[Parameter(Mandatory = $true)][string]$Token,
		[int]$MaxRetries = 3
	)

	begin
	{
		# Validate parameters
		if ($MaxRetries -le 0)
		{
			throw "MaxRetries must be greater than 0."
		}

		Write-LogFile -Message "[INFO] Running Show-MailboxRules" -Color "Green"
	}

	process
	{
		$retryCount = 0
		$success = $false

		if ($UserIds -eq "")
		{
			$mailboxesUrl = "https://graph.microsoft.com/v1.0/users"
			$mailboxes = @()

			while (-not $success -and $retryCount -lt $MaxRetries)
			{
				try
				{
					$mailboxes = Invoke-RestMethod -Uri $mailboxesUrl -Headers @{Authorization = "Bearer $Token" } -Method Get
					Write-LogFile -Message "[INFO] Successfully retrieved mailboxes." -Color "Green"
					$success = $true
				}
				catch
				{
					$retryCount++
					$delay = [math]::Pow(2, $retryCount)
					Write-Warning "Error retrieving mailboxes. Attempt $retryCount of $MaxRetries. Retrying in $delay seconds..."
					Start-Sleep -Seconds $delay
				}
			}

			if (-not $success)
			{
				Write-Error "Failed to retrieve mailboxes after $MaxRetries attempts." -ForegroundColor Red
			}
			else
			{
				foreach ($mailbox in $mailboxes.value)
				{
					$inboxRulesUrl = "https://graph.microsoft.com/v1.0/users/$($mailbox.id)/mailFolders/inbox/messageRules"
					$retryCount = 0
					$success = $false

					while (-not $success -and $retryCount -lt $MaxRetries)
					{
						try
						{
							$inboxRules = Invoke-RestMethod -Uri $inboxRulesUrl -Headers @{Authorization = "Bearer $Token" } -Method Get
							Write-LogFile -Message "[INFO] Successfully retrieved inbox rules for $($mailbox.userPrincipalName)." -Color "Green"
							$success = $true

							foreach ($rule in $inboxRules.value)
							{
								Write-LogFile -Message "[INFO] Found InboxRule for: $($mailbox.userPrincipalName)" -Color "Green"
								Write-LogFile -Message "RuleName: $($rule.name)" -Color "Yellow"
								Write-LogFile -Message "RuleEnabled: $($rule.enabled)" -Color "Yellow"
								Write-LogFile -Message "CopytoFolder: $($rule.actions.moveToFolder)" -Color "Yellow"
								Write-LogFile -Message "MovetoFolder: $($rule.actions.moveToFolder)" -Color "Yellow"
								Write-LogFile -Message "RedirectTo: $($rule.actions.redirectTo)" -Color "Yellow"
								Write-LogFile -Message "ForwardTo: $($rule.actions.forwardTo)" -Color "Yellow"
								Write-LogFile -Message "TextDescription: $($rule.displayName)" -Color "Yellow"
							}
						}
						catch
						{
							$retryCount++
							$delay = [math]::Pow(2, $retryCount)
							Write-Warning "Error retrieving inbox rules for $($mailbox.userPrincipalName). Attempt $retryCount of $MaxRetries. Retrying in $delay seconds..."
							Start-Sleep -Seconds $delay
						}
					}

					if (-not $success)
					{
						Write-Error "Failed to retrieve inbox rules for $($mailbox.userPrincipalName) after $MaxRetries attempts." -ForegroundColor Red
					}
				}
			}
		}
		else
		{
			$userIdsArray = $UserIds.Split(",")

			foreach ($userId in $userIdsArray)
			{
				$inboxRulesUrl = "https://graph.microsoft.com/v1.0/users/$userId/mailFolders/inbox/messageRules"
				$retryCount = 0
				$success = $false

				while (-not $success -and $retryCount -lt $MaxRetries)
				{
					try
					{
						$inboxRules = Invoke-RestMethod -Uri $inboxRulesUrl -Headers @{Authorization = "Bearer $Token" } -Method Get
						Write-LogFile -Message "[INFO] Successfully retrieved inbox rules for $userId." -Color "Green"
						$success = $true

						foreach ($rule in $inboxRules.value)
						{
							Write-LogFile -Message "[INFO] Found InboxRule for: $userId" -Color "Green"
							Write-LogFile -Message "RuleName: $($rule.name)" -Color "Yellow"
							Write-LogFile -Message "RuleEnabled: $($rule.enabled)" -Color "Yellow"
							Write-LogFile -Message "CopytoFolder: $($rule.actions.moveToFolder)" -Color "Yellow"
							Write-LogFile -Message "MovetoFolder: $($rule.actions.moveToFolder)" -Color "Yellow"
							Write-LogFile -Message "RedirectTo: $($rule.actions.redirectTo)" -Color "Yellow"
							Write-LogFile -Message "ForwardTo: $($rule.actions.forwardTo)" -Color "Yellow"
							Write-LogFile -Message "TextDescription: $($rule.displayName)" -Color "Yellow"
						}
					}
					catch
					{
						$retryCount++
						$delay = [math]::Pow(2, $retryCount)
						Write-Warning "Error retrieving inbox rules for $userId. Attempt $retryCount of $MaxRetries. Retrying in $delay seconds..."
						Start-Sleep -Seconds $delay
					}
				}

				if (-not $success)
				{
					Write-Error "Failed to retrieve inbox rules for $userId after $MaxRetries attempts." -ForegroundColor Red
				}
			}
		}
	}

	end
	{
		Write-Host '[INFO] Process completed.' -ForegroundColor Green
	}
}
