function Get-Sessions {
    <#
        .SYNOPSIS
        Find SessionID(s) in the Audit Log.
    
        .DESCRIPTION
        Find SessionID(s) in the Audit Log. You can filter based on IP address or Username. The first step is to identify what sessions belong to the threat actor.
        With this information you can go to the next step and find the MessageID(s) belonging to those sessions. Output is saved in: Output\MailItemsAccessed\
    
        .PARAMETER UserIds
        The unique identifier of the user.
    
        .PARAMETER StartDate
        startDate is the parameter specifying the start date of the date range.
    
        .PARAMETER EndDate
        endDate is the parameter specifying the end date of the date range.
    
        .PARAMETER IP
        The IP address parameter is used to filter the logs by specifying the desired IP address.
    
        .PARAMETER OutputDir
        outputDir is the parameter specifying the output directory.
        Default: Output\MailItemsAccessed
    
        .PARAMETER Encoding
        Encoding is the parameter specifying the encoding of the CSV output file.
        Default: UTF8
    
        .PARAMETER Output
        "Y" or "N" to specify whether the output should be saved to a file.
        Default: Y
    
        .EXAMPLE
        Get-Sessions -StartDate 1/4/2023 -EndDate 5/4/2023
        Collects all sessions for all users between 1/4/2023 and 5/4/2023.
    
        .EXAMPLE
        Get-Sessions -StartDate 1/4/2023 -EndDate 5/4/2023 -UserIds HR@invictus-ir.com
        Collects all sessions for the user HR@invictus-ir.com.
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]$StartDate,
        [Parameter(Mandatory = $true)]$EndDate,
        [string]$OutputDir = 'Output\MailItemsAccessed',
        [string]$UserIds,
        [string]$IP,
        [string]$Encoding = 'UTF8',
        [string]$Output = 'Y',
        [int]$MaxRetries = 3
    )
    
    begin {
        # Ensure output directory exists
        if (-not (Test-Path -Path $OutputDir)) {
            Write-LogFile -Message "[INFO] Creating the directory: $OutputDir" -Color 'Green'
            New-Item -ItemType Directory -Force -Path $OutputDir | Out-Null
        }
    
        Write-LogFile -Message '[INFO] Starting Get-Sessions' -Color 'Green'
    
        # Ensure connected to Microsoft 365
        if (-not (Get-MgContext)) {
            Connect-MgGraph -Scopes 'AuditLog.Read.All' -NoWelcome
        }
    }
    
    process {
        $retryCount = 0
        $success = $false
    
        while (-not $success -and $retryCount -lt $MaxRetries) {
            try {
                $Results = @()
    
                # Construct query filter
                $filter = "Operations eq 'MailItemsAccessed' and CreationTime ge $StartDate and CreationTime le $EndDate"
                if ($UserIds) {
                    $filter += " and UserIds eq '$UserIds'"
                }
                if ($IP) {
                    $filter += " and ClientIP eq '$IP'"
                }
    
                $params = @{
                    StartDate  = $StartDate
                    EndDate    = $EndDate
                    ResultSize = 5000
                    Filter     = $filter
                }
    
                $amountResults = (Search-UnifiedAuditLog @params -ResultSize 1 | Select-Object -First 1 -ExpandProperty ResultCount)
                if ($amountResults -gt 4999) {
                    Write-LogFile -Message "[WARNING] A total of $amountResults events have been identified, surpassing the maximum limit of 5000 results for a single session. To refine your search, kindly provide more specific details, such as specifying a user or IP address." -Color 'Red'
                    return
                }
    
                do {
                    $records = Search-UnifiedAuditLog @params
                    foreach ($rec in $records) {
                        $AuditData = ConvertFrom-Json $Rec.Auditdata
                        $Line = [PSCustomObject]@{
                            TimeStamp      = $AuditData.CreationTime
                            User           = $AuditData.UserId
                            Action         = $AuditData.Operation
                            SessionId      = $AuditData.SessionId
                            ClientIP       = $AuditData.ClientIPAddress
                            OperationCount = $AuditData.OperationCount
                        }
                        $Results += $Line
                    }
                    $params['SessionId'] = $records[-1].SessionId
                } while ($records.Count -eq 5000)
    
                $Results | Sort-Object SessionId, TimeStamp | Format-Table Timestamp, User, Action, SessionId, ClientIP, OperationCount -AutoSize
    
                if (($Output -ne 'N') -and ($Output -ne 'No')) {
                    $fileName = 'Sessions'
                    if ($UserIds) { $fileName += "-$UserIds" }
                    if ($IP) { $fileName += "-$IP" }
                    $filePath = "$OutputDir\$fileName.csv"
                    $Results | Export-Csv -Path $filePath -NoTypeInformation -Encoding $Encoding
                    Write-LogFile -Message "[INFO] Output written to $filePath" -Color 'Green'
                }
    
                $success = $true
            } catch {
                $retryCount++
                $delay = [math]::Pow(2, $retryCount)
                Write-LogFile -Message "[WARNING] Error fetching data: $_. Attempt $retryCount of $MaxRetries. Retrying in $delay seconds..." -Color 'Yellow'
                Start-Sleep -Seconds $delay
            }
        }
    
        if (-not $success) {
            Write-LogFile -Message "[ERROR] Failed to retrieve session logs after $MaxRetries attempts." -Color 'Red'
        }
    }
}
    

function Get-MessageIDs {
    <#
    .SYNOPSIS
	Find the InternetMessageID(s).

    .DESCRIPTION
    Find the InternetMessageID(s). You can filter on SessionID(s) or IP addresses. After you identified the session(s) of the threat actor, you can use this information to find all MessageID(s).
    belonging to the sessions. With the MessageID(s) you can identify what emails were exposed to the threat actor. Output is saved in: Output\MailItemsAccessed\

	.PARAMETER StartDate
    startDate is the parameter specifying the start date of the date range.

	.PARAMETER EndDate
    endDate is the parameter specifying the end date of the date range.

	.PARAMETER OutputDir
    outputDir is the parameter specifying the output directory.
	Default: Output\MailItemsAccessed

	.PARAMETER Encoding
    Encoding is the parameter specifying the encoding of the CSV output file.
	Default: UTF8
	
	.PARAMETER Sessions
    The sessions parameter is used to filter the logs by specifying the desired session id.

    .PARAMETER IP
    The IP address parameter is used to filter the logs by specifying the desired IP address.

    .PARAMETER Output
    "Yes" or "No" to specify whether the output should be saved to a file.
	Default: Yes

    .PARAMETER Download
    To specifiy whether the messages and their attachments should be saved.
	Default: No

	.EXAMPLE
    Get-MessageIDs -StartDate 1/4/2023 -EndDate 5/4/2023
	Collects all sessions for all users between 1/4/2023 and 5/4/2023.
    
    .EXAMPLE
    Get-MessageIDs Get-Sessions -StartDate 1/4/2023 -EndDate 5/4/2023 -IP 1.1.1.1
	Collects all sessions for the IP address 1.1.1.1.

    .EXAMPLE
    Get-MessageIDs Get-Sessions -StartDate 1/4/2023 -EndDate 5/4/2023 -IP 1.1.1.1 -Download Yes
	Collects all sessions for the IP address 1.1.1.1 and downloads the e-mails and attachments.
#>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]$StartDate,
        [Parameter(Mandatory = $true)]$EndDate,
        [string]$OutputDir,
        [string]$IP,
        [string]$Encoding,
        [string]$Sessions,
        [string]$Output,
        [string]$Download
    )

    try {
        $areYouConnected = Get-AdminAuditLogConfig -ErrorAction stop
    } catch {
        write-logFile -Message '[WARNING] You must call Connect-M365 before running this script' -Color 'Red'
        break
    }

    if ($OutputDir -eq '' ) {
        $OutputDir = 'Output\MailItemsAccessed'
        if (!(Test-Path $OutputDir)) {
            New-Item -ItemType Directory -Force -Name $OutputDir | Out-Null
            write-logFile -Message "[INFO] Creating the following directory: $OutputDir"
        }
    }

    else {
        if (Test-Path -Path $OutputDir) {
            write-LogFile -Message "[INFO] Custom directory set to: $OutputDir"
        }
	
        else {
            Write-Error "[Error] Custom directory invalid: $OutputDir exiting script" -ErrorAction Stop
            write-LogFile -Message "[Error] Custom directory invalid: $OutputDir exiting script"
        }
    }

    if ($Encoding -eq '' ) {
        $Encoding = 'UTF8'
    }
    
    Write-logFile -Message '[INFO] Running Get-MessageIDs' -Color 'Green'

    $results = @()
	
    if (!$Sessions -And !$IP) {
        $amountResults = Search-UnifiedAuditLog -StartDate $StartDate -EndDate $EndDate -Operations 'MailItemsAccessed' -ResultSize 1 | Select-Object -First 1 -ExpandProperty ResultCount
		
        if ($amountResults -gt 4999) {
            write-logFile -Message "[WARNING] A total of $amountResults events have been identified, surpassing the maximum limit of 5000 results for a single session. To refine your search, kindly lower the time window." -Color 'Red'
        }

        else {
            $MailItemRecords = Search-UnifiedAuditLog -StartDate $StartDate -EndDate $EndDate -ResultSize 5000 -Operations 'MailItemsAccessed'

            forEach ($Rec in $MailItemRecords) {
                $AuditData = ConvertFrom-Json $Rec.Auditdata
                $InternetMessageId = $AuditData.Folders.FolderItems
                $TimeStamp = $AuditData.CreationTime
                $SessionId = $AuditData.SessionId
                $ClientIP = $AuditData.ClientIPAddress
                $userId = $AuditData.UserId
                                
                if ($AuditData.OperationCount -gt 1) {
                    foreach ($message in $InternetMessageId) {
                        $iMessageID = $message.InternetMessageId
                        $sizeInBytes = $message.SizeInBytes

                        $resultObject = [PSCustomObject]@{
                            Timestamp         = $TimeStamp
                            User              = $userId
                            IPaddress         = $ClientIP
                            SessionID         = $SessionId
                            InternetMessageId = $iMessageID
                            SizeInBytes       = $sizeInBytes
                        }
                        
                        $results += $resultObject

                        if ($Download -eq 'Yes' ) {
                            DownloadMails($iMessageID, $userId)
                        } 
                    }
                }
                            
                else {
                    $SessionID = ''
                    $iMessageID = $message.InternetMessageId
                    $sizeInBytes = $message.SizeInBytes
                    
                    $resultObject = [PSCustomObject]@{
                        Timestamp         = $TimeStamp
                        User              = $userId
                        IPaddress         = $ClientIP
                        SessionID         = $SessionId
                        InternetMessageId = $iMessageID
                        SizeInBytes       = $sizeInBytes
                    }
                    
                    $results += $resultObject

                    if ($Download -eq 'Yes' ) {
                        DownloadMails($iMessageID, $userId)
                    }
                }
            }
        }
        $results | Sort-Object TimeStamp | Format-Table Timestamp, User, IPaddress, SessionID, InternetMessageId, SizeInBytes
        
        if (($output -ne 'N') -And ($output -ne 'No')) {
            $date = [datetime]::Now.ToString('yyyyMMddHHmmss') 
            $filePath = "$OutputDir\$date-MessageIDs.csv"
            $results | Export-Csv -Path $filePath -NoTypeInformation -Encoding $Encoding
            Write-logFile -Message "[INFO] Output written to $filePath" -Color 'Green'
        } 
    }

    elseif ($IP -And $Sessions) {
        $amountResults = Search-UnifiedAuditLog -StartDate $StartDate -EndDate $EndDate -FreeText $IP -Operations 'MailItemsAccessed' -ResultSize 1 | Select-Object -First 1 -ExpandProperty ResultCount
		
        if ($amountResults -gt 4999) {
            write-logFile -Message "[WARNING] A total of $amountResults events have been identified, surpassing the maximum limit of 5000 results for a single session. To refine your search, kindly lower the time window." -Color 'Red'
        }

        else {
            $MailItemRecords = Search-UnifiedAuditLog -StartDate $StartDate -EndDate $EndDate -FreeText $IP -ResultSize 5000 -Operations 'MailItemsAccessed'
        
            forEach ($Rec in $MailItemRecords) {
                $AuditData = ConvertFrom-Json $Rec.Auditdata
                $InternetMessageId = $AuditData.Folders.FolderItems
                $TimeStamp = $AuditData.CreationTime
                $SessionId = $AuditData.SessionId
                $ClientIP = $AuditData.ClientIPAddress
                $userId = $AuditData.UserId
        
                if ($SessionId) {
                    if ($Sessions.Contains($SessionId)) {
                        if ($ClientIP -eq $IP) {

                            if ($AuditData.OperationCount -gt 1) {
                                foreach ($message in $InternetMessageId) {
                                    $iMessageID = $message.InternetMessageId
                                    $sizeInBytes = $message.SizeInBytes
            
                                    $resultObject = [PSCustomObject]@{
                                        Timestamp         = $TimeStamp
                                        User              = $userId
                                        IPaddress         = $ClientIP
                                        SessionID         = $SessionId
                                        InternetMessageId = $iMessageID
                                        SizeInBytes       = $sizeInBytes
                                    }
                                    
                                    $results += $resultObject

                                    if ($Download -eq 'Yes' ) {
                                        DownloadMails($iMessageID, $userId)
                                    }
                                }
                            }
                                        
                            else {
                                $SessionID = ''
                                $iMessageID = $message.InternetMessageId
                                $sizeInBytes = $message.SizeInBytes
                                
                                $resultObject = [PSCustomObject]@{
                                    Timestamp         = $TimeStamp
                                    User              = $userId
                                    IPaddress         = $ClientIP
                                    SessionID         = $SessionId
                                    InternetMessageId = $iMessageID
                                    SizeInBytes       = $sizeInBytes
                                }
                                
                                $results += $resultObject

                                if ($Download -eq 'Yes' ) {
                                    DownloadMails($iMessageID, $userId)
                                }
                            }                               
                        }
                        
                    }
                }
            }
        }
        $results | Sort-Object TimeStamp | Format-Table Timestamp, User, IPaddress, SessionID, InternetMessageId, SizeInBytes  

        if (($output -ne 'N') -And ($output -ne 'No')) {
            $date = [datetime]::Now.ToString('yyyyMMddHHmmss') 
            $filePath = "$OutputDir\$date-MessageIDs.csv"
            $results | Export-Csv -Path $filePath -NoTypeInformation -Encoding $Encoding
            Write-logFile -Message "[INFO] Output written to $filePath" -Color 'Green'
        }
    }

    elseif ($Sessions -And !$IP) {
        $amountResults = Search-UnifiedAuditLog -StartDate $StartDate -EndDate $EndDate -FreeText $Sessions -Operations 'MailItemsAccessed' -ResultSize 1 | Select-Object -First 1 -ExpandProperty ResultCount
		
        if ($amountResults -gt 4999) {
            write-logFile -Message "[WARNING] A total of $amountResults events have been identified, surpassing the maximum limit of 5000 results for a single session. To refine your search, kindly lower the time window." -Color 'Red'
        }

        else {
            $MailItemRecords = Search-UnifiedAuditLog -StartDate $StartDate -EndDate $EndDate -ResultSize 5000 -FreeText $Sessions -Operations 'MailItemsAccessed'
        
            forEach ($Rec in $MailItemRecords) {
                $AuditData = ConvertFrom-Json $Rec.Auditdata
                $InternetMessageId = $AuditData.Folders.FolderItems
                $TimeStamp = $AuditData.CreationTime
                $SessionId = $AuditData.SessionId
                $ClientIP = $AuditData.ClientIPAddress
                $userId = $AuditData.UserId

                if ($SessionId) {
                    if ($Sessions.Contains($SessionId)) {
                        if ($AuditData.OperationCount -gt 1) {
                            foreach ($message in $InternetMessageId) {
                                $iMessageID = $message.InternetMessageId
                                $sizeInBytes = $message.SizeInBytes
            
                                $resultObject = [PSCustomObject]@{
                                    Timestamp         = $TimeStamp
                                    User              = $userId
                                    IPaddress         = $ClientIP
                                    SessionID         = $SessionId
                                    InternetMessageId = $iMessageID
                                    SizeInBytes       = $sizeInBytes
                                }
                                
                                $results += $resultObject

                                if ($Download -eq 'Yes' ) {
                                    DownloadMails($iMessageID, $userId)
                                }
                            }
                        }
                                    
                        else {
                            $SessionID = ''
                            $iMessageID = $message.InternetMessageId
                            $sizeInBytes = $message.SizeInBytes
                            
                            $resultObject = [PSCustomObject]@{
                                Timestamp         = $TimeStamp
                                User              = $userId
                                IPaddress         = $ClientIP
                                SessionID         = $SessionId
                                InternetMessageId = $iMessageID
                                SizeInBytes       = $sizeInBytes
                            }
                            
                            $results += $resultObject

                            if ($Download -eq 'Yes' ) {
                                DownloadMails($iMessageID, $userId)
                            }
                        }                               
                    }    
                }
            }
        }
        $results | Sort-Object TimeStamp | Format-Table Timestamp, User, IPaddress, SessionID, InternetMessageId, SizeInBytes  

        if (($output -ne 'N') -And ($output -ne 'No')) {
            $filePath = "$OutputDir\MessageIDs-$Sessions.csv"
            $results | Export-Csv -Path $filePath -NoTypeInformation -Encoding $Encoding
            Write-logFile -Message "[INFO] Output written to $filePath" -Color 'Green'
        }
    }
        
    elseif (!$Sessions -And $IP) {
        $amountResults = Search-UnifiedAuditLog -StartDate $StartDate -EndDate $EndDate -FreeText $IP -Operations 'MailItemsAccessed' -ResultSize 1 | Select-Object -First 1 -ExpandProperty ResultCount
        if ($amountResults -gt 4999) {
            write-logFile -Message "[WARNING] A total of $amountResults events have been identified, surpassing the maximum limit of 5000 results for a single session. To refine your search, kindly lower the time window." -Color 'Red'
        }

        else {
            $MailItemRecords = Search-UnifiedAuditLog -StartDate $StartDate -EndDate $EndDate -FreeText $IP -ResultSize 5000 -Operations 'MailItemsAccessed'

            forEach ($Rec in $MailItemRecords) {
                $AuditData = ConvertFrom-Json $Rec.Auditdata
                $InternetMessageId = $AuditData.Folders.FolderItems
                $TimeStamp = $AuditData.CreationTime
                $SessionId = $AuditData.SessionId
                $ClientIP = $AuditData.ClientIPAddress

                $userId = $AuditData.UserId
                  
                if ($ClientIP -eq $IP) {
                    if ($AuditData.OperationCount -gt 1) {
                        foreach ($message in $InternetMessageId) {
                            $iMessageID = $message.InternetMessageId
                            $sizeInBytes = $message.SizeInBytes
            
                            $resultObject = [PSCustomObject]@{
                                Timestamp         = $TimeStamp
                                User              = $userId
                                IPaddress         = $ClientIP
                                SessionID         = $SessionId
                                InternetMessageId = $iMessageID
                                SizeInBytes       = $sizeInBytes
                            }
                            
                            $results += $resultObject

                            if ($Download -eq 'Yes' ) {
                                DownloadMails($iMessageID, $userId)
                            }
                        }
                    }
                                
                    else {
                        $SessionID = ''
                        $iMessageID = $message.InternetMessageId
                        $sizeInBytes = $message.SizeInBytes
                        
                        $resultObject = [PSCustomObject]@{
                            Timestamp         = $TimeStamp
                            User              = $userId
                            IPaddress         = $ClientIP
                            SessionID         = $SessionId
                            InternetMessageId = $iMessageID
                            SizeInBytes       = $sizeInBytes
                        }
                        
                        $results += $resultObject

                        if ($Download -eq 'Yes' ) {
                            DownloadMails($iMessageID, $userId)
                        }
                    }                               
                }          
            }
        }
        $results | Sort-Object TimeStamp | Format-Table Timestamp, User, IPaddress, SessionID, InternetMessageId, SizeInBytes  

        if (($output -ne 'N') -And ($output -ne 'No')) {
            $date = [datetime]::Now.ToString('yyyyMMddHHmmss') 
            $filePath = "$OutputDir\$date-MessageIDs.csv"
            $results | Export-Csv -Path $filePath -NoTypeInformation -Encoding $Encoding
            Write-logFile -Message "[INFO] Output written to $filePath" -Color 'Green'
        }
    }                       
}

function DownloadMails {
    param(
        [Parameter(Mandatory=$true)] [string]$iMessageID,
        [Parameter(Mandatory=$true)] [string]$UserIds,
        [string]$OutputDir = "Output\MailItemsAccessed\Emails"
    )

    Write-LogFile -Message "[INFO] Running DownloadMails for InternetMessageId: $iMessageID" -Color "Green"

    try {
        # Ensure output directory exists
        if (-not (Test-Path -Path $OutputDir)) {
            Write-LogFile -Message "[INFO] Creating the following directory: $OutputDir"
            New-Item -ItemType Directory -Force -Path $OutputDir | Out-Null
        }

        # Extract only the message ID part
        $onlyMessageID = $iMessageID.Split(' ')[0]

        # Retrieve the message
        $getMessage = Get-MgUserMessage -Filter "internetMessageId eq '$onlyMessageID'" -UserId $UserIds -ErrorAction Stop
        $messageId = $getMessage.Id
        $ReceivedDateTime = $getMessage.ReceivedDateTime.ToString('yyyyMMdd_HHmmss')
        $subject = $getMessage.Subject -replace '[\\/:*?"<>|]', '_'
        $filePath = "$OutputDir\$ReceivedDateTime-$subject.msg"

        # Save the message content
        Get-MgUserMessageContent -MessageId $messageId -UserId $UserIds -OutFile $filePath
        Write-LogFile -Message "[INFO] Email saved to $filePath" -Color "Green"

        # Check for and save attachments if present
        if ($getMessage.HasAttachments -eq $true) {
            Write-LogFile -Message "[INFO] Attachments found, downloading..."
            $attachments = Get-MgUserMessageAttachment -UserId $UserIds -MessageId $messageId

            foreach ($attachment in $attachments) {
                $filename = $attachment.Name -replace '[\\/:*?"<>|]', '_'
                $filePath = Join-Path -Path $OutputDir -ChildPath "$ReceivedDateTime-$filename"

                # Decode and save attachment content
                $base64Content = $attachment.ContentBytes
                $decodedContent = [System.Convert]::FromBase64String($base64Content)
                [System.IO.File]::WriteAllBytes($filePath, $decodedContent)

                Write-LogFile -Message "[INFO] Attachment saved to $filePath" -Color "Green"
            }
        } else {
            Write-LogFile -Message "[INFO] No attachments found for this email." -Color "Yellow"
        }
    } catch {
        Write-LogFile -Message "[WARNING] Error retrieving or saving email: $($_.Exception.Message)" -Color "Red"
        Write-Host "[WARNING] Error Message: $($_.Exception.Message)" -ForegroundColor Red
    }
}
