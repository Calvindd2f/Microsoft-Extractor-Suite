<# 
This contains functions for getting the unified audit log entries. Calvin 5.7.24

Reminder to self:
    The timeout for server-side exchange commands is 15 minutes, so if querying the results takes longer than 15ms, it will timeout.
    With this in mind, I can implement full success of obtaining the logs by having a timer while retrieving the logs, before it times out. It gracefully exits. 
    Afterwards, it uses the previous request session.ID to continue where it left off.

    Application Interop will involve wrapping the cmdlet in the ExoCommand function. Along with this there is one or two other things needed.

    I need to create the function IsConnected in same script as authentication and has to be fully implemented into each of these function for `$IsConnected assertion.
::
#>
function Get-UALAll
{
	<#
    .SYNOPSIS
        Gets unified audit log entries.
    .DESCRIPTION
        Collects the contents of the unified audit log using the Search-UnifiedAuditLog cmdlet with pagination.
        Outputs are written to a specified directory.
    .PARAMETER StartDate
        Specifies the date from which all logs need to be collected.
    .PARAMETER EndDate
        Specifies the end date until which all logs need to be collected.
    .PARAMETER OutputDir
        Specifies the output directory. Default: "Output\UnifiedAuditLog"
    .PARAMETER Encoding
        Specifies the encoding of the output file. Default: UTF8
    .PARAMETER UserIds
        Filters log entries by the user account that performed the actions.
    .PARAMETER Interval
        Specifies the interval in minutes for each API call. Default: 720
    .PARAMETER Output
        Specifies the output format. Default: CSV
    .PARAMETER MergeOutput
        Specifies if output files should be merged into a single file.
    .PARAMETER HighCompleteness
        Specifies if high completeness mode should be used for the search.
    .PARAMETER ResultSize
        Specifies the maximum number of results to return per request. Default: 5000
    .PARAMETER MaxRetries
        Specifies the maximum number of retries for failed requests. Default: 3
    #>
	[CmdletBinding()]
	param (
		[datetime]$StartDate,
		[datetime]$EndDate,
		[string]$UserIds,
		[int]$Interval = 720,
		[string]$Output = "CSV",
		[switch]$MergeOutput,
		[string]$OutputDir = "Output\UnifiedAuditLog",
		[string]$Encoding = "UTF8",
		[switch]$HighCompleteness,
		[int]$ResultSize = 5000,
		[int]$MaxRetries = 3
	)

	begin
	{
		# Validate parameters
		if (-not $StartDate)
		{
			throw "StartDate is required."
		}
		if (-not $EndDate)
		{
			throw "EndDate is required."
		}
		if ([string]::IsNullOrWhiteSpace($OutputDir))
		{
			$OutputDir = "Output\UnifiedAuditLog"
		}
		if ([string]::IsNullOrWhiteSpace($Encoding))
		{
			$Encoding = "UTF8"
		}
		if ($ResultSize -le 0)
		{
			throw "ResultSize must be greater than 0."
		}
		if ($MaxRetries -le 0)
		{
			throw "MaxRetries must be greater than 0."
		}

		# Ensure the output directory exists
		if (-not (Test-Path -Path $OutputDir))
		{
			New-Item -ItemType Directory -Force -Path $OutputDir | Out-Null
		}
	}

	process
	{
		$currentDate = $StartDate

		while ($currentDate -lt $EndDate)
		{
			$currentEnd = $currentDate.AddMinutes($Interval)

			$params = @{
				StartDate      = $currentDate
				EndDate        = $currentEnd
				ResultSize     = $ResultSize
				SessionCommand = "ReturnLargeSet"
			}

			if ($UserIds)
			{
				$params.UserIds = $UserIds.Split(",")
			}

			if ($HighCompleteness)
			{
				$params.HighCompleteness = $true
			}

			$outputFile = "$OutputDir/UAL-$($currentDate.ToString("yyyyMMddHHmmss")).$Output"

			$retryCount = 0
			$success = $false

			while (-not $success -and $retryCount -lt $MaxRetries)
			{
				try
				{
					$results = @()
					$sessionId = [Guid]::NewGuid().ToString()
					$params.SessionId = $sessionId
					do
					{
						$result = Search-UnifiedAuditLog @params
						$results += $result
						$params.SessionCommand = "ReturnNextPreviewPage"
					} while ($result.Count -eq $ResultSize)

					if ($Output -eq "CSV")
					{
						$results | Export-Csv -Path $outputFile -NoTypeInformation -Encoding $Encoding
					}
					else
					{
						$results | ConvertTo-Json -Depth 100 | Out-File -FilePath $outputFile -Encoding $Encoding
					}

					Write-Host "[INFO] Audit logs written to $outputFile" -ForegroundColor Green
					$success = $true
				}
				catch
				{
					$retryCount++
					$delay = [math]::Pow(2, $retryCount)
					Write-Warning "Error fetching data for interval starting at $currentDate. Attempt $retryCount of $MaxRetries. Retrying in $delay seconds..."
					Start-Sleep -Seconds $delay
				}
			}

			if (-not $success)
			{
				Write-Error "Failed to fetch data for interval starting at $currentDate after $MaxRetries attempts." -ForegroundColor Red
			}

			$currentDate = $currentEnd
			[System.GC]::Collect()
			[System.GC]::WaitForPendingFinalizers()
		}
	}

	end
	{
		if ($MergeOutput)
		{
			Write-Host "[INFO] Merging output files into one file" -ForegroundColor Green
			$mergedFilePath = "$OutputDir\Merged\UAL-Combined.$Output"
			$allFiles = Get-ChildItem -Path $OutputDir -Filter "*.$Output" | Select-Object -ExpandProperty FullName
			if ($Output -eq "CSV")
			{
				Import-Csv -Path $allFiles | Export-Csv -Path $mergedFilePath -NoTypeInformation -Encoding $Encoding
			}
			else
			{
				Get-Content -Path $allFiles | Out-File -FilePath $mergedFilePath -Encoding $Encoding
			}
			Write-Host "[INFO] All logs merged into $mergedFilePath" -ForegroundColor Green
		}

		Write-Host '[INFO] Process completed.' -ForegroundColor Green
	}
}

function Get-UALGroup
{
	<#
    .SYNOPSIS
        Gets the selected group of unified audit log entries.
    .DESCRIPTION
        Makes it possible to extract a group of specific unified audit data out of a Microsoft 365 environment.
        You can, for example, extract all Exchange or Azure logging in one go.
        The output will be written to: Output\UnifiedAuditLog\
    .PARAMETER UserIds
        UserIds is the parameter filtering the log entries by the account of the user who performed the actions.
    .PARAMETER StartDate
        StartDate is the parameter specifying the start date of the date range. Default: Today -90 days.
    .PARAMETER EndDate
        EndDate is the parameter specifying the end date of the date range. Default: Now.
    .PARAMETER Interval
        Interval is the parameter specifying the interval in which the logs are being gathered. Default: 1440 minutes.
    .PARAMETER Group
        Group is the group of logging needed to be extracted. Options are: Exchange, Azure, Sharepoint, Skype, and Defender.
    .PARAMETER Output
        Output is the parameter specifying the CSV or JSON output type. Default: CSV.
    .PARAMETER OutputDir
        OutputDir is the parameter specifying the output directory. Default: Output\UnifiedAuditLog.
    .PARAMETER MergeOutput
        MergeOutput is the parameter specifying if you wish to merge CSV outputs to a single file. Default: No.
    .PARAMETER Encoding
        Encoding is the parameter specifying the encoding of the CSV/JSON output file. Default: UTF8.
    .PARAMETER MaxRetries
        Specifies the maximum number of retries for failed requests. Default: 3.
    .EXAMPLE
        Get-UALGroup -Group Azure
        Gets the Azure related unified audit log entries.
    #>
	[CmdletBinding()]
	param (
		[string]$StartDate,
		[string]$EndDate,
		[string]$UserIds,
		[int]$Interval = 1440,
		[string]$Group,
		[string]$Output = "CSV",
		[switch]$MergeOutput,
		[string]$OutputDir = "Output\UnifiedAuditLog",
		[string]$Encoding = "UTF8",
		[int]$MaxRetries = 3
	)

	begin
	{
		# Validate parameters
		if ([string]::IsNullOrWhiteSpace($Group))
		{
			throw "Group is required. Options are: Exchange, Azure, Sharepoint, Skype, and Defender."
		}
        
		$validGroups = @("Exchange", "Azure", "Sharepoint", "Skype", "Defender")
		if (-not $validGroups.Contains($Group))
		{
			throw "Invalid group specified. Options are: Exchange, Azure, Sharepoint, Skype, and Defender."
		}
        
		if ([string]::IsNullOrWhiteSpace($OutputDir))
		{
			$OutputDir = "Output\UnifiedAuditLog"
		}
		if ([string]::IsNullOrWhiteSpace($Encoding))
		{
			$Encoding = "UTF8"
		}
		if ($MaxRetries -le 0)
		{
			throw "MaxRetries must be greater than 0."
		}

		# Ensure the output directory exists
		if (-not (Test-Path -Path $OutputDir))
		{
			New-Item -ItemType Directory -Force -Path $OutputDir | Out-Null
		}

		# Determine record types based on the group
		switch ($Group)
		{
			"Exchange"
			{
				$recordTypes = @("ExchangeAdmin", "ExchangeAggregatedOperation", "ExchangeItem", "ExchangeItemGroup", "ExchangeItemAggregated", "ComplianceDLPExchange", "ComplianceSupervisionExchange", "MipAutoLabelExchangeItem")
				$recordFile = "Exchange"
			}
			"Azure"
			{
				$recordTypes = @("AzureActiveDirectory", "AzureActiveDirectoryAccountLogon", "AzureActiveDirectoryStsLogon")
				$recordFile = "Azure"
			}
			"Sharepoint"
			{
				$recordTypes = @("ComplianceDLPSharePoint", "SharePoint", "SharePointFileOperation", "SharePointSharingOperation", "SharepointListOperation", "ComplianceDLPSharePointClassification", "SharePointCommentOperation", "SharePointListItemOperation", "SharePointContentTypeOperation", "SharePointFieldOperation", "MipAutoLabelSharePointItem", "MipAutoLabelSharePointPolicyLocation")
				$recordFile = "Sharepoint"
			}
			"Skype"
			{
				$recordTypes = @("SkypeForBusinessCmdlets", "SkypeForBusinessPSTNUsage", "SkypeForBusinessUsersBlocked")
				$recordFile = "Skype"
			}
			"Defender"
			{
				$recordTypes = @("ThreatIntelligence", "ThreatFinder", "ThreatIntelligenceUrl", "ThreatIntelligenceAtpContent", "Campaign", "AirInvestigation", "WDATPAlerts", "AirManualInvestigation", "AirAdminActionInvestigation", "MSTIC", "MCASAlerts")
				$recordFile = "Defender"
			}
		}
	}

	process
	{
		$currentDate = [datetime]::Parse($StartDate)
		$endDate = [datetime]::Parse($EndDate)

		foreach ($record in $recordTypes)
		{
			$currentStart = $currentDate
			$currentEnd = $endDate

			$retryCount = 0
			$success = $false

			while ($currentStart -lt $endDate)
			{
				$currentEnd = $currentStart.AddMinutes($Interval)

				$params = @{
					StartDate      = $currentStart
					EndDate        = $currentEnd
					RecordType     = $record
					ResultSize     = 5000
					SessionCommand = "ReturnLargeSet"
				}

				if ($UserIds)
				{
					$params.UserIds = $UserIds.Split(",")
				}

				$outputFile = "$OutputDir/UAL-$($currentStart.ToString("yyyyMMddHHmmss"))-$record.$Output"

				while (-not $success -and $retryCount -lt $MaxRetries)
				{
					try
					{
						$results = @()
						$sessionId = [Guid]::NewGuid().ToString()
						$params.SessionId = $sessionId
						do
						{
							$result = Search-UnifiedAuditLog @params
							$results += $result
							$params.SessionCommand = "ReturnNextPreviewPage"
						} while ($result.Count -eq $ResultSize)

						if ($Output -eq "CSV")
						{
							$results | Export-Csv -Path $outputFile -NoTypeInformation -Encoding $Encoding
						}
						else
						{
							$results | ConvertTo-Json -Depth 100 | Out-File -FilePath $outputFile -Encoding $Encoding
						}

						Write-Host "[INFO] Audit logs written to $outputFile" -ForegroundColor Green
						$success = $true
					}
					catch
					{
						$retryCount++
						$delay = [math]::Pow(2, $retryCount)
						Write-Warning "Error fetching data for interval starting at $currentStart. Attempt $retryCount of $MaxRetries. Retrying in $delay seconds..."
						Start-Sleep -Seconds $delay
					}
				}

				if (-not $success)
				{
					Write-Error "Failed to fetch data for interval starting at $currentStart after $MaxRetries attempts." -ForegroundColor Red
				}

				$currentStart = $currentEnd
				[System.GC]::Collect()
				[System.GC]::WaitForPendingFinalizers()
			}
		}
	}

	end
	{
		if ($MergeOutput)
		{
			Write-Host "[INFO] Merging output files into one file" -ForegroundColor Green
			$mergedFilePath = "$OutputDir\Merged\UAL-Combined.$Output"
			$allFiles = Get-ChildItem -Path $OutputDir -Filter "*.$Output" | Select-Object -ExpandProperty FullName
			if ($Output -eq "CSV")
			{
				Import-Csv -Path $allFiles | Export-Csv -Path $mergedFilePath -NoTypeInformation -Encoding $Encoding
			}
			else
			{
				Get-Content -Path $allFiles | Out-File -FilePath $mergedFilePath -Encoding $Encoding
			}
			Write-Host "[INFO] All logs merged into $mergedFilePath" -ForegroundColor Green
		}

		Write-Host '[INFO] Process completed.' -ForegroundColor Green
	}
}

function Get-UALSpecific
{
	<#
    .SYNOPSIS
        Gets specific record types of unified audit log.
    .DESCRIPTION
        Makes it possible to extract a group of specific unified audit data out of a Microsoft 365 environment.
        The output will be written to: Output\UnifiedAuditLog\

    .PARAMETER UserIds
        UserIds is the parameter filtering the log entries by the account of the user who performed the actions.
    .PARAMETER StartDate
        StartDate is the parameter specifying the start date of the date range. Default: Today -90 days.
    .PARAMETER EndDate
        EndDate is the parameter specifying the end date of the date range. Default: Now.
    .PARAMETER Interval
        Interval is the parameter specifying the interval in which the logs are being gathered. Default: 1440 minutes.
    .PARAMETER RecordType
        The RecordType parameter filters the log entries by record type. A total of 236 RecordTypes are supported.
    .PARAMETER Output
        Output is the parameter specifying the CSV or JSON output type. Default: CSV.
    .PARAMETER OutputDir
        OutputDir is the parameter specifying the output directory. Default: Output\UnifiedAuditLog.
    .PARAMETER Encoding
        Encoding is the parameter specifying the encoding of the CSV/JSON output file. Default: UTF8.
    .PARAMETER MergeOutput
        MergeOutput is the parameter specifying if you wish to merge CSV outputs to a single file. Default: No.
    .PARAMETER MaxRetries
        Specifies the maximum number of retries for failed requests. Default: 3.
    .EXAMPLE
        Get-UALSpecific -RecordType ExchangeItem
        Gets the ExchangeItem logging from the unified audit log.
    #>
	[CmdletBinding()]
	param (
		[datetime]$StartDate = (Get-Date).AddDays(-90),
		[datetime]$EndDate = (Get-Date),
		[string]$UserIds = "*",
		[int]$Interval = 1440,
		[Parameter(Mandatory = $true)][string]$RecordType,
		[string]$Output = "CSV",
		[switch]$MergeOutput,
		[string]$OutputDir = "Output\UnifiedAuditLog",
		[string]$Encoding = "UTF8",
		[int]$MaxRetries = 3
	)

	begin
	{
		# Validate parameters
		if ([string]::IsNullOrWhiteSpace($RecordType))
		{
			throw "RecordType is required."
		}
		if ([string]::IsNullOrWhiteSpace($OutputDir))
		{
			$OutputDir = "Output\UnifiedAuditLog"
		}
		if ([string]::IsNullOrWhiteSpace($Encoding))
		{
			$Encoding = "UTF8"
		}
		if ($MaxRetries -le 0)
		{
			throw "MaxRetries must be greater than 0."
		}

		# Ensure the output directory exists
		if (-not (Test-Path -Path $OutputDir))
		{
			New-Item -ItemType Directory -Force -Path $OutputDir | Out-Null
		}

		Write-LogFile -Message "[INFO] Running Get-UALSpecific" -Color "Green"
		Write-LogFile -Message "[INFO] Extracting all available audit logs between $($StartDate.ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ssK")) and $($EndDate.ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ssK"))"
		Write-LogFile -Message "[INFO] The following RecordType(s) are configured to be extracted:"
		Write-LogFile -Message "-$RecordType"
	}

	process
	{
		$currentDate = $StartDate

		while ($currentDate -lt $EndDate)
		{
			$currentEnd = $currentDate.AddMinutes($Interval)
			$retryCount = 0
			$success = $false

			$params = @{
				StartDate      = $currentDate
				EndDate        = $currentEnd
				RecordType     = $RecordType
				ResultSize     = 5000
				SessionCommand = "ReturnLargeSet"
			}

			if ($UserIds)
			{
				$params.UserIds = $UserIds.Split(",")
			}

			$outputFile = "$OutputDir/UAL-$($currentDate.ToString("yyyyMMddHHmmss"))-$RecordType.$Output"

			while (-not $success -and $retryCount -lt $MaxRetries)
			{
				try
				{
					$results = @()
					$sessionId = [Guid]::NewGuid().ToString()
					$params.SessionId = $sessionId
					do
					{
						$result = Search-UnifiedAuditLog @params
						$results += $result
						$params.SessionCommand = "ReturnNextPreviewPage"
					} while ($result.Count -eq $ResultSize)

					if ($Output -eq "CSV")
					{
						$results | Export-Csv -Path $outputFile -NoTypeInformation -Encoding $Encoding
					}
					else
					{
						$results | ConvertTo-Json -Depth 100 | Out-File -FilePath $outputFile -Encoding $Encoding
					}

					Write-Host "[INFO] Audit logs written to $outputFile" -ForegroundColor Green
					$success = $true
				}
				catch
				{
					$retryCount++
					$delay = [math]::Pow(2, $retryCount)
					Write-Warning "Error fetching data for interval starting at $currentDate. Attempt $retryCount of $MaxRetries. Retrying in $delay seconds..."
					Start-Sleep -Seconds $delay
				}
			}

			if (-not $success)
			{
				Write-Error "Failed to fetch data for interval starting at $currentDate after $MaxRetries attempts." -ForegroundColor Red
			}

			$currentDate = $currentEnd
			[System.GC]::Collect()
			[System.GC]::WaitForPendingFinalizers()
		}
	}

	end
	{
		if ($MergeOutput)
		{
			Write-Host "[INFO] Merging output files into one file" -ForegroundColor Green
			$mergedFilePath = "$OutputDir\Merged\UAL-Combined.$Output"
			$allFiles = Get-ChildItem -Path $OutputDir -Filter "*.$Output" | Select-Object -ExpandProperty FullName
			if ($Output -eq "CSV")
			{
				Import-Csv -Path $allFiles | Export-Csv -Path $mergedFilePath -NoTypeInformation -Encoding $Encoding
			}
			else
			{
				Get-Content -Path $allFiles | Out-File -FilePath $mergedFilePath -Encoding $Encoding
			}
			Write-Host "[INFO] All logs merged into $mergedFilePath" -ForegroundColor Green
		}

		Write-Host '[INFO] Process completed.' -ForegroundColor Green
	}
}

function Get-UALSpecificActivity
{
	<#
    .SYNOPSIS
        Gets specific activities from the unified audit log.
    .DESCRIPTION
        Makes it possible to extract a group of specific unified audit activities out of a Microsoft 365 environment.
        The output will be written to: Output\UnifiedAuditLog\
    .PARAMETER UserIds
        UserIds is the parameter filtering the log entries by the account of the user who performed the actions.
    .PARAMETER StartDate
        StartDate is the parameter specifying the start date of the date range. Default: Today -90 days.
    .PARAMETER EndDate
        EndDate is the parameter specifying the end date of the date range. Default: Now.
    .PARAMETER Interval
        Interval is the parameter specifying the interval in which the logs are being gathered. Default: 1440 minutes.
    .PARAMETER ActivityType
        The ActivityType parameter filters the log entries by operation or activity type.
    .PARAMETER Output
        Output is the parameter specifying the CSV or JSON output type. Default: CSV.
    .PARAMETER OutputDir
        OutputDir is the parameter specifying the output directory. Default: Output\UnifiedAuditLog.
    .PARAMETER Encoding
        Encoding is the parameter specifying the encoding of the CSV/JSON output file. Default: UTF8.
    .PARAMETER MergeOutput
        MergeOutput is the parameter specifying if you wish to merge CSV outputs to a single file. Default: No.
    .PARAMETER MaxRetries
        Specifies the maximum number of retries for failed requests. Default: 3.
    .EXAMPLE
        Get-UALSpecificActivity -ActivityType New-InboxRule
        Gets the New-InboxRule logging from the unified audit log.
    #>
	[CmdletBinding()]
	param (
		[datetime]$StartDate = (Get-Date).AddDays(-90),
		[datetime]$EndDate = (Get-Date),
		[string]$UserIds = "*",
		[int]$Interval = 1440,
		[Parameter(Mandatory = $true)][string]$ActivityType,
		[string]$Output = "CSV",
		[switch]$MergeOutput,
		[string]$OutputDir = "Output\UnifiedAuditLog",
		[string]$Encoding = "UTF8",
		[int]$MaxRetries = 3
	)

	begin
	{
		# Validate parameters
		if ([string]::IsNullOrWhiteSpace($ActivityType))
		{
			throw "ActivityType is required."
		}
		if ([string]::IsNullOrWhiteSpace($OutputDir))
		{
			$OutputDir = "Output\UnifiedAuditLog"
		}
		if ([string]::IsNullOrWhiteSpace($Encoding))
		{
			$Encoding = "UTF8"
		}
		if ($MaxRetries -le 0)
		{
			throw "MaxRetries must be greater than 0."
		}

		# Ensure the output directory exists
		if (-not (Test-Path -Path $OutputDir))
		{
			New-Item -ItemType Directory -Force -Path $OutputDir | Out-Null
		}

		Write-LogFile -Message "[INFO] Running Get-UALSpecificActivity" -Color "Green"
		Write-LogFile -Message "[INFO] Extracting all available audit logs between $($StartDate.ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ssK")) and $($EndDate.ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ssK"))"
		Write-LogFile -Message "[INFO] The following ActivityType(s) are configured to be extracted:"
		Write-LogFile -Message "-$ActivityType"
	}

	process
	{
		$currentDate = $StartDate

		while ($currentDate -lt $EndDate)
		{
			$currentEnd = $currentDate.AddMinutes($Interval)
			$retryCount = 0
			$success = $false

			$params = @{
				StartDate      = $currentDate
				EndDate        = $currentEnd
				Operations     = $ActivityType
				ResultSize     = 5000
				SessionCommand = "ReturnLargeSet"
			}

			if ($UserIds)
			{
				$params.UserIds = $UserIds.Split(",")
			}

			$outputFile = "$OutputDir/UAL-$($currentDate.ToString("yyyyMMddHHmmss"))-$ActivityType.$Output"

			while (-not $success -and $retryCount -lt $MaxRetries)
			{
				try
				{
					$results = @()
					$sessionId = [Guid]::NewGuid().ToString()
					$params.SessionId = $sessionId
					do
					{
						$result = Search-UnifiedAuditLog @params
						$results += $result
						$params.SessionCommand = "ReturnNextPreviewPage"
					} while ($result.Count -eq $ResultSize)

					if ($Output -eq "CSV")
					{
						$results | Export-Csv -Path $outputFile -NoTypeInformation -Encoding $Encoding
					}
					else
					{
						$results | ConvertTo-Json -Depth 100 | Out-File -FilePath $outputFile -Encoding $Encoding
					}

					Write-Host "[INFO] Audit logs written to $outputFile" -ForegroundColor Green
					$success = $true
				}
				catch
				{
					$retryCount++
					$delay = [math]::Pow(2, $retryCount)
					Write-Warning "Error fetching data for interval starting at $currentDate. Attempt $retryCount of $MaxRetries. Retrying in $delay seconds..."
					Start-Sleep -Seconds $delay
				}
			}

			if (-not $success)
			{
				Write-Error "Failed to fetch data for interval starting at $currentDate after $MaxRetries attempts." -ForegroundColor Red
			}

			$currentDate = $currentEnd
			[System.GC]::Collect()
			[System.GC]::WaitForPendingFinalizers()
		}
	}

	end
	{
		if ($MergeOutput)
		{
			Write-Host "[INFO] Merging output files into one file" -ForegroundColor Green
			$mergedFilePath = "$OutputDir\Merged\UAL-Combined.$Output"
			$allFiles = Get-ChildItem -Path $OutputDir -Filter "*.$Output" | Select-Object -ExpandProperty FullName
			if ($Output -eq "CSV")
			{
				Import-Csv -Path $allFiles | Export-Csv -Path $mergedFilePath -NoTypeInformation -Encoding $Encoding
			}
			else
			{
				Get-Content -Path $allFiles | Out-File -FilePath $mergedFilePath -Encoding $Encoding
			}
			Write-Host "[INFO] All logs merged into $mergedFilePath" -ForegroundColor Green
		}

		Write-Host '[INFO] Process completed.' -ForegroundColor Green
	}
}
