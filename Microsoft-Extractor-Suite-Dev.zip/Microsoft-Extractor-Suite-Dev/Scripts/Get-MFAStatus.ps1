function Get-MFA {
  <#
      .SYNOPSIS
      Retrieves the MFA status for all users.
  
      .DESCRIPTION
      Retrieves the MFA status for all users.
      The output will be written to: Output\UserInfo\
  
      .PARAMETER OutputDir
      OutputDir is the parameter specifying the output directory.
      Default: Output\UserInfo
  
      .PARAMETER Encoding
      Encoding is the parameter specifying the encoding of the CSV output file.
      Default: UTF8
  
      .PARAMETER Application
      Application is the parameter specifying App-only access (access without a user) for authentication and authorization.
      Default: Delegated access (access on behalf a user)
  
      .EXAMPLE
      Get-MFA
      Retrieves the MFA status for all users.
  
      .EXAMPLE
      Get-MFA
      Retrieves the MFA status for all users via application authentication.
  
      .EXAMPLE
      Get-MFA -Encoding utf32
      Retrieves the MFA status for all users and exports the output to a CSV file with UTF-32 encoding.
  
      .EXAMPLE
      Get-MFA -OutputDir C:\Windows\Temp
      Retrieves the MFA status for all users and saves the output to the C:\Windows\Temp folder.
  #>
      [CmdletBinding()]
      param(
          [string]$OutputDir = "Output\UserInfo",
          [string]$Encoding = "UTF8",
          [switch]$Application
      )
  
      # Ensure connection to Microsoft Graph
      if (-not $Application) {
          Connect-MgGraph -Scopes UserAuthenticationMethod.Read.All, User.Read.All -NoWelcome
      }
  
      try {
          $null = Get-MgUser -ErrorAction Stop
      } catch {
          Write-LogFile -Message "[WARNING] You must call Connect-MgGraph -Scopes 'UserAuthenticationMethod.Read.All, User.Read.All' before running this script" -Color "Red"
          return
      }
  
      # Ensure output directory exists
      if (-not (Test-Path -Path $OutputDir)) {
          New-Item -ItemType Directory -Force -Path $OutputDir | Out-Null
          Write-LogFile -Message "[INFO] Creating the following directory: $OutputDir"
      } elseif (-not (Test-Path -Path $OutputDir)) {
          Write-Error "[Error] Custom directory invalid: $OutputDir exiting script" -ErrorAction Stop
          Write-LogFile -Message "[Error] Custom directory invalid: $OutputDir exiting script"
          return
      }
  
      Write-LogFile -Message "[INFO] Running Get-MFA" -Color "Green"
      Write-LogFile -Message "[INFO] Identifying all the authentication methods utilized within the environment" -Color "Green"
  
      $users = Get-MgUser -All
  
      $results = @()
      foreach ($user in $users) {
          $myObject = [PSCustomObject]@{
              User                                   = $user.UserPrincipalName
              MFAStatus                              = "Disabled"
              Email                                  = $false
              Fido2                                  = $false
              App                                    = $false
              Password                               = $false
              Phone                                  = $false
              SoftwareOath                           = $false
              HelloBusiness                          = $false
              TemporaryAccessPass                    = $false
              CertificateBasedAuthConfiguration      = $false
          }
  
          try {
              $MFAData = Get-MgUserAuthenticationMethod -UserId $user.UserPrincipalName
              foreach ($method in $MFAData) {
                  switch ($method.AdditionalProperties["@odata.type"]) {
                      "#microsoft.graph.emailAuthenticationMethod" {
                          $myObject.Email = $true
                          $myObject.MFAStatus = "Enabled"
                      }
                      "#microsoft.graph.fido2AuthenticationMethod" {
                          $myObject.Fido2 = $true
                          $myObject.MFAStatus = "Enabled"
                      }
                      "#microsoft.graph.microsoftAuthenticatorAuthenticationMethod" {
                          $myObject.App = $true
                          $myObject.MFAStatus = "Enabled"
                      }
                      "#microsoft.graph.passwordAuthenticationMethod" {
                          $myObject.Password = $true
                      }
                      "#microsoft.graph.phoneAuthenticationMethod" {
                          $myObject.Phone = $true
                          $myObject.MFAStatus = "Enabled"
                      }
                      "#microsoft.graph.softwareOathAuthenticationMethod" {
                          $myObject.SoftwareOath = $true
                          $myObject.MFAStatus = "Enabled"
                      }
                      "#microsoft.graph.windowsHelloForBusinessAuthenticationMethod" {
                          $myObject.HelloBusiness = $true
                          $myObject.MFAStatus = "Enabled"
                      }
                      "#microsoft.graph.temporaryAccessPassAuthenticationMethod" {
                          $myObject.TemporaryAccessPass = $true
                          $myObject.MFAStatus = "Enabled"
                      }
                      "#microsoft.graph.certificateBasedAuthConfiguration" {
                          $myObject.CertificateBasedAuthConfiguration = $true
                          $myObject.MFAStatus = "Enabled"
                      }
                  }
              }
          } catch {
              Write-LogFile -Message "[ERROR] Error while retrieving the MFA status for $($user.UserPrincipalName) | Error: $_" -Color "Red"
          }
  
          $results += $myObject
      }
  
      $date = Get-Date -Format "yyyyMMddHHmm"
      $filePath = "$OutputDir\$date-MFA-AuthenticationMethods.csv"
      $results | Export-Csv -Path $filePath -NoTypeInformation -Encoding $Encoding
      Write-LogFile -Message "[INFO] Output written to $filePath" -Color "Green"
  
      # Count the number of users with each MFA method enabled
      $MFAEmail = ($results | Where-Object { $_.Email -eq $true }).Count
      $MFAFido2 = ($results | Where-Object { $_.Fido2 -eq $true }).Count
      $MFAApp = ($results | Where-Object { $_.App -eq $true }).Count
      $MFAPhone = ($results | Where-Object { $_.Phone -eq $true }).Count
      $MFASoftwareOath = ($results | Where-Object { $_.SoftwareOath -eq $true }).Count
      $MFAHelloBusiness = ($results | Where-Object { $_.HelloBusiness -eq $true }).Count
      $MFATemporaryAccessPass = ($results | Where-Object { $_.TemporaryAccessPass -eq $true }).Count
      $MFACertificateBasedAuth = ($results | Where-Object { $_.CertificateBasedAuthConfiguration -eq $true }).Count
      $MFAStatusEnabled = ($results | Where-Object { $_.MFAStatus -eq "Enabled" }).Count
  
      Write-Host "$MFAStatusEnabled out of $($users.Count) users have MFA enabled:"
      Write-Host "  - $MFAEmail x Email"
      Write-Host "  - $MFAFido2 x Fido2"
      Write-Host "  - $MFAApp x Microsoft Authenticator App"
      Write-Host "  - $MFAPhone x Phone"
      Write-Host "  - $MFASoftwareOath x Software OATH"
      Write-Host "  - $MFAHelloBusiness x Windows Hello for Business"
      Write-Host "  - $MFATemporaryAccessPass x Temporary Access Pass (TAP)"
      Write-Host "  - $MFACertificateBasedAuth x Certificate Based Authentication"
  
      Write-LogFile -Message "[INFO] Retrieving the user registration details" -Color "Green"
  
      $results = @()
      $filePath = "$OutputDir\$date-MFA-UserRegistrationDetails.csv"
  
      Get-MgReportAuthenticationMethodUserRegistrationDetail -All | ForEach-Object {
          $results += [PSCustomObject]@{
              Id = $_.Id
              IsAdmin = $_.IsAdmin
              IsMfaCapable = $_.IsMfaCapable
              IsMfaRegistered = $_.IsMfaRegistered
              IsPasswordlessCapable = $_.IsPasswordlessCapable
              IsSsprCapable = $_.IsSsprCapable
              IsSsprEnabled = $_.IsSsprEnabled
              IsSsprRegistered = $_.IsSsprRegistered
              IsSystemPreferredAuthenticationMethodEnabled = $_.IsSystemPreferredAuthenticationMethodEnabled
              MethodsRegistered = $_.MethodsRegistered -join ', '
              SystemPreferredAuthenticationMethods = $_.SystemPreferredAuthenticationMethods -join ', '
              UserDisplayName = $_.UserDisplayName
              UserPreferredMethodForSecondaryAuthentication = $_.UserPreferredMethodForSecondaryAuthentication
              UserPrincipalName = $_.UserPrincipalName
              UserType = $_.UserType
              AdditionalProperties = $_.AdditionalProperties -join ', '
          }
      }
  
      $results | Export-Csv -Path $filePath -NoTypeInformation -Encoding $Encoding
      Write-LogFile -Message "[INFO] Output written to $filePath" -Color "Green"
  }
  