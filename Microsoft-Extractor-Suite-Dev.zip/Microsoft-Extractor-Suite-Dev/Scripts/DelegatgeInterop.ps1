function Get-ADSignInLogsGraph
{
    param (
        [switch]$IsApplication
    )

    if ($IsApplication)
    {
        Invoke-Interop -IsApplication
        # some function to validate $env:appID,$env:appSecret,$env:appThumbprint,$env:tenantID [Unsure how to approach this at the moment.]
        $token = Get-Token -scope 'https://graph.microsoft.com/.default'# msgraph | exchangeonline | az
    }

    # This block of headers can be used with the PS Invoke-MgGraphRequest Cmdlet - just make sure if headers is specified , it does not include authorization
    $Headers = @{
        'request-id'       = [GUID]::NewGuid()
        'ConsistencyLevel' = 'eventual'
    }

    if ($token -and $IsApplication)
    {
        $Headers.Add("Authorization", "Bearer $token")
    }

    $response = Invoke-MgGraphRequest -Method Get -Uri 'https://graph.microsoft.com/beta/users' -ContentType 'application/json' -Headers $Headers

    $Output = [pscustomobject]@{
        response = $response;
        headers  = $Headers;
    }

    
    return $Output
}

function Get-Token
{
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [ValidateSet('https://graph.microsoft.com/.default', 'https://outlook.office365.com/.default')]
        [string]$Scope,

        [Parameter(Mandatory = $false)]
        [string]$AppId,

        [Parameter(Mandatory = $false)]
        [string]$AppSecret,

        [Parameter(Mandatory = $false)]
        [string]$TenantId
    )
    begin
    {
        $body = @{
            Grant_Type    = 'client_credentials'
            Client_Id     = $env:AppId
            Client_Secret = $env:AppSecret
            Scope         = $Scope
        }
    }
    process
    {
        $response = Invoke-RestMethod -Uri "https://login.microsoftonline.com/$env:TenantId/oauth2/v2.0/token" -Method Post -Body $body
    }
    end
    {
        $response.access_token
    }
}
function Invoke-Interop
{
    param (
        [switch]$IsApplication
    )
    begin
    {
        $Local:Object = [pscustomobject]@{
            success = $false;
            res     = ' ';
            out     = ' ';
        }
        # Verify if all required parameters are provided and valid
        if (-not $IsApplication)
        {
            Write-Error "IsApplication switch is required."
            return
        }

    }
    process
    {
        try
        {
            if ($IsApplication)
            {
                if ((Get-Alias -Name Invoke-MgGraphRequest -ErrorAction Stop).Definition -eq "Invoke-RestMethod")
                {
                    Write-Warning "Constant Alias already configured - continuing"
                    $out = Write-Output "Alias set successfully.  - Alias Definition: `(Get-Alias -Name Invoke-MgGraphRequest).Definition == " (Get-Alias -Name Invoke-MgGraphRequest).Definition
                    $Local:Object.success = $true
                    $Local:Object.out = $out
                    $out
                }
                else
                {
                    New-Alias -Name Invoke-MgGraphRequest -Value Invoke-RestMethod -Force 
                    $out = Write-Output "Alias set successfully.  - Alias Definition: `(Get-Alias -Name Invoke-MgGraphRequest).Definition == " (Get-Alias -Name Invoke-MgGraphRequest).Definition
                    $Local:Object.success = $true
                    $out = Write-Output "Alias set successfully.  - Alias Definition: `(Get-Alias -Name Invoke-MgGraphRequest).Definition == " (Get-Alias -Name Invoke-MgGraphRequest).Definition
                    $Local:Object.out = $out
                }
            }
        } 
        catch
        {
            Write-Warning "Failed to create alias using New-Alias. Attempting to set alias using Set-Alias."
            try
            {
                try
                {
                    Set-Alias -Name Invoke-MgGraphRequest -Value Invoke-RestMethod -Force 
                    $out = Write-Output "Alias set successfully.  - Alias Definition: `(Get-Alias -Name Invoke-MgGraphRequest).Definition == " (Get-Alias -Name Invoke-MgGraphRequest).Definition
                }
                catch
                {
                    Write-Warning "Constant Alias already configured - continuing"
                    $out = Write-Output "Alias set successfully.  - Alias Definition: `(Get-Alias -Name Invoke-MgGraphRequest).Definition == " (Get-Alias -Name Invoke-MgGraphRequest).Definition
                    $Local:Object.success = $true
                    $Local:Object.out = $out
                    break
                }
            }
            catch
            {
                Write-Error "Failed to set alias using New-Alias & Set-Alias. Terminating exception occurred."
                $Local:Object.debug = $_.Exception
                $Local:Object.success = $false
            }
        }
    }
}
