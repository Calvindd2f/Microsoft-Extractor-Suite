function Get-RiskyUsers
{
    <#
    .SYNOPSIS
    Retrieves the risky users via API calls.

    .DESCRIPTION
    Retrieves the risky users from the Entra ID Identity Protection, which marks an account as being at risk based on the pattern of activity for the account.
    The output will be written to: Output\UserInfo\

    .PARAMETER OutputDir
    OutputDir is the parameter specifying the output directory.
    Default: Output\UserInfo

    .PARAMETER Encoding
    Encoding is the parameter specifying the encoding of the CSV output file.
    Default: UTF8

    .PARAMETER Token
    Token is the parameter specifying the API token for authentication.

    .PARAMETER MaxRetries
    Specifies the maximum number of retries for failed requests. Default: 3.

    .EXAMPLE
    Get-RiskyUsers -Token $token
    Retrieves all risky users.

    .EXAMPLE
    Get-RiskyUsers -Token $token -Encoding utf32
    Retrieves all risky users and exports the output to a CSV file with UTF-32 encoding.

    .EXAMPLE
    Get-RiskyUsers -Token $token -OutputDir C:\Windows\Temp
    Retrieves all risky users and saves the output to the C:\Windows\Temp folder.
    #>
    [CmdletBinding()]
    param(
        [string]$OutputDir = "Output\UserInfo",
        [string]$Encoding = "UTF8",
        [Parameter(Mandatory = $true)][string]$Token,
        [int]$MaxRetries = 3
    )

    begin
    {
        # Validate parameters
        if ([string]::IsNullOrWhiteSpace($OutputDir))
        {
            $OutputDir = "Output\UserInfo"
        }
        if ([string]::IsNullOrWhiteSpace($Encoding))
        {
            $Encoding = "UTF8"
        }
        if ($MaxRetries -le 0)
        {
            throw "MaxRetries must be greater than 0."
        }

        # Ensure the output directory exists
        if (-not (Test-Path -Path $OutputDir))
        {
            New-Item -ItemType Directory -Force -Path $OutputDir | Out-Null
        }

        Write-LogFile -Message "[INFO] Running Get-RiskyUsers" -Color "Green"
        $results = @()
        $count = 0
        $retryCount = 0
        $success = $false
        $url = "https://graph.microsoft.com/v1.0/riskyUsers"
    }

    process
    {
        while (-not $success -and $retryCount -lt $MaxRetries)
        {
            try
            {
                $response = Invoke-MgGraphRequest -Method GET -Uri $url -Headers @{Authorization = "Bearer $Token" } -ContentType "application/json"
                Write-LogFile -Message "[INFO] Successfully retrieved risky users." -Color "Green"
                $success = $true

                foreach ($user in $response.value)
                {
                    $results += [PSCustomObject]@{
                        History                 = $user.History
                        Id                      = $user.Id
                        IsDeleted               = $user.IsDeleted
                        IsProcessing            = $user.IsProcessing
                        RiskDetail              = $user.RiskDetail
                        RiskLastUpdatedDateTime = $user.RiskLastUpdatedDateTime
                        RiskLevel               = $user.RiskLevel
                        RiskState               = $user.RiskState
                        UserDisplayName         = $user.UserDisplayName
                        UserPrincipalName       = $user.UserPrincipalName
                        AdditionalProperties    = $user.AdditionalProperties | Out-String
                    }
                    $count++
                }
            }
            catch
            {
                $retryCount++
                $delay = [math]::Pow(2, $retryCount)
                Write-Warning "Error retrieving risky users. Attempt $retryCount of $MaxRetries. Retrying in $delay seconds..."
                Start-Sleep -Seconds $delay
            }
        }

        if (-not $success)
        {
            Write-Error "Failed to retrieve risky users after $MaxRetries attempts." -ForegroundColor Red
        }
        else
        {
            $date = Get-Date -Format "yyyyMMddHHmm"
            $filePath = "$OutputDir\$($date)-RiskyUsers.csv"
            $results | Export-Csv -Path $filePath -NoTypeInformation -Encoding $Encoding
            Write-LogFile -Message "[INFO] A total of $count Risky Users found"
            Write-LogFile -Message "[INFO] Output written to $filePath" -Color "Green"
        }
    }

    end
    {
        Write-Host '[INFO] Process completed.' -ForegroundColor Green
    }
}


function Get-RiskyDetections
{
    <#
    .SYNOPSIS
    Retrieves the risky detections via API calls.

    .DESCRIPTION
    Retrieves the risky detections from the Entra ID Identity Protection.
    The output will be written to: Output\UserInfo\

    .PARAMETER OutputDir
    OutputDir is the parameter specifying the output directory.
    Default: Output\UserInfo

    .PARAMETER Encoding
    Encoding is the parameter specifying the encoding of the CSV output file.
    Default: UTF8

    .PARAMETER Token
    Token is the parameter specifying the API token for authentication.

    .PARAMETER MaxRetries
    Specifies the maximum number of retries for failed requests. Default: 3.

    .EXAMPLE
    Get-RiskyDetections -Token $token
    Retrieves all risky detections.

    .EXAMPLE
    Get-RiskyDetections -Token $token -Encoding utf32
    Retrieves the risky detections and exports the output to a CSV file with UTF-32 encoding.

    .EXAMPLE
    Get-RiskyDetections -Token $token -OutputDir C:\Windows\Temp
    Retrieves the risky detections and saves the output to the C:\Windows\Temp folder.
    #>
    [CmdletBinding()]
    param(
        [string]$OutputDir = "Output\UserInfo",
        [string]$Encoding = "UTF8",
        [Parameter(Mandatory = $true)][string]$Token,
        [int]$MaxRetries = 3
    )

    begin
    {
        # Validate parameters
        if ([string]::IsNullOrWhiteSpace($OutputDir))
        {
            $OutputDir = "Output\UserInfo"
        }
        if ([string]::IsNullOrWhiteSpace($Encoding))
        {
            $Encoding = "UTF8"
        }
        if ($MaxRetries -le 0)
        {
            throw "MaxRetries must be greater than 0."
        }

        # Ensure the output directory exists
        if (-not (Test-Path -Path $OutputDir))
        {
            New-Item -ItemType Directory -Force -Path $OutputDir | Out-Null
        }

        Write-LogFile -Message "[INFO] Running Get-RiskyDetections" -Color "Green"
        $results = @()
        $count = 0
        $retryCount = 0
        $success = $false
        $url = "https://graph.microsoft.com/v1.0/riskDetections"
    }

    process
    {
        while (-not $success -and $retryCount -lt $MaxRetries)
        {
            try
            {
                $response = Invoke-MgGraphRequest -Method GET -Uri $url -Headers @{Authorization = "Bearer $Token" } -ContentType "application/json"
                Write-LogFile -Message "[INFO] Successfully retrieved risky detections." -Color "Green"
                $success = $true

                foreach ($detection in $response.value)
                {
                    $results += [PSCustomObject]@{
                        Activity             = $detection.Activity
                        ActivityDateTime     = $detection.ActivityDateTime
                        AdditionalInfo       = $detection.AdditionalInfo
                        CorrelationId        = $detection.CorrelationId
                        DetectedDateTime     = $detection.DetectedDateTime
                        IPAddress            = $detection.IPAddress
                        Id                   = $detection.Id
                        LastUpdatedDateTime  = $detection.LastUpdatedDateTime
                        City                 = $detection.Location.City | Out-String
                        CountryOrRegion      = $detection.Location.CountryOrRegion | Out-String
                        State                = $detection.Location.State | Out-String
                        RequestId            = $detection.RequestId
                        RiskDetail           = $detection.RiskDetail
                        RiskEventType        = $detection.RiskEventType
                        RiskLevel            = $detection.RiskLevel
                        RiskState            = $detection.RiskState
                        DetectionTimingType  = $detection.DetectionTimingType
                        Source               = $detection.Source
                        TokenIssuerType      = $detection.TokenIssuerType
                        UserDisplayName      = $detection.UserDisplayName
                        UserId               = $detection.UserId
                        UserPrincipalName    = $detection.UserPrincipalName
                        AdditionalProperties = $detection.AdditionalProperties | Out-String
                    }
                    $count++
                }
            }
            catch
            {
                $retryCount++
                $delay = [math]::Pow(2, $retryCount)
                Write-Warning "Error retrieving risky detections. Attempt $retryCount of $MaxRetries. Retrying in $delay seconds..."
                Start-Sleep -Seconds $delay
            }
        }

        if (-not $success)
        {
            Write-Error "Failed to retrieve risky detections after $MaxRetries attempts." -ForegroundColor Red
        }
        else
        {
            $date = Get-Date -Format "yyyyMMddHHmm"
            $filePath = "$OutputDir\$($date)-RiskyDetections.csv"
            $results | Export-Csv -Path $filePath -NoTypeInformation -Encoding $Encoding
            Write-LogFile -Message "[INFO] A total of $count Risky Detections found"
            Write-LogFile -Message "[INFO] Output written to $filePath" -Color "Green"
        }
    }

    end
    {
        Write-Host '[INFO] Process completed.' -ForegroundColor Green
    }
}
