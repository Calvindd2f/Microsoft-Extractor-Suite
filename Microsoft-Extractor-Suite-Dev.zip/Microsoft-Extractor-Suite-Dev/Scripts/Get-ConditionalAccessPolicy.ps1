function Get-ConditionalAccessPolicies {
    <#
        .SYNOPSIS
        Retrieves all the conditional access policies. 
    
        .DESCRIPTION
        Retrieves the risky users from the Entra ID Identity Protection, which marks an account as being at risk based on the pattern of activity for the account.
        The output will be written to: Output\UserInfo\
    
        .PARAMETER OutputDir
        OutputDir is the parameter specifying the output directory.
        Default: Output\UserInfo
    
        .PARAMETER Encoding
        Encoding is the parameter specifying the encoding of the CSV output file.
        Default: UTF8
    
        .PARAMETER Application
        Application is the parameter specifying App-only access (access without a user) for authentication and authorization.
        Default: Delegated access (access on behalf a user)
        
        .EXAMPLE
        Get-ConditionalAccessPolicies
        Retrieves all the conditional access policies.
    
        .EXAMPLE
        Get-ConditionalAccessPolicies -Application
        Retrieves all the conditional access policies via application authentication.
        
        .EXAMPLE
        Get-ConditionalAccessPolicies -Encoding utf32
        Retrieves all the conditional access policies and exports the output to a CSV file with UTF-32 encoding.
            
        .EXAMPLE
        Get-ConditionalAccessPolicies -OutputDir C:\Windows\Temp
        Retrieves all the conditional access policies and saves the output to the C:\Windows\Temp folder.	
    #>
        [CmdletBinding()]
        param(
            [string]$OutputDir = "Output\UserInfo",
            [string]$Encoding = "UTF8",
            [switch]$Application,
            [int]$MaxRetries = 3
        )
    
        begin {
            if ([string]::IsNullOrWhiteSpace($OutputDir)) {
                $OutputDir = "Output\UserInfo"
            }
    
            if (-not (Test-Path -Path $OutputDir)) {
                New-Item -ItemType Directory -Force -Path $OutputDir | Out-Null
            }
    
            if ([string]::IsNullOrWhiteSpace($Encoding)) {
                $Encoding = "UTF8"
            }
    
            if ($MaxRetries -le 0) {
                throw "MaxRetries must be greater than 0."
            }
    
            Write-LogFile -Message "[INFO] Starting Get-ConditionalAccessPolicies" -Color "Green"
    
            if (-not $Application) {
                Connect-MgGraph -Scopes "Policy.Read.All" -NoWelcome
            }
        }
    
        process {
            $retryCount = 0
            $success = $false
            $results = @()
    
            do {
                while (-not $success -and $retryCount -lt $MaxRetries) {
                    try {
                        $response = Get-MgIdentityConditionalAccessPolicy -All -ErrorAction Stop
    
                        if ($response -eq $null -or $response.Count -eq 0) {
                            Write-LogFile -Message "[INFO] No conditional access policies found. Checking if security defaults are enabled." -Color "Yellow"
    
                            $securityDefaults = Invoke-MgGraphRequest -Method Get -Uri "https://graph.microsoft.com/v1.0/policies/identitySecurityDefaultsEnforcementPolicy"
                            if ($securityDefaults.enabled -eq $true) {
                                Write-LogFile -Message "[INFO] Security defaults are enabled." -Color "Green"
                            } else {
                                Write-LogFile -Message "[INFO] Security defaults are disabled." -Color "Yellow"
                            }
                            break
                        }
    
                        $response | ForEach-Object {
                            $results += [PSCustomObject]@{
                                DisplayName                   = $_.DisplayName
                                CreatedDateTime               = $_.CreatedDateTime
                                Description                   = $_.Description
                                Id                            = $_.Id
                                ModifiedDateTime              = $_.ModifiedDateTime
                                State                         = $_.State
                                ClientAppTypes                = ($_.Conditions.ClientAppTypes -join ',')
                                ServicePrincipalRiskLevels    = ($_.Conditions.ServicePrincipalRiskLevels -join ',')
                                SignInRiskLevels              = ($_.Conditions.SignInRiskLevels -join ',')
                                UserRiskLevels                = ($_.Conditions.UserRiskLevels -join ',')
                                BuiltInControls               = ($_.GrantControls.BuiltInControls -join ',')
                                CustomAuthenticationFactors   = ($_.GrantControls.CustomAuthenticationFactors -join ',')
                                ClientOperatorAppTypes        = $_.GrantControls.Operator
                                TermsOfUse                    = ($_.GrantControls.TermsOfUse -join ',')
                                DisableResilienceDefaults     = $_.SessionControls.DisableResilienceDefaults
                            }
                        }
    
                        $success = $true
                    } catch {
                        $retryCount++
                        $delay = [math]::Pow(2, $retryCount)
                        Write-Warning "Error fetching data: $_. Attempt $retryCount of $MaxRetries. Retrying in $delay seconds..."
                        Start-Sleep -Seconds $delay
                    }
                }
    
                if (-not $success) {
                    Write-Error "Failed to retrieve conditional access policies after $MaxRetries attempts."
                }
            } while (-not $success -and $retryCount -lt $MaxRetries)
        }
    
        end {
            if ($results.Count -gt 0) {
                $date = Get-Date -Format "yyyyMMddHHmmss"
                $filePath = Join-Path -Path $OutputDir -ChildPath "$($date)-ConditionalAccessPolicies.csv"
                $results | Export-Csv -Path $filePath -NoTypeInformation -Encoding $Encoding
                Write-LogFile -Message "[INFO] Output written to $filePath" -Color "Green"
            }
            Write-LogFile -Message '[INFO] Process completed.' -Color "Green"
        }
    }
    