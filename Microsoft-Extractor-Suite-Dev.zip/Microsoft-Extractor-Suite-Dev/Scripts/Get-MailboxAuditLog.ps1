# This contains a function for getting Mailbox Audit logging

function Get-MailboxAuditLog
{
<#
    .SYNOPSIS
    Get mailbox audit log entries.

    .DESCRIPTION
    Get mailbox audit log entries for specific user accounts.
    The output will be written to: Output\MailboxAuditLog\

    .PARAMETER UserIds
    UserIds is the Identity parameter specifying one or more mailboxes to retrieve mailbox audit log entries from.

    .PARAMETER StartDate
    StartDate is the parameter specifying the start date of the date range.

    .PARAMETER EndDate
    EndDate is the parameter specifying the end date of the date range.

    .PARAMETER OutputDir
    OutputDir is the parameter specifying the output directory.
    Default: Output\MailboxAuditLog

    .PARAMETER Encoding
    Encoding is the parameter specifying the encoding of the CSV output file.
    Default: UTF8

    .EXAMPLE
    Get-MailboxAuditLog
    Get all available mailbox audit log entries for all user accounts.

    .EXAMPLE
    Get-MailboxAuditLog -UserIds Test@invictus-ir.com
    Get mailbox audit log entries for the user Test@invictus-ir.com.

    .EXAMPLE
    Get-MailboxAuditLog -UserIds "Test@invictus-ir.com,HR@invictus-ir.com"
    Get mailbox audit log entries for the users Test@invictus-ir.com and HR@invictus-ir.com.

    .EXAMPLE
    Get-MailboxAuditLog -UserIds Test@invictus-ir.com -StartDate 1/4/2023 -EndDate 5/4/2023
    Get mailbox audit log entries for the user Test@invictus-ir.com between 1/4/2023 and 5/4/2023.
#>
    [CmdletBinding()]
    param(
        [string]$UserIds,
        [string]$StartDate,
        [string]$EndDate,
        [string]$OutputDir = "Output\MailboxAuditLog",
        [string]$Encoding = "UTF8",
        [int]$MaxRetries = 3
    )

    begin {
        if (-not (Test-Path -Path $OutputDir)) {
            Write-LogFile -Message "[INFO] Creating the directory: $OutputDir" -Color "Green"
            New-Item -ItemType Directory -Force -Path $OutputDir | Out-Null
        }

        Write-LogFile -Message "[INFO] Starting Get-MailboxAuditLog" -Color "Green"

        if (-not (Get-MgContext)) {
            Connect-MgGraph -Scopes "MailboxSettings.Read" -NoWelcome
        }
    }

    process {
        $retryCount = 0
        $success = $false

        while (-not $success -and $retryCount -lt $MaxRetries) {
            try {
                if (-not $UserIds) {
                    Write-LogFile -Message "[INFO] No users provided.. Getting the MailboxAuditLog for all users" -Color "Yellow"
                    Get-Mailbox -ResultSize Unlimited | ForEach-Object {
                        $currentRetry = 0
                        $currentSuccess = $false

                        while (-not $currentSuccess -and $currentRetry -lt $MaxRetries) {
                            try {
                                $date = Get-Date -Format "yyyyMMddHHmm"
                                $outputFile = "$OutputDir\$($date)-mailboxAuditLog-$($_.UserPrincipalName).csv"
                                Write-LogFile -Message "[INFO] Collecting the MailboxAuditLog for $($_.UserPrincipalName)"
                                $result = Search-MailboxAuditLog -Identity $_.UserPrincipalName -LogonTypes Delegate,Admin,Owner -StartDate $StartDate -EndDate $EndDate -ShowDetails -ResultSize 250000
                                $result | Export-Csv -NoTypeInformation -Path $outputFile -Encoding $Encoding
                                Write-LogFile -Message "[INFO] Output written to: $outputFile" -Color "Green"
                                $currentSuccess = $true
                            } catch {
                                $currentRetry++
                                $delay = [math]::Pow(2, $currentRetry)
                                Write-LogFile -Message "[WARNING] Error fetching data for $($_.UserPrincipalName): $_. Attempt $currentRetry of $MaxRetries. Retrying in $delay seconds..." -Color "Yellow"
                                Start-Sleep -Seconds $delay
                            }
                        }

                        if (-not $currentSuccess) {
                            Write-LogFile -Message "[ERROR] Failed to retrieve mailbox audit log for $($_.UserPrincipalName) after $MaxRetries attempts." -Color "Red"
                        }
                    }
                } elseif ($UserIds -match ",") {
                    $UserIds.Split(",") | ForEach-Object {
                        $user = $_
                        $currentRetry = 0
                        $currentSuccess = $false

                        while (-not $currentSuccess -and $currentRetry -lt $MaxRetries) {
                            try {
                                $date = Get-Date -Format "yyyyMMddHHmm"
                                $outputFile = "$OutputDir\$($date)-mailboxAuditLog-$($user).csv"
                                Write-LogFile -Message "[INFO] Collecting the MailboxAuditLog for $user"
                                $result = Search-MailboxAuditLog -Identity $user -LogonTypes Delegate,Admin,Owner -StartDate $StartDate -EndDate $EndDate -ShowDetails -ResultSize 250000
                                $result | Export-Csv -NoTypeInformation -Path $outputFile -Encoding $Encoding
                                Write-LogFile -Message "[INFO] Output written to: $outputFile" -Color "Green"
                                $currentSuccess = $true
                            } catch {
                                $currentRetry++
                                $delay = [math]::Pow(2, $currentRetry)
                                Write-LogFile -Message "[WARNING] Error fetching data for $user: $_. Attempt $currentRetry of $MaxRetries. Retrying in $delay seconds..." -Color "Yellow"
                                Start-Sleep -Seconds $delay
                            }
                        }

                        if (-not $currentSuccess) {
                            Write-LogFile -Message "[ERROR] Failed to retrieve mailbox audit log for $user after $MaxRetries attempts." -Color "Red"
                        }
                    }
                } else {
                    $date = Get-Date -Format "yyyyMMddHHmm"
                    $outputFile = "$OutputDir\$($date)-mailboxAuditLog-$($UserIds).csv"
                    $currentRetry = 0
                    $currentSuccess = $false

                    while (-not $currentSuccess -and $currentRetry -lt $MaxRetries) {
                        try {
                            Write-LogFile -Message "[INFO] Collecting the MailboxAuditLog for $UserIds"
                            $result = Search-MailboxAuditLog -Identity $UserIds -LogonTypes Delegate,Admin,Owner -StartDate $StartDate -EndDate $EndDate -ShowDetails -ResultSize 250000
                            $result | Export-Csv -NoTypeInformation -Path $outputFile -Encoding $Encoding
                            Write-LogFile -Message "[INFO] Output written to: $outputFile" -Color "Green"
                            $currentSuccess = $true
                        } catch {
                            $currentRetry++
                            $delay = [math]::Pow(2, $currentRetry)
                            Write-LogFile -Message "[WARNING] Error fetching data for $UserIds: $_. Attempt $currentRetry of $MaxRetries. Retrying in $delay seconds..." -Color "Yellow"
                            Start-Sleep -Seconds $delay
                        }
                    }

                    if (-not $currentSuccess) {
                        Write-LogFile -Message "[ERROR] Failed to retrieve mailbox audit log for $UserIds after $MaxRetries attempts." -Color "Red"
                    }
                }

                $success = $true
            } catch {
                $retryCount++
                $delay = [math]::Pow(2, $retryCount)
                Write-LogFile -Message "[WARNING] Error fetching data: $_. Attempt $retryCount of $MaxRetries. Retrying in $delay seconds..." -Color "Yellow"
                Start-Sleep -Seconds $delay
            }
        }

        if (-not $success) {
            Write-LogFile -Message "[ERROR] Failed to retrieve mailbox audit log after $MaxRetries attempts." -Color "Red"
        }
    }
}
