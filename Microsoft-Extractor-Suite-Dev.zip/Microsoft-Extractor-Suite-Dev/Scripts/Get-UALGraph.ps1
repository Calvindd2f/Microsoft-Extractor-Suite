<#
    Pending Application Interop
#>

function Get-UnifiedAuditLogGraph
{
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)][string]$SearchName,
        [switch]$Application,
        [string]$OutputDir = "Output\UnifiedAuditLog",
        [string]$Encoding = "UTF8",
        [string]$StartDate,
        [string]$EndDate,
        [string[]]$RecordTypes = @(),
        [string]$Keyword = "",
        [string]$Service = "",
        [string[]]$Operations = @(),
        [string[]]$UserIds = @(),
        [string[]]$IPAddresses = @(),
        [string]$OutFormat = "CSV",
        [string]$OutEncoding = "UTF8",
        [AllowNull()][int]$Interval = 15,
        [switch]$MergeOutput,
        [int]$MaxRetries = 3
    )

    begin
    {
        # Validate parameters
        if ([string]::IsNullOrWhiteSpace($OutputDir))
        {
            $OutputDir = "Output\UnifiedAuditLog"
        }
        if ([string]::IsNullOrWhiteSpace($Encoding))
        {
            $Encoding = "UTF8"
        }
        if ($MaxRetries -le 0)
        {
            throw "MaxRetries must be greater than 0."
        }

        # Ensure the output directory exists
        if (-not (Test-Path -Path $OutputDir))
        {
            New-Item -ItemType Directory -Force -Path $OutputDir | Out-Null
        }

        Write-LogFile -Message "[INFO] Running Get-UnifiedAuditLogGraph" -Color "Green"

        $StartDate = if ($StartDate) { [DateTime]::Parse($StartDate) } else { [DateTime]::Today.AddDays(-90) }
        $EndDate = if ($EndDate) { [DateTime]::Parse($EndDate) } else { [DateTime]::Now }

        $params = @{
            "@odata.type"            = "#microsoft.graph.security.auditLogQuery"
            DisplayName              = $SearchName
            FilterStartDateTime      = $StartDate
            FilterEndDateTime        = $EndDate
            RecordTypeFilters        = $RecordTypes
            KeywordFilter            = $Keyword
            ServiceFilter            = $Service
            OperationFilters         = $Operations
            UserPrincipalNameFilters = $UserIds
            IPAddressFilters         = $IPAddresses
        }

        $queryString = $params | ConvertTo-Json -Compress

        if (!($Application.IsPresent))
        {
            Connect-MgGraph -Scopes "AuditLogsQuery.Read.All" -NoWelcome
        }
    }

    process
    {
        $retryCount = 0
        $success = $false

        while (-not $success -and $retryCount -lt $MaxRetries)
        {
            try
            {
                $auditLogQuery = Invoke-MgGraphRequest -Method POST -Uri "beta/security/auditLogs/queries" -Body $queryString
                $scanId = $auditLogQuery.Id
                $success = $true
            }
            catch
            {
                $retryCount++
                $delay = [math]::Pow(2, $retryCount)
                Write-Warning "Error initiating audit log query. Attempt $retryCount of $MaxRetries. Retrying in $delay seconds..."
                Start-Sleep -Seconds $delay
            }
        }

        if (-not $success)
        {
            Write-Error "Failed to initiate audit log query after $MaxRetries attempts." -ForegroundColor Red
            return
        }

        $retryCount = 0
        $success = $false

        while (-not $success -and $retryCount -lt $MaxRetries)
        {
            try
            {
                do
                {
                    $auditLogQuery = Invoke-MgGraphRequest -Method GET -Uri "beta/security/auditLogs/queries/$scanId"

                    if ($auditLogQuery.Status -eq "running")
                    {
                        Start-Sleep -Seconds 10
                    }
                    elseif ($auditLogQuery.Status -eq "failed")
                    {
                        throw "Unified Audit Log search failed."
                    }
                    elseif ($auditLogQuery.Status -eq "succeeded")
                    {
                        $customObjects = Fetch-AuditLogRecordsGraph -ScanId $scanId -Encoding $Encoding -OutputDir $OutputDir
                        $date = Get-Date -Format "yyyyMMddHHmm"
                        $filePath = "$OutputDir\$($date)-$SearchName-UnifiedAuditLog.json"
                        $customObjects | ConvertTo-Json -Depth 100 | Out-File -FilePath $filePath -Encoding $Encoding
                        Write-LogFile -Message "[INFO] Unified Audit Log search succeeded. Output written to $filePath" -Color "Green"
                        $success = $true
                    }
                    else
                    {
                        Start-Sleep -Seconds 10
                    }
                } while ($auditLogQuery.Status -eq "running" -and $retryCount -lt $MaxRetries)
            }
            catch
            {
                $retryCount++
                $delay = [math]::Pow(2, $retryCount)
                Write-Warning "Error fetching audit log results. Attempt $retryCount of $MaxRetries. Retrying in $delay seconds..."
                Start-Sleep -Seconds $delay
            }
        }

        if (-not $success)
        {
            Write-Error "Failed to fetch audit log results after $MaxRetries attempts." -ForegroundColor Red
        }
    }

    end
    {
        Write-Host '[INFO] Process completed.' -ForegroundColor Green
    }
}

function Fetch-AuditLogRecordsGraph
{
    param (
        [Parameter(Mandatory = $true)][string]$ScanId,
        [Parameter(Mandatory = $true)][string]$Encoding,
        [Parameter(Mandatory = $true)][string]$OutputDir
    )

    $customObjects = @()
    $pageSize = 1000
    $nextLink = "beta/security/auditLogs/queries/$ScanId/results?`$top=$pageSize"

    do
    {
        $response = Invoke-MgGraphRequest -Method GET -Uri $nextLink
        $customObjects += $response.Value | ForEach-Object {
            [PSCustomObject]@{
                AdministrativeUnits  = $_.AdministrativeUnits
                AuditData            = $_.AuditData
                AuditLogRecordType   = $_.AuditLogRecordType
                ClientIP             = $_.ClientIP
                CreatedDateTime      = $_.CreatedDateTime
                Id                   = $_.Id
                ObjectId             = $_.ObjectId
                Operation            = $_.Operation
                OrganizationId       = $_.OrganizationId
                Service              = $_.Service
                UserId               = $_.UserId
                UserPrincipalName    = $_.UserPrincipalName
                UserType             = $_.UserType
                AdditionalProperties = $_.AdditionalProperties
            }
        }

        if ($response.'@odata.nextLink')
        {
            $nextLink = $response.'@odata.nextLink'
        }
        else
        {
            $nextLink = $null
        }
    } while ($nextLink)

    return $customObjects
}
