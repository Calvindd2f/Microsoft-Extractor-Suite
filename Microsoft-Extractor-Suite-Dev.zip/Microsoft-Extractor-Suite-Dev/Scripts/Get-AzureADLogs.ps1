# This contains functions for getting Azure AD logging

function Get-ADSignInLogs {
	<#
    .SYNOPSIS
    Get sign-in logs.

    .DESCRIPTION
    The Get-ADSignInLogs cmdlet collects the contents of the Azure Active Directory sign-in logs.
	The output will be written to: Output\AzureAD\SignInLogs.json

	.PARAMETER startDate
	The startDate parameter specifies the date from which all logs need to be collected.

	.PARAMETER endDate
    The Before parameter specifies the date endDate which all logs need to be collected.

	.PARAMETER OutputDir
    OutputDir is the parameter specifying the output directory.
	Default: Output\AzureAD

	.PARAMETER Encoding
    Encoding is the parameter specifying the encoding of the JSON output file.
	Default: UTF8

	.PARAMETER MergeOutput
    MergeOutput is the parameter specifying if you wish to merge outputs to a single file
    Default: No

	.PARAMETER UserIds
    UserIds is the UserIds parameter filtering the log entries by the account of the user who performed the actions.
    
    .EXAMPLE
    Get-ADSignInLogs
	Get all sign-in logs.

    .EXAMPLE
    Get-ADAuditLogs -UserIds Test@invictus-ir.com
    Get sign-in logs for the user Test@invictus-ir.com.

	.EXAMPLE
    Get-ADSignInLogs -endDate 2023-04-12
	Get sign-in logs before 2023-04-12.

	.EXAMPLE
    Get-ADSignInLogs -startDate 2023-04-12
	Get sign-in logs after 2023-04-12.
#>
	[CmdletBinding()]
	param(
		[datetime]$StartDate = (Get-Date).AddDays(-30),
		[datetime]$EndDate = (Get-Date),
		[string]$OutputDir = "$((Get-Location).Path)\Output\",
		[string]$UserIds,
		[switch]$MergeOutput,
		[string]$Encoding = 'UTF8',
		[int]$Interval = 1440,
		[Parameter(Mandatory = $true)]
		[string]$ClientId,
		[Parameter(Mandatory = $true)]
		[string]$TenantId,
		[Parameter(Mandatory = $false)]
		[string]$ClientSecret,
		[Parameter(Mandatory = $false)]
		[switch]$IsApplication
	)
	begin {
		#region Variables
		[DateTime]$currentStart = $script:StartDate
		[DateTime]$currentEnd = $script:EndDate
		[DateTime]$lastLog = $script:EndDate
		$currentDay = 0  
		$date = [datetime]::Now.ToString('yyyyMMddHHmmss') 
		$filePath = "$OutputDir\SignInLogs.json"
		#endregion Variables

		#region Validation
		if (!($Global:IsConnected.mg)) {
			Write-logFile -Message '[WARNING] You must call Connect-Azure or install AzureADPreview before running this script' -Color 'Red'
		}
		if ([string]::IsNullOrWhiteSpace($Interval)) {
			$Interval = 1440
			Write-LogFile -Message '[INFO] Setting the Interval to the default value of 1440'
		}
		if ([string]::IsNullOrWhiteSpace($Encoding)) {
			$Encoding = 'UTF8'
		}
		if ([string]::IsNullOrWhiteSpace($OutputDir)) {
			$OutputDir = "Output\AzureAD\$date"
			write-logFile -Message "[INFO] Creating the following directory: $OutputDir"
			New-Item -ItemType Directory -Force -Name $OutputDir > $Null
		}
		if ($UserIds) {
			Write-LogFile -Message "[INFO] UserID's eq $($UserIds)"
		}
		if ($currentStart -gt $script:EndDate) {
			Write-LogFile -Message "[ERROR] $($currentStart.ToString('yyyy-MM-dd')) is greather than $($script:EndDate.ToString('yyyy-MM-dd')) - are you sure you put in the correct year? Exiting!" -Color 'Red'
			return
		}
		#endregion Validation

		Write-logFile -Message '[INFO] Running Get-AADSignInLogs' -Color 'Green'
		Write-LogFile -Message "[INFO] Extracting all available Directory Sign-in Logs between $($currentStart.ToUniversalTime().ToString('yyyy-MM-dd')) and $($currentEnd.ToUniversalTime().ToString('yyyy-MM-dd'))" -Color 'Green'

		#region IsApplicationInteroperability
		# 	Target: Find-MgGraphCommand `Get-MgAuditLogSignIn`
		# 	Method: GET
		#	URI: /auditLogs/signIns
		#	Permissions: {AuditLog.Read.All, Directory.Read.All}
		If ($IsApplication) {
			$Global:isApplication = $true
			# Set up interoperability
			Set-Interoperability -IsApplication:$IsApplication
			# Get authentication token
			$token = Get-AuthToken -ClientId $ClientId -TenantId $TenantId -ClientSecret $ClientSecret -IsApplication:$IsApplication
			# Configure Headers
			$headers = @{
				'Authorization' = "Bearer $token"
				'Content-Type'  = 'application/json'
			}
		}
		#endregion IsApplicationInteroperability

		#region URI.Builder
		# Prepare the query parameters
		$filterParts = @(
			"activityDateTime ge $($StartDate.ToString('yyyy-MM-ddTHH:mm:ssZ'))",
			"activityDateTime le $($EndDate.ToString('yyyy-MM-ddTHH:mm:ssZ'))"
		)
		if ($UserIds) {
			$filterParts += "initiatedBy/user/id eq '$UserIds'"
		}
		$filter = $filterParts -join ' and '
		# Prepare the initial API URL
		$baseUri = 'https://graph.microsoft.com/beta/auditLogs/signIns'
		$apiUrl = "$baseUri?`$filter=$filter"
		#endregion URI.Builder
	}
	process {
		#region API.Template
		$json = $data | ConvertTo-Json -Depth 10
		#if(!$json.StartsWith("[") -and !$json.EndsWith("]")){
		#    $json = "[`n" + $json + "`n]"
		#}
		$success = $false
		$WaitTime = 30
		$RetryCount = 0    
		$RetryCodes = @(503, 504, 520, 521, 522, 524)
		while ($RetryCount -lt $retry -and $success -eq $false) {
			do {
				try {
					Write-LogFile -Message "[INFO] Collecting Directory Sign-in logs between $($currentStart.ToUniversalTime().ToString('yyyy-MM-dd')) and $($currentEnd.ToUniversalTime().ToString('yyyy-MM-dd'))."
					if ($UserIds) {
						try {
							if ($IsApplication) {
								$results = Invoke-MgGraphRequest -Method Get -Uri $apiUrl -Headers $headers
								if ($response.value) {
									$response.value | ConvertTo-Json -Depth 100 | Out-File -FilePath $filePath -Encoding utf8 -Append
									Write-Host "[INFO] Sign-in logs appended to $filePath" -ForegroundColor Green
								}
								$apiUrl = $response.'@odata.nextLink'
								if (-not $apiUrl) {
									break
								}
							} else {
								$results = Invoke-MgGraphRequest -Method Get -Uri $apiUrl
								if ($response.value) {
									$response.value | ConvertTo-Json -Depth 100 | Out-File -FilePath $filePath -Encoding utf8 -Append
									Write-Host "[INFO] Sign-in logs appended to $filePath" -ForegroundColor Green
								}
								$apiUrl = $response.'@odata.nextLink'
								if (-not $apiUrl) {
									break
								}
							}
							[System.GC]::Collect()
							[System.GC]::WaitForPendingFinalizers()
						} catch {
							$retryCount++
							if ($retryCount -ge $maxRetries) {
								break
							}
							Write-Warning "Error occurred. Retrying in 30 seconds... (Attempt $retryCount of $maxRetries)"
						}
					} catch {
						$retryCount++
						if ($retryCount -ge $maxRetries) {
							Write-Error "Max retry attempts reached. Error: $_"
							break
						}
						Write-Warning "Error occurred. Retrying in 30 seconds... (Attempt $retryCount of $maxRetries)"
						Start-Sleep -Seconds 30
					}
					else {
						try {
							if ($IsApplication) {
								$results = Invoke-MgGraphRequest -Method Get -Uri $apiUrl -Headers $headers
								if ($response.value) {
									$response.value | ConvertTo-Json -Depth 100 | Out-File -FilePath $filePath -Encoding utf8 -Append
									Write-Host "[INFO] Sign-in logs appended to $filePath" -ForegroundColor Green
								}
								$apiUrl = $response.'@odata.nextLink'
								if (-not $apiUrl) {
									break
								}
							} else {
								$results = Invoke-MgGraphRequest -Method Get -Uri $apiUrl
								if ($response.value) {
									$response.value | ConvertTo-Json -Depth 100 | Out-File -FilePath $filePath -Encoding utf8 -Append
									Write-Host "[INFO] Sign-in logs appended to $filePath" -ForegroundColor Green
								}
								$apiUrl = $response.'@odata.nextLink'
								if (-not $apiUrl) {
									break
								}
							}
						} catch {
							$retryCount++
							if ($retryCount -ge $maxRetries) {
								Write-Error "Max retry attempts reached. Error: $_"
								break
							}
							Write-Warning "Error occurred. Retrying in 30 seconds... (Attempt $retryCount of $maxRetries)"
							Start-Sleep -Seconds 30
						}
					}
				} catch {
					$retryCount++
					if ($retryCount -ge $maxRetries) {
						Write-Error "Max retry attempts reached. Error: $_"
						break
					}
					Write-Warning "Error occurred. Retrying in 30 seconds... (Attempt $retryCount of $maxRetries)"
					Start-Sleep -Seconds 30
				}
				$success = $true
			} while ($RetryCount -lt $retry -and $success -eq $false)

			Write-LogFile -Message "[INFO] Found $currentCount Directory Audit Logs between $($currentStart.ToUniversalTime().ToString('yyyy-MM-dd')) and $($currentEnd.ToUniversalTime().ToString('yyyy-MM-dd'))" -Color 'Green'
			$filePath = "$OutputDir\SignInLogs-$($CurrentStart.ToString('yyyyMMdd'))-$($CurrentEnd.ToString('yyyyMMdd')).json"
			$results | ConvertTo-Json -Depth 100 | Out-File -Append $filePath -Encoding $Encoding
			Write-LogFile -Message "[INFO] Successfully retrieved $($currentCount) records out of total $($currentTotal) for the current time range."							
			[Array]$results = @()
			$CurrentStart = $CurrentEnd
		}
	}
	end {
		if ($MergeOutput.IsPresent) {
			Write-LogFile -Message '[INFO] Merging output files into one file'
			$outputDirMerged = "$OutputDir\Merged\"
			$mergedFilePath = "$outputDirMerged\SignInLogs-Combined.json"
			# Call the mergeoutput function with JSON argument for the (pwd).path
		}
		Write-LogFile -Message "[INFO] Acquisition complete, check the $($OutputDir) directory for your files.." -Color 'Green'		
	}
}

function Get-ADAuditLogs {
	<#
    .SYNOPSIS
    Get directory audit logs.

    .DESCRIPTION
    The Get-ADAuditLogs cmdlet collects the contents of the Azure Active Directory Audit logs.
	The output will be written to: "Output\AzureAD\Auditlogs.json

	.PARAMETER startDate
	The startDate parameter specifies the date from which all logs need to be collected.

	.PARAMETER endDate
    The endDate parameter specifies the date before which all logs need to be collected.

	.PARAMETER OutputDir
    outputDir is the parameter specifying the output directory.
	Default: Output\AzureAD

	.PARAMETER Encoding
    Encoding is the parameter specifying the encoding of the JSON output file.
	Default: UTF8

    .PARAMETER UserIds
    UserIds is the UserIds parameter filtering the log entries by the account of the user who performed the actions.
    
    .EXAMPLE
    Get-ADAuditLogs
	Get directory audit logs.

    .EXAMPLE
    Get-ADAuditLogs -UserIds Test@invictus-ir.com
    Get directory audit logs for the user Test@invictus-ir.com.

	.EXAMPLE
    Get-ADAuditLogs -endDate 2023-04-12
	Get directory audit logs before 2023-04-12.

	.EXAMPLE
    Get-ADAuditLogs -startDate 2023-04-12
	Get directory audit logs after 2023-04-12.
#>
	[CmdletBinding()]
	param(
		[datetime]$StartDate = (Get-Date).AddDays(-30),
		[datetime]$EndDate = (Get-Date),
		[string]$OutputDir = "$((Get-Location).Path)\Output\",
		[string]$UserIds,
		[string]$Encoding,
	 [switch]$IsApplication
	)
	begin {
		#region Variables
		[DateTime]$currentStart = $script:StartDate
		[DateTime]$currentEnd = $script:EndDate
		[DateTime]$lastLog = $script:EndDate
		$currentDay = 0  
		$date = [datetime]::Now.ToString('yyyyMMddHHmmss') 
		$filePath = "$OutputDir\$($date)-Auditlogs.json"
		#endregion Variables

		#region Validation
		if (!($Global:IsConnected.mg)) {
			Write-logFile -Message '[WARNING] You must call Connect-Azure or install AzureADPreview before running this script' -Color 'Red'
		}
		if ([string]::IsNullOrWhiteSpace($Interval)) {
			$Interval = 1440
			Write-LogFile -Message '[INFO] Setting the Interval to the default value of 1440'
		}
		if ([string]::IsNullOrWhiteSpace($Encoding)) {
			$Encoding = 'UTF8'
		}
		if ([string]::IsNullOrWhiteSpace($OutputDir)) {
			$OutputDir = "Output\AzureAD\$date"
			write-logFile -Message "[INFO] Creating the following directory: $OutputDir"
			New-Item -ItemType Directory -Force -Name $OutputDir > $Null
		}
		if ($UserIds) {
			Write-LogFile -Message "[INFO] UserID's eq $($UserIds)"
		}
		if ($endDate -and $After) {
			write-logFile -Message '[WARNING] Please provide only one of either a start date or end date' -Color 'Red'
			return
		}
		#endregion Validation

		Write-logFile -Message '[INFO] Running Get-ADAuditLogs' -Color 'Green'
		Write-logFile -Message '[INFO] Collecting the Directory Audit Logs'
		
		#region IsApplicationInteroperability
		# 	Target: Find-MgGraphCommand `Get-MgBetaAuditLogDirectoryAudit`
		# 	Method: GET
		#	URI: /auditLogs/directoryAudits
		#	Permissions: {AuditLog.Read.All, Directory.Read.All}
		If ($IsApplication) {
			$Global:isApplication = $true
			# Set up interoperability
			Set-Interoperability -IsApplication:$IsApplication
			# Get authentication token
			$token = Get-AuthToken -ClientId $ClientId -TenantId $TenantId -ClientSecret $ClientSecret -IsApplication:$IsApplication
			# Configure Headers
			$headers = @{
				'Authorization' = "Bearer $token"
				'Content-Type'  = 'application/json'
			}
		}
		#endregion IsApplicationInteroperability
		
		#region URI.Builder
		# Prepare the query parameters
		$filterParts = @(
			"activityDateTime ge $($StartDate.ToString('yyyy-MM-ddTHH:mm:ssZ'))",
			"activityDateTime le $($EndDate.ToString('yyyy-MM-ddTHH:mm:ssZ'))"
		)
		if ($UserIds) {
			$filterParts += "initiatedBy/user/id eq '$UserIds'"
		}
		$filter = $filterParts -join ' and '
		# Prepare the initial API URL
		$apiUri = 'https://graph.microsoft.com/beta/auditLogs/directoryAudits'
		$apiUrl = "$apiUri`?`$filter=$filter"
		#endregion URI.Builder
	}
	process {
		#region API.Template
		$json = $data | ConvertTo-Json -Depth 10
		#if(!$json.StartsWith("[") -and !$json.EndsWith("]")){
		#    $json = "[`n" + $json + "`n]"
		#}
		$success = $false
		$WaitTime = 30
		$RetryCount = 0    
		$RetryCodes = @(503, 504, 520, 521, 522, 524)
		while ($RetryCount -lt $retry -and $success -eq $false) {
			do {
				try {
					Write-LogFile -Message "[INFO] Collecting Directory Audit logs between $($currentStart.ToUniversalTime().ToString('yyyy-MM-dd')) and $($currentEnd.ToUniversalTime().ToString('yyyy-MM-dd'))."
					try {
						if ($IsApplication) {
							$results = Invoke-MgGraphRequest -Method Get -Uri $apiUrl -Headers $headers
							if ($response.value) {
								$response.value | ConvertTo-Json -Depth 100 | Out-File -FilePath $filePath -Encoding utf8 -Append
								Write-Host "[INFO] Audit logs appended to $filePath" -ForegroundColor Green
							}
							$apiUrl = $response.'@odata.nextLink'
							if (-not $apiUrl) {
								break
							}
						} else {
							$results = Invoke-MgGraphRequest -Method Get -Uri $apiUrl
							if ($response.value) {
								$response.value | ConvertTo-Json -Depth 100 | Out-File -FilePath $filePath -Encoding utf8 -Append
								Write-Host "[INFO] Audit logs appended to $filePath" -ForegroundColor Green
							}
							$apiUrl = $response.'@odata.nextLink'
							if (-not $apiUrl) {
								break
							}
						}
						[System.GC]::Collect()
						[System.GC]::WaitForPendingFinalizers()
					} catch {
						$retryCount++
						if ($retryCount -ge $maxRetries) {
							break
						}
						Write-Warning "Error occurred. Retrying in 30 seconds... (Attempt $retryCount of $maxRetries)"
					}
				} catch {
					$retryCount++
					if ($retryCount -ge $maxRetries) {
						Write-Error "Max retry attempts reached. Error: $_"
						break
					}
					Write-Warning "Error occurred. Retrying in 30 seconds... (Attempt $retryCount of $maxRetries)"
					Start-Sleep -Seconds 30
				} else {
					try {
						if ($IsApplication) {
							$results = Invoke-MgGraphRequest -Method Get -Uri $apiUrl -Headers $headers
							if ($response.value) {
								$response.value | ConvertTo-Json -Depth 100 | Out-File -FilePath $filePath -Encoding utf8 -Append
								Write-Host "[INFO] Audit logs appended to $filePath" -ForegroundColor Green
							}
							$apiUrl = $response.'@odata.nextLink'
							if (-not $apiUrl) {
								break
							}
						} else {
							$results = Invoke-MgGraphRequest -Method Get -Uri $apiUrl
							if ($response.value) {
								$response.value | ConvertTo-Json -Depth 100 | Out-File -FilePath $filePath -Encoding utf8 -Append
								Write-Host "[INFO] Audit logs appended to $filePath" -ForegroundColor Green
							}
							$apiUrl = $response.'@odata.nextLink'
							if (-not $apiUrl) {
								break
							}
						}
					} catch {
						$retryCount++
						if ($retryCount -ge $maxRetries) {
							Write-Error "Max retry attempts reached. Error: $_"
							break
						}
						Write-Warning "Error occurred. Retrying in 30 seconds... (Attempt $retryCount of $maxRetries)"
						Start-Sleep -Seconds 30
					}
				}
			} catch {
				$retryCount++
				if ($retryCount -ge $maxRetries) {
					Write-Error "Max retry attempts reached. Error: $_"
					break
				}
				Write-Warning "Error occurred. Retrying in 30 seconds... (Attempt $retryCount of $maxRetries)"
				Start-Sleep -Seconds 30
			}
			$success = $true
		}
		Write-LogFile -Message "[INFO] Found $currentCount Directory Audit Logs between $($currentStart.ToUniversalTime().ToString('yyyy-MM-dd')) and $($currentEnd.ToUniversalTime().ToString('yyyy-MM-dd'))" -Color 'Green'
		$filePath = "$OutputDir\SignInLogs-$($CurrentStart.ToString('yyyyMMdd'))-$($CurrentEnd.ToString('yyyyMMdd')).json"
		$results | ConvertTo-Json -Depth 100 | Out-File -Append $filePath -Encoding $Encoding
		Write-LogFile -Message "[INFO] Successfully retrieved $($currentCount) records out of total $($currentTotal) for the current time range."							
		[Array]$results = @()
		$CurrentStart = $CurrentEnd
		
		Write-LogFile -Message "[INFO] Successfully retrieved $($currentCount) records out of total $($currentTotal) for the current time range."
	}
	end {
		if ($MergeOutput.IsPresent) {
			Write-LogFile -Message '[INFO] Merging output files into one file'
			$outputDirMerged = "$OutputDir\Merged\"
			$mergedFilePath = "$outputDirMerged\SignInLogs-Combined.json"
			# Call the mergeoutput function with JSON argument for the (pwd).path
		}
		Write-LogFile -Message "[INFO] Acquisition complete, check the $($OutputDir) directory for your files.." -Color 'Green'		
	}
	Write-logFile -Message "[INFO] Directory audit logs written to $filePath" -Color 'Green'
}
