function Resolve-AzSubscription {
    [cmdletbinding()]
    param(
        [Parameter(Mandatory = $true, HelpMessage = 'Subscription object')]
        [Object]$Subscription
    )
    Begin {
        $state = $null
        $subscriptionId = $null
        $EmptyGuid = [System.Guid]::Empty

        # Get Subscription details
        if ($null -ne $Subscription.Psobject.Properties.Item('subscriptionId')) {
            $subscriptionId = $Subscription.subscriptionId
        }
        if ($null -ne $Subscription.Psobject.Properties.Item('state')) {
            $state = $Subscription.state
        }
        $isValidSubscription = [System.Guid]::TryParse($subscriptionId, [System.Management.Automation.PSReference]$EmptyGuid)
    }
    Process {
        if ($isValidSubscription -eq $false -or $state -eq 'Disabled') {
            Write-LogFile -Message "[ERROR] Invalid or disabled subscription: $($Subscription.displayName) - State: $state" -Color 'Red'
            $Subscription = $null
        } else {
            Write-LogFile -Message "[INFO] Valid subscription: $($Subscription.displayName)" -Color 'Green'
        }
    }
    End {
        return $Subscription
    }
}

function Get-ActivityLogs {
    <#
    .SYNOPSIS
    Retrieves the Activity logs.

    .DESCRIPTION
    The Get-ActivityLogs cmdlet collects the Azure Activity logs.
    The output will be written to: Output\AzureActivityLogs\$date\$SubscriptionID-ActivityLog.json

    .PARAMETER StartDate
    startDate is the parameter specifying the start date of the date range.
    Default: Today -89 days

    .PARAMETER EndDate
    endDate is the parameter specifying the end date of the date range.
    Default: Now

    .PARAMETER SubscriptionID
    SubscriptionID is the parameter specifies the subscription ID for which the collection of Activity logs is required.
    Default: All subscriptions

    .PARAMETER OutputDir
    OutputDir is the parameter specifying the output directory.
    Default: Output\AzureActivityLogs

    .PARAMETER Encoding
    Encoding is the parameter specifying the encoding of the JSON output file.
    Default: UTF8

    .EXAMPLE
    Get-ActivityLogs
    Get all the activity logs for all subscriptions connected to the logged-in user account for the last 89 days.

    .EXAMPLE
    Get-ActivityLogs -EndDate 2023-04-12
    Get all the activity logs before 2023-04-12.

    .EXAMPLE
    Get-ActivityLogs -StartDate 2023-04-12
    Get all the activity logs after 2023-04-12.

    .EXAMPLE
    Get-ActivityLogs -SubscriptionID "4947f939-cf12-4329-960d-4dg68a3eb66f"
    Get all the activity logs for the subscription 4947f939-cf12-4329-960d-4dg68a3eb66f
    #>
    [CmdletBinding()]
    param(
        [string]$StartDate,
        [string]$EndDate,
        [string]$SubscriptionID,
        [string]$OutputDir = "Output\AzureActivityLogs",
        [string]$Encoding = "UTF8",
        [int]$MaxRetries = 3
    )

    begin {
        # Validate parameters
        if ([string]::IsNullOrWhiteSpace($StartDate)) {
            $StartDate = (Get-Date).AddDays(-89).ToString("yyyy-MM-ddTHH:mm:ssZ")
        }
        if ([string]::IsNullOrWhiteSpace($EndDate)) {
            $EndDate = (Get-Date).ToString("yyyy-MM-ddTHH:mm:ssZ")
        }
        if ($MaxRetries -le 0) {
            throw "MaxRetries must be greater than 0."
        }

        # Ensure the output directory exists
        if (-not (Test-Path -Path $OutputDir)) {
            New-Item -ItemType Directory -Force -Path $OutputDir | Out-Null
        }

        Write-LogFile -Message "[INFO] Running Get-ActivityLogs" -Color "Green"
        $retryCount = 0
        $success = $false
        $subscriptions = @()

        # Get list of subscriptions
        if ([string]::IsNullOrWhiteSpace($SubscriptionID)) {
            $subscriptions = Get-AzSubscription | ForEach-Object { Resolve-AzSubscription -Subscription $_ }
        } else {
            $subscriptions = @(Resolve-AzSubscription -Subscription (Get-AzSubscription -SubscriptionId $SubscriptionID))
        }

        $subscriptions = $subscriptions | Where-Object { $_ -ne $null }

        if ($subscriptions.Count -eq 0) {
            Write-Error "No valid subscriptions found."
            return
        }
    }

    process {
        foreach ($sub in $subscriptions) {
            $subscriptionId = $sub.Id
            $subscriptionName = $sub.Name
            $date = Get-Date -Format "yyyyMMddHHmmss"
            $filePath = "$OutputDir\$($date)-$subscriptionId-ActivityLog.json"

            Write-LogFile -Message "[INFO] Retrieving Activity Logs for subscription: $subscriptionId" -Color "Green"
            Set-AzContext -SubscriptionId $subscriptionId | Out-Null

            $currentStart = [DateTime]::Parse($StartDate)
            $currentEnd = [DateTime]::Parse($EndDate)

            $totalDays = ($currentEnd - $currentStart).TotalDays

            for ($i = 0; $i -lt $totalDays; $i++) {
                $dayStart = $currentStart.AddDays($i)
                $dayEnd = $dayStart.AddDays(1).AddSeconds(-1)
                $success = $false
                $retryCount = 0

                while (-not $success -and $retryCount -lt $MaxRetries) {
                    try {
                        $logs = Get-AzActivityLog -StartTime $dayStart -EndTime $dayEnd -MaxRecord 1000 -ErrorAction Stop
                        $success = $true

                        if ($logs.Count -gt 0) {
                            Write-LogFile -Message "[INFO] Successfully retrieved $($logs.Count) Activity logs for $($dayStart.ToString("yyyy-MM-dd"))." -Color "Green"
                            $logs | ConvertTo-Json -Depth 100 | Out-File -FilePath $filePath -Append -Encoding $Encoding
                        } else {
                            Write-LogFile -Message "[INFO] No Activity Logs found for $($dayStart.ToString("yyyy-MM-dd")). Moving on!" -Color "Yellow"
                        }
                    } catch {
                        $retryCount++
                        $delay = [math]::Pow(2, $retryCount)
                        Write-Warning "Error retrieving activity logs for $($dayStart.ToString("yyyy-MM-dd")). Attempt $retryCount of $MaxRetries. Retrying in $delay seconds..."
                        Start-Sleep -Seconds $delay
                    }
                }

                if (-not $success) {
                    Write-Error "Failed to retrieve activity logs for $($dayStart.ToString("yyyy-MM-dd")) after $MaxRetries attempts." -ForegroundColor Red
                }
            }
        }
    }

    end {
        Write-Host '[INFO] Process completed.' -ForegroundColor Green
    }
}