function Get-ADSignInLogsGraph {
    <#
    .SYNOPSIS
        Gets Azure AD sign-in logs with pagination.
    .DESCRIPTION
        Collects the contents of the Azure Active Directory sign-in logs using the GraphAPI with pagination.
        Outputs are written to a specified directory.
    .PARAMETER startDate
        Specifies the date from which all logs need to be collected.
    .PARAMETER endDate
        Specifies the end date until which all logs need to be collected.
    .PARAMETER OutputDir
        Specifies the output directory. Default: "Output\AzureAD"
    .PARAMETER Encoding
        Specifies the encoding of the JSON output file. Default: UTF8
    .PARAMETER Application
        Specifies App-only access for authentication and authorization.
        Default: Delegated access (access on behalf a user)
    .PARAMETER MergeOutput
        Specifies if output files should be merged into a single file. Default: No
    .PARAMETER UserIds
        Filters log entries by the user account that performed the actions.
    .EXAMPLE
        Get-ADSignInLogsGraph
        Retrieves all sign-in logs.
    .EXAMPLE
        Get-ADSignInLogsGraph -endDate '2023-04-12'
        Retrieves sign-in logs until 2023-04-12.
    #>
    [CmdletBinding()]
    param(
        [string]$startDate,
        [string]$endDate,
        [string]$OutputDir = 'Output\AzureAD',
        [string]$UserIds,
        [string]$Encoding = 'UTF8',
        [switch]$Application,
        [switch]$MergeOutput,
        [int]$MaxRetries = 3
    )

    begin {
        if ([string]::IsNullOrWhiteSpace($OutputDir)) {
            $OutputDir = "Output\AzureAD"
        }

        if (-not (Test-Path -Path $OutputDir)) {
            New-Item -ItemType Directory -Force -Path $OutputDir >$null
        }

        if ([string]::IsNullOrWhiteSpace($Encoding)) {
            $Encoding = 'UTF8'
        }

        if ($MaxRetries -le 0) {
            throw "MaxRetries must be greater than 0."
        }

        Write-LogFile -Message "[INFO] Starting Get-ADSignInLogsGraph" -Color "Green"
    }

    process {
        try {
            if (!($Application.IsPresent)) {
                $areYouConnected = (IsConnected).IsConnected.mg
                if (!$areYouConnected) {
                    Connect-MgGraph -ErrorAction Stop
                }
            } elseif ($Application.IsPresent) {
                Invoke-Interop
                if([string]::IsNullOrEmpty($appID)){}
                if([string]::IsNullOrEmpty($appSecret)){}
                if([string]::IsNullOrEmpty($tenantID)){}
                if([string]::IsNullOrEmpty($token)){
                    $param=@{
                        appID = $appID
                        appSecret = $appSecret
                        tenantID = $tenantID
                    }
                    $token = Get-Token @param
                }
                $headers = @{
                    'Authorization' = "Bearer $token"
                }
                return $headers
            }

            $queryFilter = @()
            if ($startDate) {
                $queryFilter += "createdDateTime ge '$startDate'"
            }
            if ($endDate) {
                $queryFilter += "createdDateTime le '$endDate'"
            }
            if ($UserIds) {
                $queryFilter += "userPrincipalName eq '$UserIds'"
            }

            $apiUri = 'https://graph.microsoft.com/v1.0/auditLogs/signIns'
            $filter = $queryFilter -join ' and '
            $params = @{
                Uri    = "$apiUri?`$filter=$filter"
                Method = 'GET'
            }

            if ($Application.IsPresent) {
                $params.Headers = $headers
            }

            $retryCount = 0
            $success = $false

            do {
                while (-not $success -and $retryCount -lt $MaxRetries) {
                    try {
                        $response = Invoke-MgGraphRequest @params
                        $logs = $response.Content | ConvertFrom-Json

                        $date = Get-Date -Format 'yyyyMMddHHmmss'
                        $filePath = Join-Path -Path $OutputDir -ChildPath "$($date)-SignInLogsGraph.json"
                        $logs.value | ConvertTo-Json -Depth 100 | Out-File -FilePath $filePath -Append -Encoding $Encoding

                        Write-LogFile -Message "[INFO] Sign-in logs written to $filePath" -Color "Green"

                        if ($response.'@odata.nextLink') {
                            $params.Uri = $response.'@odata.nextLink'
                        } else {
                            $success = $true
                        }

                        [System.GC]::Collect()
                        [System.GC]::WaitForPendingFinalizers()
                    } catch {
                        $retryCount++
                        $delay = [math]::Pow(2, $retryCount)
                        Write-Warning "Error fetching data: $_. Attempt $retryCount of $MaxRetries. Retrying in $delay seconds..."
                        Start-Sleep -Seconds $delay
                    }
                }

                if (-not $success) {
                    Write-Error "Failed to retrieve sign-in logs after $MaxRetries attempts."
                }
            } while ($response.'@odata.nextLink' -and $success)
        } catch {
            Write-Error "Error during process: $_" -ForegroundColor Red
        }
    }

    end {
        if ($MergeOutput) {
            Merge-OutputFiles -OutputDir $OutputDir -Encoding $Encoding
        }

        Write-LogFile -Message '[INFO] Process completed.' -Color "Green"
    }
}

function Merge-OutputFiles {
    param(
        [string]$OutputDir,
        [string]$Encoding
    )
    $mergedFilePath = Join-Path -Path $OutputDir -ChildPath 'SignInLogs-Combined.json'
    $allLogs = Get-ChildItem -Path $OutputDir -Filter '*.json' |
    Get-Content -Raw | ConvertFrom-Json

    $allLogs | ConvertTo-Json -Depth 100 | Set-Content -Path $mergedFilePath -Encoding $Encoding
    Write-LogFile -Message "[INFO] All logs merged into $mergedFilePath" -Color "Green"
}

function Get-ADAuditLogsGraph {
    <#
    .SYNOPSIS
        Get directory audit logs using direct API calls.
    .DESCRIPTION
        Uses direct API calls to fetch the contents of the Azure Active Directory Audit logs using RESTful endpoints.
        Outputs are written to "Output\AzureAD\AuditlogsGraph.json"
    .PARAMETER StartDate
        Specifies the date from which logs should be collected.
    .PARAMETER EndDate
        Specifies the end date until which logs should be collected.
    .PARAMETER OutputDir
        Specifies the output directory.
        Default: "Output\AzureAD"
    .PARAMETER UserIds
        Filters the log entries by the account of the user who performed the actions.
    .PARAMETER Encoding
        Specifies the encoding of the JSON output file.
        Default: "UTF8"
    #>
    [CmdletBinding()]
    param(
        [string]$StartDate,
        [string]$EndDate,
        [string]$OutputDir = 'Output\AzureAD',
        [string]$UserIds,
        [string]$Encoding = 'UTF8',
        [int]$MaxRetries = 3
    )

    begin {
        if ([string]::IsNullOrWhiteSpace($OutputDir)) {
            $OutputDir = "Output\AzureAD"
        }

        if (-not (Test-Path -Path $OutputDir)) {
            New-Item -ItemType Directory -Force -Path $OutputDir | Out-Null
        }

        if ([string]::IsNullOrWhiteSpace($Encoding)) {
            $Encoding = 'UTF8'
        }

        if ($MaxRetries -le 0) {
            throw "MaxRetries must be greater than 0."
        }

        Write-LogFile -Message "[INFO] Starting Get-ADAuditLogsGraph" -Color "Green"
    }

    process {
        try {
            Connect-MgGraph -Scopes 'AuditLog.Read.All', 'Directory.Read.All' -NoWelcome

            $queryParameters = @()
            if ($StartDate) { $queryParameters += "`$filter=activityDateTime ge $StartDate" }
            if ($EndDate) { $queryParameters += "activityDateTime le $EndDate" }
            if ($UserIds) { $queryParameters += " and initiatedBy/user/id eq $UserIds" }
            $filterQuery = $queryParameters -join ' and '
            $apiUrl = "https://graph.microsoft.com/v1.0/auditLogs/directoryAudits?$filterQuery"

            $retryCount = 0
            $success = $false

            do {
                while (-not $success -and $retryCount -lt $MaxRetries) {
                    try {
                        $response = Invoke-MgGraphRequest -Method Get -Uri $apiUrl
                        $logs = $response.Content | ConvertFrom-Json

                        $date = Get-Date -Format 'yyyyMMddHHmmss'
                        $filePath = Join-Path $OutputDir "$($date)-AuditlogsGraph.json"
                        $logs.value | ConvertTo-Json -Depth 100 | Out-File -FilePath $filePath -Append -Encoding $Encoding

                        Write-LogFile -Message "[INFO] Audit logs written to $filePath" -Color "Green"

                        if ($response.'@odata.nextLink') {
                            $apiUrl = $response.'@odata.nextLink'
                        } else {
                            $success = $true
                        }

                        [System.GC]::Collect()
                        [System.GC]::WaitForPendingFinalizers()
                    } catch {
                        $retryCount++
                        $delay = [math]::Pow(2, $retryCount)
                        Write-Warning "Error fetching data: $_. Attempt $retryCount of $MaxRetries. Retrying in $delay seconds..."
                        Start-Sleep -Seconds $delay
                    }
                }

                if (-not $success) {
                    Write-Error "Failed to retrieve audit logs after $MaxRetries attempts."
                }
            } while ($response.'@odata.nextLink' -and $success)
        } catch {
            Write-Error "Error during process: $_" -ForegroundColor Red
        }
    }

    end {
        Write-LogFile -Message '[INFO] Process completed.' -Color "Green"
    }
}

