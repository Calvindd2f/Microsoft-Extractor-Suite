# This contains a function to collect the Message Trace logging.
Function StartDateMTL
{
	if (($startDate -eq "") -Or ($null -eq $startDate))
	{
		$script:StartDate = [datetime]::Now.ToUniversalTime().AddDays(-10)
		write-LogFile -Message "[INFO] No start date provived by user setting the start date to: $($script:StartDate.ToString("yyyy-MM-ddTHH:mm:ssK"))" -Color "Yellow"
	}
	else
	{
		$script:StartDate = $startDate -as [datetime]
		if (!$startDate) { write-LogFile -Message "[WARNING] Not A valid start date and time, make sure to use YYYY-MM-DD" -Color "Red"} 
	}
}

function EndDateMTL
{
	if (($endDate -eq "") -Or ($null -eq $endDate))
	{
		$script:EndDate = [datetime]::Now.ToUniversalTime()
		write-LogFile -Message "[INFO] No end date provived by user setting the end date to: $($script:EndDate.ToString("yyyy-MM-ddTHH:mm:ssK"))" -Color "Yellow"
	}
	else
	{
		$script:EndDate = $endDate -as [datetime]
		if (!$endDate) {write-LogFile -Message "[WARNING] Not A valid end date and time, make sure to use YYYY-MM-DD" -Color "Red"} 
	}
}

ffunction Get-MessageTraceLog {
    <#
    .SYNOPSIS
    Collects the trace messages as they pass through the cloud-based organization.

    .DESCRIPTION
    Collects the trace messages as they pass through the cloud-based organization.
    Only 10 days of history is available. Output is saved in: Output\MessageTrace\

    .PARAMETER UserIds
    UserIds is the parameter filtering the log entries by the account of the user who performed the actions.

    .PARAMETER StartDate
    StartDate is the parameter specifying the start date of the date range.
    Default: Today - 10 days.

    .PARAMETER EndDate
    EndDate is the parameter specifying the end date of the date range.
    Default: Now.

    .PARAMETER OutputDir
    OutputDir is the parameter specifying the output directory.
    Default: Output\MessageTrace

    .PARAMETER Encoding
    Encoding is the parameter specifying the encoding of the CSV output file.
    Default: UTF8

    .EXAMPLE
    Get-MessageTraceLog
    Collects the trace messages for all users.

    .EXAMPLE
    Get-MessageTraceLog -UserIds HR@invictus-ir.com
    Collects the trace messages for the user HR@invictus-ir.com.

    .EXAMPLE
    Get-MessageTraceLog -UserIds "Test@invictus-ir.com,HR@invictus-ir.com"
    Collects the trace messages for the users Test@invictus-ir.com and HR@invictus-ir.com.

    .EXAMPLE
    Get-MessageTraceLog -UserIds "*@invictus-ir.com"
    Collects the trace messages for the full @invictus-ir.com domain.

    .EXAMPLE
    Get-MessageTraceLog -UserIds Test@invictus-ir.com -StartDate 1/4/2023 -EndDate 5/4/2023
    Gets the trace messages for the user Test@invictus-ir.com between 1/4/2023 and 5/4/2023.
    #>
    [CmdletBinding()]
    param(
        [string]$UserIds,
        [string]$StartDate,
        [string]$EndDate,
        [string]$OutputDir = "Output\MessageTrace",
        [string]$Encoding = "UTF8"
    )

    # Ensure we're connected to M365
    try {
        $null = Get-MessageTrace -ResultSize 1 -ErrorAction Stop
    }
    catch {
        Write-LogFile -Message "[WARNING] You must call Connect-M365 before running this script" -Color "Red"
        return
    }

    Write-LogFile -Message "[INFO] Running Get-MessageTraceLog" -Color "Green"

    # Ensure output directory exists
    if (-not (Test-Path -Path $OutputDir)) {
        New-Item -ItemType Directory -Force -Path $OutputDir | Out-Null
        Write-LogFile -Message "[INFO] Creating the following directory: $OutputDir"
    }

    $date = Get-Date -Format "yyyyMMddHHmm"

    # Set default date range if not specified
    if (-not $StartDate) {
        $StartDate = (Get-Date).AddDays(-10)
    }

    if (-not $EndDate) {
        $EndDate = Get-Date
    }

    # Helper function to collect message trace logs
    function Collect-MessageTraceLogs($identifier) {
        $outputFile = "$OutputDir\$($identifier)-MTL.csv"

        $resultsRecipient = Get-MessageTrace -RecipientAddress $identifier -StartDate $StartDate -EndDate $EndDate -PageSize 5000
        $resultsSender = Get-MessageTrace -SenderAddress $identifier -StartDate $StartDate -EndDate $EndDate -PageSize 5000

        $results = $resultsSender + $resultsRecipient

        if ($results) {
            Write-LogFile -Message "[INFO] Collecting the Message Trace Log for $identifier"
            $results | Export-Csv -Path $outputFile -NoTypeInformation -Encoding $Encoding
            Write-LogFile -Message "[INFO] Output is written to: $outputFile" -Color "Green"
        } else {
            Write-LogFile -Message "[INFO] No message trace logging found for $identifier" -Color "Yellow"
        }
    }

    # Process user IDs
    if (-not $UserIds) {
        Write-LogFile -Message "[INFO] No users provided. Getting the Message Trace Log for all users." -Color "Yellow"
        Get-Mailbox -ResultSize Unlimited | ForEach-Object {
            Collect-MessageTraceLogs $_.PrimarySmtpAddress
        }
    } elseif ($UserIds -match ",") {
        $UserIds.Split(",") | ForEach-Object {
            Collect-MessageTraceLogs $_
        }
    } elseif ($UserIds -match "\*") {
        Write-LogFile -Message "[INFO] An entire domain has been provided. Retrieving all messages." -Color "Yellow"
        Write-LogFile -Message "[WARNING] Output is restricted to a maximum of 5000 received and 5000 sent emails." -Color "Red"

        $domain = $UserIds.Replace("*@", "")
        Collect-MessageTraceLogs $UserIds
    } else {
        Collect-MessageTraceLogs $UserIds
    }
}