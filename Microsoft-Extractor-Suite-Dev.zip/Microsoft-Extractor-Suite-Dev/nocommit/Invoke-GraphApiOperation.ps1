# Microsoft Graph API Interaction Template

# Constants
$script:GraphApiEndpoint = "https://graph.microsoft.com/v1.0"
$script:LoginEndpoint = "https://login.microsoftonline.com"

# Function to set up constants
function Set-Constants {
    # Add any additional constants here
}

# Function to handle interoperability
function Set-Interoperability {
    [CmdletBinding()]
    param(
        [switch]$IsApplication
    )

    if ($IsApplication) {
        # For application authentication, we use Invoke-RestMethod directly
        New-Alias -Name Invoke-MgGraphRequest -Value Invoke-RestMethod -Option Constant -Force
    } else {
        # For delegated authentication, we use the Microsoft.Graph module's Invoke-MgGraphRequest
        # Ensure the Microsoft.Graph module is imported
        Import-Module Microsoft.Graph -ErrorAction Stop
    }
}

# Function to get authentication token
function Get-AuthToken {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$ClientId,
        [Parameter(Mandatory = $true)]
        [string]$TenantId,
        [Parameter(Mandatory = $false)]
        [string]$ClientSecret,
        [Parameter(Mandatory = $false)]
        [switch]$ExchangeOnline,
        [Parameter(Mandatory = $false)]
        [switch]$IsApplication
    )

    $scope = if ($ExchangeOnline) {
        'https://outlook.office365.com/.default'
    } else {
        'https://graph.microsoft.com/.default'
    }

    if ($IsApplication) {
        # Application authentication
        $body = @{
            Grant_Type    = 'client_credentials'
            Client_Id     = $ClientId
            Client_Secret = $ClientSecret
            Scope         = $scope
        }

        $tokenEndpoint = "$script:LoginEndpoint/$TenantId/oauth2/v2.0/token"
        $response = Invoke-RestMethod -Uri $tokenEndpoint -Method Post -Body $body

        return $response.access_token
    } else {
        # Delegated authentication
        Connect-MgGraph -ClientId $ClientId -TenantId $TenantId -Scopes $scope
        return (Get-MgContext).AccessToken
    }
}

# Function to test if the token is valid
function Test-AuthToken {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$Token
    )

    $headers = @{
        'Authorization' = "Bearer $Token"
    }

    try {
        Invoke-RestMethod -Uri "$script:GraphApiEndpoint/me" -Headers $headers -Method Get -ErrorAction Stop
        return $true
    } catch {
        Write-Warning "Token validation failed: $_"
        return $false
    }
}

# Main execution function
function Invoke-GraphApiOperation {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$ClientId,
        [Parameter(Mandatory = $true)]
        [string]$TenantId,
        [Parameter(Mandatory = $false)]
        [string]$ClientSecret,
        [Parameter(Mandatory = $false)]
        [switch]$ExchangeOnline,
        [Parameter(Mandatory = $false)]
        [switch]$IsApplication
    )

    # Set up constants and interoperability
    Set-Constants
    Set-Interoperability -IsApplication:$IsApplication

    # Get authentication token
    $token = Get-AuthToken -ClientId $ClientId -TenantId $TenantId -ClientSecret $ClientSecret -ExchangeOnline:$ExchangeOnline -IsApplication:$IsApplication

    # Test the token
    if (-not (Test-AuthToken -Token $token)) {
        throw "Failed to obtain a valid authentication token."
    }

    # Example Graph API call
    $headers = @{
        'Authorization' = "Bearer $token"
        'Content-Type' = 'application/json'
    }

    $response = Invoke-MgGraphRequest -Uri "$script:GraphApiEndpoint/me" -Headers $headers -Method Get

    # Process and return the response
    return $response
}

# Usage example
# Invoke-GraphApiOperation -ClientId 'your-client-id' -TenantId 'your-tenant-id' -ClientSecret 'your-client-secret' -IsApplication