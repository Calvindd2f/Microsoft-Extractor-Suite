using module Microsoft.Graph.Authentication;
#using module ExchangeOnlineManagement;
using module Az;
Get-InstalledModule PackageManagement -AllVersions; Get-InstalledModule PowerShellGet -AllVersions
install-package PackageManagement -ProviderName PowerShellGet
install-package PowerShellGet -ForceBootstrap -Force



function Connect-Mg($ClientId, $Scopes)
{
    Connect-MgGraph -NoWelcome -UseDeviceCode  > $null
}
function Connect-Exo($ClientId)
{
    Connect-ExchangeOnline -NoWelcome -UseDeviceCode  > $null 
}
function Connect-Az
{
    Connect-AzAccount -NoWelcome -UseDeviceCode  > $null
}

function Execute
{
    param(
        [Parameter(Mandatory = $false)]
        [string]$ClientId,
        [Parameter(Mandatory = $false)]
        [string]$Scopes
    )

    $connectionStatus = [pscustomobject]@{
        mg     = $false
        exo    = $false
        az     = $false
        status = $null
    }

    $commands = @(
        { Connect-MgGraph -NoWelcome -UseDeviceCode  > $null },
        { Connect-ExchangeOnline -ShowBanner:$false -UseMultithreading:$true -Device > $null },
        { Connect-AzAccount -UseDeviceAuthentication  > $null }
    )

    $connectionStatus.mg = $null -ne (Get-MgContext -ErrorAction SilentlyContinue)
    $connectionStatus.exo = $null -ne (Get-ConnectionInformation -ErrorAction SilentlyContinue)
    $connectionStatus.az = $null -eq (Get-AzContext -ErrorAction SilentlyContinue)

    $commands | ForEach-Object{
        & $_
    }

    if ($connectionStatus.mg -eq $false -or $connectionStatus.exo -eq $false -or $connectionStatus.az -eq $false) { $connectionStatus.status = 'false' }
    else { $connectionStatus.status = "true" }
    
    return @{ IsConnected = $connectionStatus;}
}

Function IsConnected($mg,$exo,$az)
{
    return $connectionStatus
}
