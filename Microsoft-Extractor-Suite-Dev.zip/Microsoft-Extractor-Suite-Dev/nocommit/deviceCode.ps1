# Load the Newtonsoft.Json assembly
Add-Type -Path "Newtonsoft.Json.dll"

# Define the C# class code
$csCode = @"
using System;
using System.Net.Http;
using System.Collections.Generic;
using System.Threading.Tasks;
using Newtonsoft.Json.Linq;

public class DeviceCode
{
    public string RefreshToken { get; set; }
    public string TenantId { get; set; }
    public bool DisplayToken { get; set; }
    public string Outfile { get; set; }
    public bool IsExchange { get; set; }

    public DeviceCode(string refreshToken, string tenantId, bool displayToken, string outfile, bool isExchange)
    {
        this.RefreshToken = refreshToken;
        this.TenantId = tenantId;
        this.DisplayToken = displayToken;
        this.Outfile = outfile;
        this.IsExchange = isExchange;
    }

    public void RefreshTokenMethod()
    {
        var deviceCodeResult = GetTokenAsync(new DeviceCodeResult
        {
            RefreshToken = this.RefreshToken,
            TenantId = this.TenantId,
            IsExchange = this.IsExchange,
            Scopes = this.IsExchange ? new[] { "https://outlook.office.com/.default" } : new[] { "https://graph.microsoft.com/.default" }
        }).Result;

        if (DisplayToken)
        {
            Console.WriteLine("New token: " + deviceCodeResult.AccessToken);
        }

        if (!string.IsNullOrEmpty(Outfile))
        {
            System.IO.File.WriteAllText(Outfile, deviceCodeResult.AccessToken);
        }
    }

    public async Task<DeviceCodeResult> GetTokenAsync(DeviceCodeResult deviceCodeResult)
    {
        if (deviceCodeResult == null)
        {
            throw new ArgumentNullException(nameof(deviceCodeResult));
        }

        var client = new HttpClient();
        var content = new FormUrlEncodedContent(new[]
        {
            new KeyValuePair<string, string>("client_id", deviceCodeResult.ClientId),
            new KeyValuePair<string, string>("grant_type", "urn:ietf:params:oauth:grant-type:device_code"),
            new KeyValuePair<string, string>("code", deviceCodeResult.UserCode),
            new KeyValuePair<string, string>("scope", string.Join(" ", deviceCodeResult.Scopes))
        });

        var response = await client.PostAsync(deviceCodeResult.VerificationUrl, content);
        response.EnsureSuccessStatusCode();

        var tokenResponse = JObject.Parse(await response.Content.ReadAsStringAsync());

        var tokenExpire = DateTime.Parse(tokenResponse["expires_on"].ToString(), null, System.Globalization.DateTimeStyles.RoundtripKind).ToLocalTime();
        Console.WriteLine("Decoded JWT payload:\n" + tokenResponse.ToString() + "\nYour access token is set to expire on: " + tokenExpire);

        return new DeviceCodeResult
        {
            AccessToken = tokenResponse["access_token"].ToString(),
            RefreshToken = tokenResponse["refresh_token"].ToString(),
            ExpiresOn = tokenResponse["expires_on"].ToString(),
            ClientId = deviceCodeResult.ClientId,
            Scopes = deviceCodeResult.Scopes
        };
    }
}

public class DeviceCodeResult
{
    public string UserCode { get; set; }
    public string VerificationUrl { get; set; }
    public string ClientId { get; set; }
    public string[] Scopes { get; set; }
    public string AccessToken { get; set; }
    public string RefreshToken { get; set; }
    public string ExpiresOn { get; set; }

    public DeviceCodeResult() {}

    public DeviceCodeResult(string accessToken, string refreshToken, string expiresOn, string clientId, string[] scopes)
    {
        this.AccessToken = accessToken;
        this.RefreshToken = refreshToken;
        this.ExpiresOn = expiresOn;
        this.ClientId = clientId;
        this.Scopes = scopes;
    }
}
"@

# Add the C# class to the PowerShell session
Add-Type -TypeDefinition $csCode -Language CSharp

# Example usage
$refreshToken = "your-refresh-token"
$tenantId = $env:tenantId
$displayToken = $true
$outfile = $null
$isExchange = $false

# Create an instance of the DeviceCode class
$deviceCode = [DeviceCode]::new($refreshToken, $tenantId, $displayToken, $outfile, $isExchange)

# Refresh the token
$deviceCode.RefreshTokenMethod()