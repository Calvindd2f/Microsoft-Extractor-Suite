enum ErrorType
{
    UserAccessDenied = 404;
    ResourceNotFound = 403;
    Throttling = 429;
    ServiceUnavailable = 503;
}

