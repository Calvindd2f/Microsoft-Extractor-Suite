foreach ($f in $files)
{
    $fileContent = Get-Content -Path $F -Raw;
    $ast = [System.Management.Automation.Language.Parser]::ParseInput($fileContent, [ref]$null, [ref]$null)
    $functions = @()

    $ast.FindAll([Func[System.Management.Automation.Language.Ast, bool]] {
            param ($node)
            $node -is [System.Management.Automation.Language.FunctionDefinitionAst]
        }, $true) | ForEach-Object {
        $functions += $_.Name
    }
    $functions
}