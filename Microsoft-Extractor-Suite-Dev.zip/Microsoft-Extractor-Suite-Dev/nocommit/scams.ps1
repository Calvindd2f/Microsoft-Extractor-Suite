
function SLP-Audit
{
    [CmdletBinding()]
    [Diagnostics.CodeAnalysis.SuppressMessageAttribute("InjectionRisk.Create", "", Scope = "Function")]
    Param (
        [parameter(Mandatory = $false, HelpMessage = "Provider")]
        [ValidateSet("Azure", "EntraID", "Microsoft365")]
        [String]$Provider = "Azure",

        [Parameter(Mandatory = $false, HelpMessage = "Out data")]
        [Object]$ReturnData,

        [Parameter(Mandatory = $false, HelpMessage = "Change the threads settings. Default is 2")]
        [int32]$Throttle = 2,
        [Parameter(Mandatory = $false, HelpMessage = "ApartmentState of the thread")]
        [ValidateSet("STA", "MTA")]
        [String]$ApartmentState = "MTA",

        [Parameter(HelpMessage = "Timeout before a thread stops trying to gather the information")]
        [ValidateRange(1, 65535)]
        [int32]$Timeout = 30,

        [Parameter(HelpMessage = "Increase Sleep Timer in seconds between child objects")]
        [ValidateRange(1, 65535)]
        [int32]$SleepTimer = 5,

        [Parameter(HelpMessage = "Pause between batchs in milliseconds")]
        [int32]$BatchSleep = 0,

        [Parameter(HelpMessage = "BatchSize")]
        [int32]$BatchSize = 100,

        [Parameter(HelpMessage = "Increase Sleep Timer in seconds between child objects")]
        [ValidateRange(1, 65535)]
        [int32]$MaxQueue = 1
    )
  
    Begin
    {
        if ($Global:Debug) 
        { 
            [console]::WriteLine("========================= Begin Function =========================")
            [console]::WriteLine("Begin $($MyInvocation.MyCommand.Name)")
            [console]::WriteLine("Provider: $Provider")
            [console]::WriteLine("ReturnData: $ReturnData")
            [console]::WriteLine("Throttle: $Throttle")
            [console]::WriteLine("ApartmentState: $ApartmentState")
            [console]::WriteLine("Timeout: $Timeout")
            [console]::WriteLine("SleepTimer: $SleepTimer")
            [console]::WriteLine("BatchSleep: $BatchSleep")
            [console]::WriteLine("BatchSize: $BatchSize")
            [console]::WriteLine("MaxQueue: $MaxQueue")
        }

        # Initialize the return data variable
        $rdata = $null
        [console]::WriteLine("Initialize the return data variable")

        # Set the maximum queue size based on the throttle value
        if (-not $PSBoundParameters.ContainsKey('MaxQueue'))
        {
            $MaxQueue = $Throttle * 3
            [console]::WriteLine("MaxQueue set to $MaxQueue")
        }

        # Initialize the list of scans
        $allScans = [System.Collections.Generic.List[System.Collections.Hashtable]]::new()
        [console]::WriteLine("`$allScans initialized")
    }
    Process
    {
        $scans = [System.Collections.Generic.List[System.Collections.Hashtable]]::new();
        $scanOptions = $null;
        #Set hashtable
        $scanOptions = [ordered]@{
            scanName       = $Provider;
            modules        = $O365Object.runspaces_modules;
            libCommands    = $libs;
            vars           = $vars;
            threads        = $Throttle;
            collectors     = $collectors;
            apartmentState = $ApartmentState;
            startUpScripts = $O365Object.runspace_init;
        }
        [void]$all_scans.Add($scanOptions);

        #set the default connection limit
        [System.Net.ServicePointManager]::DefaultConnectionLimit = 1024;
        [System.Net.ServicePointManager]::MaxServicePoints = 1000;

        # Initialize ruleset with the same parameters as the original call
        $newParams = @()
        $metaData = [System.Management.Automation.CommandMetaData](Get-Command -Name $_)
        if ($null -ne $metaData)
        {
            foreach ($param in $metaData.Parameters.Values)
            {
                if ($PSBoundParameters.ContainsKey($param.Name))
                {
                    $newParams += @{ $param.Name = $PSBoundParameters[$param.Name] }
                }
            }
        }
        $all_scans = & $_ @newParams
        # Check if the ReturnData parameter is specified and set it if it is.
        # Otherwise, check if a variable named "returnData" exists and set it if it does.
        # If neither is specified, create a new synchonized hashtable named "returnData" and set it.
        $rdata = if ($PSBoundParameters.ContainsKey('ReturnData') -and $PSBoundParameters['ReturnData'])
        {
            $PSBoundParameters['ReturnData']
        }
        elseif (Get-Variable -Name returnData -ErrorAction Ignore)
        {
            (Get-Variable -Name returnData -ErrorAction Ignore).Value
        }
        else
        {
            $returnData = [hashtable]::Synchronized(@{})
            Set-Variable -Name returnData -Value $returnData -Scope Script -Force
            $returnData
        }
        # Populate vars with the return data hashtable
        $all_scans | ForEach-Object {
            $_.vars.returnData = $rdata
        }
        # Populate runspace vars
        $firstScanWithVars = $all_scans.Where({ $null -ne $_.vars }, 'First')
        
        if ($null -ne $firstScanWithVars)
        {
            $O365Object.runspace_vars = $firstScanWithVars.vars
        }
        else
        {
            Write-Warning 'No scans found with vars, cannot set runspace vars'
        }
    }
    End
    {
        #Set runspaces array
        $all_runspaces = [System.Collections.Generic.List[System.Management.Automation.Runspaces.RunspacePool]]::new();

        #Launch scans
        try
        {
            #Get all libs
            $libs = $all_scans.libCommands | Select-Object -Unique

            #Set nested runspace
            $nestedParam = @{
                ImportVariables          = $all_scans[0].vars;
                ImportModules            = $all_scans[0].modules;
                ImportCommands           = $libs;
                ApartmentState           = $all_scans[0].apartmentState;
                Throttle                 = $all_scans[0].threads;
                StartUpScripts           = $all_scans[0].startUpScripts;
                ThrowOnRunspaceOpenError = $true;
                Verbose                  = $O365Object.verbose;
                Debug                    = $O365Object.debug;
                InformationAction        = $O365Object.InformationAction;
            }

            #Set a second runspace for nested executions
            $nestedRunspace = New-RunspacePool @nestedParam
            if ($null -ne $nestedRunspace -and $nestedRunspace -is [System.Management.Automation.Runspaces.RunspacePool])
            {
                #Add to array
                [void]$all_runspaces.Add($nestedRunspace)
                #Add to object
                $O365Object._runspacePool = $nestedRunspace;
            }
        }
        catch
        {
            Write-Error "Error creating nested runspace: $_"
        }
        foreach ($scan in $all_scans)
        {
            $startMessage = "Starting new scan for {0}" -f $scan.scanName
            $messageData = @{
                MessageData       = $startMessage;
                callStack         = (Get-PSCallStack)[0];
                logLevel          = 'info';
                InformationAction = $O365Object.InformationAction;
                Tags              = @('365Scanner');
            }

            Write-Information @messageData

            $collectorFiles = $scan.collectors | ForEach-Object { $_.File }
            $libraryCommands = $scan.libCommands

            $commands = $collectorFiles + $libraryCommands

            $runspaceParams = @{
                ImportVariables          = $scan.vars;
                ImportModules            = $scan.modules;
                ImportCommands           = $commands;
                ApartmentState           = $scan.apartmentState;
                Throttle                 = $scan.threads;
                StartUpScripts           = $scan.startUpScripts;
                ThrowOnRunspaceOpenError = $true;
                Verbose                  = $O365Object.verbose;
                Debug                    = $O365Object.debug;
                InformationAction        = $O365Object.InformationAction;
            }

            $runspacePool = New-RunspacePool @runspaceParams

            if ($null -ne $runspacepool -and $runspacepool -is [System.Management.Automation.Runspaces.RunspacePool])
            {
                $runspacepool.Open()
                $all_runspaces.Add($runspacepool)
            }

            if ($runspacepool.RunspacePoolStateInfo.State -eq [System.Management.Automation.Runspaces.RunspaceState]::Opened)
            {
                foreach ($collector in $scan.collectors)
                {
                    $jobParams = @{
                        Runspacepool      = $runspacepool;
                        ReuseRunspacePool = $true;
                        MaxQueue          = $MaxQueue;
                        Debug             = $O365Object.Debug;
                        Verbose           = $O365Object.Verbose;
                        BatchSleep        = $O365Object.BatchSleep;
                        BatchSize         = $O365Object.BatchSize;
                        InformationAction = $O365Object.InformationAction;
                    }

                    $collectorId = [System.Guid]::NewGuid().ToString()
                    $arguments = @{
                        CollectorId = $collectorId
                    }

                    $job = Start-Job -ScriptBlock $collector.collectorName -Arguments $arguments @jobParams
                    $job | Add-Member -MemberType NoteProperty -Name CollectorId -Value $collectorId
                }
            }
            if (-not $runspacepool.RunspacePoolStateInfo.State -eq [System.Management.Automation.Runspaces.RunspaceState]::Opened)
            {
                Write-Error $message.RunspaceError
                return
            }
        }

        try
        {
            foreach ($collector in $scan.collectors)
            {
                $jobParams = @{
                    Runspacepool      = $runspacepool;
                    ReuseRunspacePool = $true;
                    MaxQueue          = $MaxQueue;
                    Debug             = $O365Object.Debug;
                    Verbose           = $O365Object.Verbose;
                    BatchSleep        = $O365Object.BatchSleep;
                    BatchSize         = $O365Object.BatchSize;
                    InformationAction = $O365Object.InformationAction;
                }

                $collectorId = [System.Guid]::NewGuid().ToString()
                $arguments = @{ CollectorId = $collectorId }

                $job = Start-Job -ScriptBlock $collector.collectorName -Arguments $arguments @jobParams
                $job | Add-Member -MemberType NoteProperty -Name CollectorId -Value $collectorId
            }
        }
        catch
        {
            Write-Error $_
            return
        }

        finally
        {
            # Dispose all runspacepool
            foreach ($rs in $all_runspaces)
            {
                $rs.Dispose()
            }

            # Collect garbage
            [System.GC]::Collect()
        }
    }
}


