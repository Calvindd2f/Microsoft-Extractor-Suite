function Get-UALAll
{
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $false)]
        [string[]]$UserIds = $null,

        [Parameter(Mandatory = $false)]
        [DateTime]$StartDate = (Get-Date).AddDays(-90),

        [Parameter(Mandatory = $false)]
        [DateTime]$EndDate = (Get-Date),

        [Parameter(Mandatory = $false)]
        [int]$Interval = 60,

        [Parameter(Mandatory = $false)]
        [string]$Output = "CSV",

        [Parameter(Mandatory = $false)]
        [string]$OutputDir = "UnifiedAuditLog",

        [Parameter(Mandatory = $false)]
        [string]$Encoding = "UTF8"
    )

    begin
    {
        $OutputFile = Join-Path -Path $OutputDir -ChildPath "$(Get-Date -Format 'yyyyMMdd_HHmmss')-AuditRecords.csv"
        if (!(Test-Path $OutputFile))
        {
            Write-Host "Creating the following file: $OutputFile"
        }
        else
        {
            Write-Host "INFO: Appending to the existing file: $OutputFile"
        }

        $userCredential = Get-Credential
        Connect-ExchangeOnline -Credential $userCredential

        $params = @{
            StartDate      = $StartDate
            EndDate        = $EndDate
            ResultSize     = 1
            SessionCommand = "ReturnTotalCount"
        }

        if ($UserIds)
        {
            $params.UserIds = $UserIds.Split(",")
        }

        $totalRecords = (Search-UnifiedAuditLog @params).Count
        $totalLoops = [math]::Ceiling($totalRecords / 5000)
    }

    process
    {
        for ($i = 0; $i -lt $totalLoops; $i++)
        {
            $currentStart = $StartDate.AddMinutes($i * $Interval)
            $currentEnd = $currentStart.AddMinutes($Interval)

            $params = @{
                StartDate      = $currentStart
                EndDate        = $currentEnd
                ResultSize     = 5000
                SessionCommand = "ReturnLargeSet"
            }

            if ($UserIds)
            {
                $params.UserIds = $UserIds.Split(",")
            }

            $sessionId = [Guid]::NewGuid().ToString()
            $params.SessionId = $sessionId
            $success = $false
            $retryCount = 0
            do
            {
                try
                {
                    $result = Search-UnifiedAuditLog @params
                    $params.SessionCommand = "ReturnNextPreviewPage"
                    $success = $true
                }
                catch
                {
                    $retryCount++
                    if ($_.Exception.Response.StatusCode -eq 429)
                    {
                        $WaitTime = 30
                        Write-Host "INFO: Attempting to retry in $WaitTime seconds" -ForegroundColor Yellow
                        Start-Sleep -Seconds $WaitTime
                        $WaitTime = $WaitTime * 2
                    }
                    else
                    {
                        throw $_
                    }
                }
            } while (-not $success -and $retryCount -lt 3)

            $result | Export-Csv $OutputFile -NoTypeInformation -Append
        }
    }
}

function Get-ADSignInLogs
{
    [CmdletBinding()]
    param(
        [datetime]$startDate = (Get-Date).AddDays(-30).ToString('yyyy-MM-ddT00:00:00'),
        [datetime]$endDate = (Get-Date).ToString('yyyy-MM-ddT00:00:00'),
        [string]$OutputDir = "$((Get-Location).Path)\Output\",
        [string]$UserIds,
        [switch]$MergeOutput,
        [string]$Encoding = 'UTF8',
        [int]$Interval = 1440
    )

    Write-logFile -Message "[INFO] Running Get-ADSignInLogs" -Color "Green"

    $date = (Get-Date).ToString('yyyyMMddHHmmss') #used for filename not for usage in API calls.
    
    if ([string]::IsNullOrWhiteSpace($OutputDir.Split('\')[0]))
    {
        mkdir -Force "$OutputDir\AzureAD\$date" > $null
    }
    $OutputDir = "$OutputDir\AzureAD\$date"

    if ($UserIds)
    {
        Write-LogFile -Message "[INFO] UserID's eq $($UserIds)"
    }
    else
    {
        Write-LogFile -Message "[INFO] UserIDs not specified."
    }

    $filePath = "$OutputDir\SignInLogs.json"
    
    $baseUri = 'https://graph.microsoft.com/v1.0'
    $resourcePath = (Find-MgGraphCommand -Command Get-MgBetaAuditLogSignIn).URI[1]
    $baseUri = "$baseUri$resourcePath`?"

    $queryParameters = @()
    if ($startDate) { $queryParameters += "`$filter=activityDateTime ge $startDate" }
    if ($endDate) { $queryParameters += "activityDateTime le $endDate" }
    if ($UserIds) { $queryParameters += " and initiatedBy/user/id eq $UserIds" }
    $filterQuery = $queryParameters -join ' and '
    $apiUrl = "$baseUri``$filterQuery"
    
    try
    {
        Do
        {
            $response = Invoke-MgGraphRequest -Method Get -Uri $apiUrl -ContentType 'application/json'
            $logs = $response
            $date = (Get-Date).ToString('yyyy-MM-ddTHH:mm:ss')
            $logs.Values | ConvertTo-Json -Depth 100 | Out-File -FilePath $filePath -Encoding utf8BOM
            Write-Host "[INFO] Sign-in logs written to $filePath" -ForegroundColor Green
            $baseUri = $response.'@odata.nextLink'  # Update the URL to the nextLink for pagination
            [System.GC]::Collect()
            [System.GC]::WaitForPendingFinalizers()
        } While ($response.'@odata.nextLink')
    }
    catch [System.Net.WebException]
    {
        Write-Error "Error fetching data: $_.Exception.Message. Retrying in 30 seconds..."
        Start-Sleep -Seconds 30
        $retryCount = 0
        while ($retryCount -lt 5)
        {
            try
            {
                $response = Invoke-MgGraphRequest -Method Get -Uri $apiUrl -ContentType 'application/json'
                $logs = $response
                $date = (Get-Date).ToString('yyyy-MM-ddTHH:mm:ss')
                $logs.Values | ConvertTo-Json -Depth 100 | Out-File -FilePath $filePath -Encoding utf8BOM
                Write-Host "[INFO] Sign-in logs written to $filePath" -ForegroundColor Green
                $baseUri = $response.'@odata.nextLink'  # Update the URL to the nextLink for pagination
                break
            }
            catch
            {
                Write-Error "Retrying... Attempt $($retryCount + 1)"
                Start-Sleep -Seconds 30
                $retryCount++
            }
        }
    }
    finally
    {
        # Clean up resources explicitly after the loop
        Remove-Variable response -ErrorAction Ignore
        Remove-Variable logs -ErrorAction Ignore
        [System.GC]::Collect()
        [System.GC]::WaitForPendingFinalizers()
    }

    if ($MergeOutput)
    {
        try
        {
            Write-Host '[INFO] Merging output files...' -ForegroundColor Green
            $mergedFile = "ADSignInLog-Combined.json"
            Merge-OutputFiles -OutputDir $OutputDir -Encoding $Encoding -mergedFile $mergedFile
        }
        catch
        {
            Write-Error "Error fetching data: $_" -ForegroundColor Red
        }
        finally
        {
            Write-Host '[INFO] Process completed.' -ForegroundColor Green
        }
    }
}












function Invoke-MgGraphRequest20 
{
    Param(
        [GraphRequestMethod]$Method,
        [Uri]$Uri,
        [object]$Body,
        [IDictionary]$Headers,
        [string] $OutputFilePath,
        [SwitchParameter] $InferOutputFileName,
        [virtual][string] $InputFilePath,
        [SwitchParameter] $PassThru,
        [SwitchParameter] $SkipHeaderValidation,
        [string] $ContentType
    )
    if ($Global:MxSDebug) { Write-Host "========================= querystring: $querystring" }
    $success = $false
    $WaitTime = 30
    $RetryCount = 0    
    $RetryCodes = @(503, 504, 520, 521, 522, 524)
    $FailCodes = @(400, 404)
    while ($RetryCount -lt $retry -and $success -eq $false)
    {
        try
        {
            $request = [System.Net.HttpWebRequest]::Create("$CW_Api_Url/apis/3.0/company/contacts$querystring")
        
            $request.Method = "GET";
            $request.ContentType = "application/json";
            $authBytes = [System.Text.Encoding]::UTF8.GetBytes($CW_Api_Token);
            $authStr = "Basic " + $([System.Convert]::ToBase64String($authBytes));
            $request.Headers["Authorization"] = $authStr;
            $request.Headers["clientId"] = $CW_Api_Client_Id;
            $request.Timeout = 10000
                
            $response = $request.GetResponse();
            $reader = new-object System.IO.StreamReader $response.GetResponseStream();
            $jsonResult = $reader.ReadToEnd();
            $response.Dispose();

            if ($Global:MxSDebug) { Write-Host "========================= JSON result from WEB(GetContact): $jsonResult" }
            [array]$returnedObject = $jsonResult | ConvertFrom-Json
            if ($Global:MxSDebug) { Write-Host "`r`n===================== Count of found objects: $($returnedObject.Count) `r`n" }
            if ($returnedObject.Count -gt 1)
            {
                foreach ($contactItem in $returnedObject)
                {
                    if ($Global:MxSDebug) { Write-Host "=====================ContactItem===> $($contactItem)" }
                    if ($Global:MxSDebug) { Write-Host "=====================ContactItem>>>> $($contactItem.id)" }
                    if ($Global:MxSDebug) { Write-Host "=====================ContactItem>>>> $($contactItem.firstName) Compare to $($userObjectToAction.firstName)" }
                    if ($Global:MxSDebug) { Write-Host "=====================ContactItem>>>> $($contactItem.lastName) Compare to $($userObjectToAction.lastName)" }
                    If (($contactItem.firstName -eq $userObjectToAction.firstName) -and ($contactItem.lastName -eq $userObjectToAction.lastName))
                    {
                        $success = $true
                        return $( $contactItem  )
                    }
                }
                $success = $true
                return $( $jsonResult | ConvertFrom-Json)
            }
            else
            {
                $success = $true
                return $( $jsonResult | ConvertFrom-Json)
            }
    
        }
        catch
        {
            if ($Global:MxSDebug) { Write-Host "========================= WARNING: $($_.Exception.Message)" }
            # Write-Host "========================= WARNING: $( ConvertTo-json $_.Exception)"
            # Geeting the actual numeric value for the error code.
            # When we run through MxS Env we will get nested InnerException inside the 
            # parent InnerException as we are utilising a HTTP WebClient Wrapper on top
            # of the MxS environment
            if ( Test-Path variable:global:psISE )
            {
                if ($Global:MxSDebug) { Write-Host "==================Running package locally for debugging===========" }
                $ErrorCode = $_.Exception.InnerException.Response.StatusCode.value__
            }
            else
            {
                if ($Global:MxSDebug) { Write-Host "========================= Running package in MxS" }
                $ErrorCode = $_.Exception.InnerException.InnerException.Response.StatusCode.value__
            }
            if ($Global:MxSDebug) { Write-Host "========================= Errorcode: $ErrorCode" }
            # Checking if we got any of Fail Codes
            if ($ErrorCode -in $FailCodes)
            {
                # Setting the variables to make activity Fail
                $success = $false;
                $activityOutput.success = $false;
                # If we need immediate stop - we can uncomment below.
                # Write-Error "CRITICAL: $($_.Exception.Message)" -ErrorAction Stop
                Write-Warning "Warning: $($_.Exception.Message)"
                return $null;
            }
            if ($ErrorCode -in $RetryCodes)
            {
                $RetryCount++

                if ($RetryCount -eq $retry)
                {
                    if ($Global:MxSDebug) { Write-host "========================= WARNING: Retry limit reached." }
                }
                else
                {
                    if ($Global:MxSDebug) { Write-host "========================= Waiting $WaitTime seconds." }
                    Start-Sleep -seconds $WaitTime
                    if ($Global:MxSDebug) { Write-host "========================= Retrying." }
                }

            }
            else
            {
                return $null;
            }
        }
    }
}



