function Set-Interop
{
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false)]
        [bool]$IsApplication
    )

    $Global:IsApplication = $IsApplication

    if (-not $Global:IsApplication)
    {
        return
    }

    try
    {
        Set-Alias -Force -Name 'Invoke-MgGraphRequest' -Value 'Invoke-RestMethod' -Option Constant -Scope Global
    }
    catch
    {
        try
        {
            New-Alias -Force -Name 'Invoke-MgGraphRequest' -Value 'Invoke-RestMethod' -Option Constant -Scope Global
        }
        catch
        {
            Write-Error "Unable to create alias Invoke-MgGraphRequest. Verify you have run 'Microsoft.Graph' installed , even though these are API calls."
            exit
        }
    }
}