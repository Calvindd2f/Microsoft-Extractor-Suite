# Enhanced Microsoft Graph and Exchange Online API Interaction Template
# Constants
$script:GraphApiEndpoint = "https://graph.microsoft.com/v1.0"
$script:ExoApiEndpoint = "https://outlook.office365.com/adminapi/beta"
$script:LoginEndpoint = "https://login.microsoftonline.com"
$script:ConnId = $([guid]::NewGuid().Guid).ToString()
$script:DefaultTimeout = 30
$script:url = "$script:ExoApiEndpoint/$TenantName/InvokeCommand"
$script:headers = @{
    'Authorization'        = "Bearer $Token"
    'Content-Type'         = 'application/json'
    'x-serializationlevel' = 'Partial'
    'X-AnchorMailbox'      = "UPN:SystemMailbox{bb558c35-97f1-4cb9-8ff7-d53741dc928c}@$TenantName"
    'X-ResponseFormat'     = 'json'
    'connection-id'        = $script:ConnId
}


# Function to set up constants
function Set-Constants {
    [pscustomobject]$constants = @{
        graphApiEndpoint = 'https://graph.microsoft.com/v1.0'
        exoApiEndpoint   = 'https://outlook.office365.com/adminapi/beta'
        loginEndpoint    = 'https://login.microsoftonline.com'
        connectionId     = [guid]::NewGuid().Guid
        defaultTimeout   = 30
        headers          = @{
            'Authorization'        = "Bearer $Token"
            'Content-Type'         = 'application/json'
            'x-serializationlevel' = 'Partial'
            'X-AnchorMailbox'      = "UPN:SystemMailbox{bb558c35-97f1-4cb9-8ff7-d53741dc928c}@$TenantName"
            'X-ResponseFormat'     = 'json'
            'connection-id'        = $script:ConnId
        }
        url = "$script:ExoApiEndpoint/$TenantName/InvokeCommand"
        DebugStatements = $true
    }

    Write-Host "Setting constants..."
    try {
        $constants.exo_token = Get-Token -Scope 'https://outlook.office365.com/.default'
        Write-Host "Token acquired: $($constants.exo_token)"
    } catch {
        Write-Error "Failed to acquire token: $_"
    }

    if ($constants.DebugStatements) {
        Write-Host "Graph API Endpoint: $($constants.graphApiEndpoint)"
        Write-Host "EXO API Endpoint: $($constants.exoApiEndpoint)"
        Write-Host "Login Endpoint: $($constants.loginEndpoint)"
        Write-Host "Connection ID: $($constants.connectionId)"
        Write-Host "Default Timeout: $($constants.defaultTimeout)"
        Write-Host "EXO Token: $($constants.exo_token)"
    } else {
        Write-Host "Debug statements are disabled."
    }

    Write-Warning "Debug statements enabled: $($constants.DebugStatements)"

    return @{
        GraphApiEndpoint = $constants.graphApiEndpoint
        ExoApiEndpoint   = $constants.exoApiEndpoint
        LoginEndpoint    = $constants.loginEndpoint
        ConnectionId     = $constants.connectionId
        DefaultTimeout   = $constants.defaultTimeout
        exo_token        = $constants.exo_token
    }
}

# Function to get authentication token
function Get-Token
{
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [ValidateSet('https://graph.microsoft.com/.default', 'https://outlook.office365.com/.default')]
        [string]$Scope,

        [Parameter(Mandatory = $false)]
        [string]$AppId,

        [Parameter(Mandatory = $false)]
        [string]$AppSecret,

        [Parameter(Mandatory = $false)]
        [string]$TenantId
    )

    begin
    {
        $body = @{
            Grant_Type    = 'client_credentials'
            Client_Id     = $env:AppId
            Client_Secret = $env:AppSecret
            Scope         = $Scope
        }
    }
    process
    {
        $response = Invoke-RestMethod -Uri "https://login.microsoftonline.com/$env:TenantId/oauth2/v2.0/token" -Method Post -Body $body
    }
    end
    {
        return $response.access_token
    }
}

# Function to execute Exchange Online commands
function Invoke-ExoCommand {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$Command,
        [Parameter(Mandatory = $false)]
        [hashtable]$Parameters,
        [Parameter(Mandatory = $true)]
        [string]$Token,
        [Parameter(Mandatory = $true)]
        [string]$TenantName,
        [Parameter(Mandatory = $false)]
        [int]$RetryCount = 5
    )

    $body = @{
        CmdletInput = @{
            CmdletName = $Command
            Parameters = $Parameters
        }
    }

    $json = $body | ConvertTo-Json -Depth 5 -Compress
    $url = "$script:ExoApiEndpoint/$TenantName/InvokeCommand"

    $headers = @{
        'Authorization' = "Bearer $Token"
        'Content-Type' = 'application/json'
        'x-serializationlevel' = 'Partial'
        'X-AnchorMailbox' = "UPN:SystemMailbox{bb558c35-97f1-4cb9-8ff7-d53741dc928c}@$TenantName"
        'X-ResponseFormat' = 'json'
        'connection-id' = $script:ConnId
    }

    $retry = 0
    do {
        try {
            $response = Invoke-RestMethod -Uri $url -Method Post -Headers $headers -Body $json -TimeoutSec $script:DefaultTimeout
            return $response.value
        }
        catch {
            $retry++
            if ($retry -gt $RetryCount) {
                throw "Failed to execute Exchange command after $RetryCount retries: $_"
            }
            Start-Sleep -Seconds ([Math]::Pow(2, $retry))
        }
    } while ($true)
}

# Function to get Unified Audit Log
function Get-UnifiedAuditLog {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$Token,
        [Parameter(Mandatory = $true)]
        [string]$TenantName,
        [Parameter(Mandatory = $false)]
        [string[]]$UserIds,
        [Parameter(Mandatory = $false)]
        [DateTime]$StartDate = (Get-Date).AddDays(-90),
        [Parameter(Mandatory = $false)]
        [DateTime]$EndDate = (Get-Date),
        [Parameter(Mandatory = $false)]
        [int]$Interval = 60,
        [Parameter(Mandatory = $false)]
        [string]$RecordType,
        [Parameter(Mandatory = $false)]
        [string]$Operations
    )

    $searchParams = @{
        StartDate = $StartDate.ToString("s")
        EndDate = $EndDate.ToString("s")
        Interval = $Interval
    }

    if ($UserIds) { $searchParams.UserIds = $UserIds }
    if ($RecordType) { $searchParams.RecordType = $RecordType }
    if ($Operations) { $searchParams.Operations = $Operations }

    $results = Invoke-ExoCommand -Command "SearchUnifiedAuditLog" -Parameters $searchParams -Token $Token -TenantName $TenantName

    return $results
}

# Main execution function
function Invoke-ApiOperation {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$ClientId,
        [Parameter(Mandatory = $true)]
        [string]$TenantId,
        [Parameter(Mandatory = $false)]
        [string]$ClientSecret,
        [Parameter(Mandatory = $false)]
        [switch]$ExchangeOnline,
        [Parameter(Mandatory = $false)]
        [switch]$IsApplication
    )

    Set-Constants
    Set-Interoperability -IsApplication:$IsApplication

    $token = Get-AuthToken -ClientId $ClientId -TenantId $TenantId -ClientSecret $ClientSecret -ExchangeOnline:$ExchangeOnline -IsApplication:$IsApplication

    if ($ExchangeOnline) {
        $tenantName = $TenantId.Split('.')[0]
        $ualData = Get-UnifiedAuditLog -Token $token -TenantName $tenantName -StartDate (Get-Date).AddDays(-7)
        return $ualData
    } else {
        $headers = @{
            'Authorization' = "Bearer $token"
            'Content-Type' = 'application/json'
        }
        $response = Invoke-MgGraphRequest -Uri "$script:GraphApiEndpoint/me" -Headers $headers -Method Get
        return $response
    }
}

# Usage example
# Invoke-ApiOperation -ClientId 'your-client-id' -TenantId 'your-tenant-id' -ClientSecret 'your-client-secret' -ExchangeOnline -IsApplication






# Main Execution
Set-Constants