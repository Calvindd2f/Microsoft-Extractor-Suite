
## MS GRAPH FUNCTIONS

function ExecuteQuery($url, $token, $queryInfo)
{
    #Write-Host "Executing query on: $url";
    #write-Host $queryInfo.body;
    
    $request = [System.Net.HttpWebRequest]::Create($url)

    $request.Method = $queryInfo.method;
    $request.ContentType = "application/json;odata.metadata=minimal";
    $request.Headers["Authorization"] = "Bearer $token";
	
    if ($null -ne $queryInfo.body)
    {
        $Body = [byte[]][char[]]$queryInfo.body;
        $Stream = $Request.GetRequestStream();
        $Stream.Write($Body, 0, $Body.Length);
    }
    try
    {
        $response = $request.GetResponse();
        $reader = new-object System.IO.StreamReader $response.GetResponseStream();
        $jsonResult = $reader.ReadToEnd();
        $response.Dispose();
    }
    catch
    {
       
        if ($($_.Exception.Message) -like "*Unable to update the specified properties for on-premises mastered Directory Sync objects*")
        {
            Write-Host "WARNING: Unable to update the specified properties for on-premises mastered Directory Sync objects or objects currently undergoing migration."
            $hardFail = $true
         
            return $null
                
        }
        else { Write-Host "WARNING: $($_.Exception.Message)" }
    }
	
	
    #write-host "JSON result: $jsonResult"

    return $jsonResult;
}

Function RemoveManager($retry = 5)
{
    $url = "https://graph.microsoft.com/v1.0/users/" + [Uri]::EscapeUriString($upn) + "/manager/`$ref"

    $success = $false
    $count = 0
    
    do
    {
        try
        {        
            $request = [System.Net.HttpWebRequest]::Create($url)
            
            $request.Method = "DELETE";
            $request.ContentType = "application/json;odata.metadata=minimal";
            $request.Headers["Authorization"] = "Bearer $msgraph_token";
            $request.Timeout = 10000
            
            $requestWriter = New-Object System.IO.StreamWriter $request.GetRequestStream();
            #$requestWriter.Write();
            $requestWriter.Flush();
            $requestWriter.Close();
            
            $response = $request.GetResponse();
            $reader = new-object System.IO.StreamReader $response.GetResponseStream();
            $jsonResult = $reader.ReadToEnd();
            $response.Dispose();
            
            $success = $true
            $count = $retry
            
            Write-Host "Manager attribute has been cleared."
            
            return $true;
        }
        catch
        {
         
            if ($($_.Exception.Message) -like "*Unable to update the specified properties for on-premises mastered Directory Sync objects*")
            {
                Write-Host "WARNING: Unable to update the specified properties for on-premises mastered Directory Sync objects or objects currently undergoing migration."
              
                return $null
            }
            elseif ($($_.Exception.Message) -like "*timed out*")
            {
                $count++
                Start-Sleep -seconds 30
            }
            else
            {
                Write-Host "WARNING: $($_.Exception.Message)"
                return $null;
            }
        }
    }while ($count -lt $retry -or $success -eq $false)
    return $null;
}

Function CreateContactItem($data, $id, $retry = 5) 
{
    $json = $data | ConvertTo-Json -Depth 10
    #if(!$json.StartsWith("[") -and !$json.EndsWith("]")){
    #    $json = "[`n" + $json + "`n]"
    #}
    $success = $false
    $WaitTime = 30
    $RetryCount = 0    
    $RetryCodes = @(503, 504, 520, 521, 522, 524)
    while ($RetryCount -lt $retry -and $success -eq $false)
    {
        try
        {
            $request = [System.Net.HttpWebRequest]::Create("$CW_Api_Url/apis/3.0/company/contacts/$id/communications")
        
            $request.Method = "POST";
            $request.ContentType = "application/json";
            $authBytes = [System.Text.Encoding]::UTF8.GetBytes($CW_Api_Token);
            $authStr = "Basic " + $([System.Convert]::ToBase64String($authBytes));
            $request.Headers["Authorization"] = $authStr;
            $request.Headers["clientId"] = $CW_Api_Client_Id;
            $request.Timeout = 10000
        	
            $requestWriter = New-Object System.IO.StreamWriter $request.GetRequestStream();
            $requestWriter.Write($json);
            $requestWriter.Flush();
            $requestWriter.Close();
            $requestWriter.Dispose();
    
            $response = $request.GetResponse();
            $response.Dispose();
            $success = $true
            Write-Host "Updated: $($data.value)"
            return $response
        }
        catch
        {
            Write-Host "WARNING: $($_.Exception.Message)"
            $ErrorCode = $_.Exception.InnerException.Response.StatusCode
            if ($ErrorCode -in $RetryCodes)
            {
                $RetryCount++

                if ($RetryCount -eq $retry)
                {
                    Write-host "WARNING: Retry limit reached." 
                }
                else
                {
                    Write-host "Waiting $WaitTime seconds."
                    Start-Sleep -seconds $WaitTime
                    Write-host "Retrying."                    
                }

            }
            else
            {
                return $null;
            }
        }
    }
}