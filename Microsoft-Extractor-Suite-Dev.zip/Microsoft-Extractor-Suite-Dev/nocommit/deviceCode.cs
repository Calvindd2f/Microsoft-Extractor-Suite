using namespace System.Diagnostics
using namespace System.Net.Http
using namespace System.Threading
using namespace Newtonsoft.Json
using namespace Newtonsoft.Json.Linq

$AutoTokenRefresh = @'
public class AutoTokenRefresh
{
    private readonly string _RefreshToken;
    private readonly string _tenantid;
    private readonly int _RefreshInterval;
    private readonly int _InitializationDelay;
    private readonly bool _DisplayToken;
    private readonly string _Outfile;
    private readonly bool _isExchange;

    public AutoTokenRefresh(string refreshToken, string tenantid, int refreshInterval, int initializationDelay, bool displayToken, string outfile, bool isExchange)
    {
        _RefreshToken = refreshToken ?? throw new ArgumentNullException(nameof(refreshToken));
        _tenantid = tenantid ?? throw new ArgumentNullException(nameof(tenantid));
        _RefreshInterval = refreshInterval;
        _InitializationDelay = initializationDelay;
        _DisplayToken = displayToken;
        _Outfile = outfile;
        _isExchange = isExchange;
    }

    private Timer tokenRefreshTimer;
    private void StartAutoRefresh()
    {
        tokenRefreshTimer = new Timer(RefreshToken, null, _InitializationDelay, _RefreshInterval);
    }

    private async void RefreshToken(object state)
    {
        $deviceCodeResult = GetTokenAsync($(New-Object -TypeName AutoTokenRefresh.DeviceCodeResult -ArgumentList $_RefreshToken, $_tenantid, $false, $false, $(if ($_isExchange) { "https://outlook.office.com/.default" } else { "https://graph.microsoft.com/.default" })), $_isExchange)

        if ($_DisplayToken)
        {
            Write-Host "New token: $($deviceCodeResult.AccessToken)"
        }

        if (![string]::IsNullOrEmpty($_Outfile))
        {
            Set-Content -Path $_Outfile -Value $deviceCodeResult.AccessToken
        }
    }

    public static async Task<DeviceCodeResult> GetTokenAsync(DeviceCodeResult deviceCodeResult, bool isExchange)
    {
        if (deviceCodeResult == null)
        {
            throw new ArgumentNullException(nameof(deviceCodeResult));
        }

        if (deviceCodeResult.UserCode == null)
        {
            throw new ArgumentNullException(nameof(deviceCodeResult.UserCode));
        }

        if (deviceCodeResult.VerificationUrl == null)
        {
            throw new ArgumentNullException(nameof(deviceCodeResult.VerificationUrl));
        }

        if (deviceCodeResult.ClientId == null)
        {
            throw new ArgumentNullException(nameof(deviceCodeResult.ClientId));
        }

        if (deviceCodeResult.Scopes == null)
        {
            throw new ArgumentNullException(nameof(deviceCodeResult.Scopes));
        }

        $client = New-Object -TypeName HttpClient
        $content = New-Object -TypeName FormUrlEncodedContent -ArgumentList @(
            New-Object -TypeName KeyValuePair[string,string] -ArgumentList "client_id", deviceCodeResult.ClientId
            New-Object -TypeName KeyValuePair[string,string] -ArgumentList "grant_type", "urn:ietf:params:oauth:grant-type:device_code"
            New-Object -TypeName KeyValuePair[string,string] -ArgumentList "code", deviceCodeResult.UserCode
            New-Object -TypeName KeyValuePair[string,string] -ArgumentList "scope", [string]::Join(" ", deviceCodeResult.Scopes)
        )

        $response = $client.PostAsync(deviceCodeResult.VerificationUrl, $content).Result
        $response.EnsureSuccessStatusCode()

        $tokenResponse = [JObject]::Parse($response.Content.ReadAsStringAsync().Result)

        $tokenExpire = [DateTime]::Parse($tokenResponse["expires_on"].ToString(), $null, [DateTimeStyles]::RoundtripKind).ToLocalTime()
        Write-Host "Decoded JWT payload:`n$tokenResponse`nYour access token is set to expire on: $tokenExpire"

        return [DeviceCodeResult]::new($tokenResponse["access_token"].ToString(), $tokenResponse["refresh_token"].ToString(), $tokenResponse["expires_on"].ToString(), deviceCodeResult.ClientId, deviceCodeResult.Scopes)
    }

    private class TokenResponse
    {
        public string AccessToken { get; set; }
        public string RefreshToken { get; set; }
        public string ExpiresOn { get; set; }

        public override string ToString()
        {
            return [JsonConvert]::SerializeObject($this, [Formatting]::Indented)
        }
    }

    public class DeviceCodeResult
    {
        public string UserCode { get; set; }
        public string VerificationUrl { get; set; }
        public string ClientId { get; set; }
        public string[] Scopes { get; set; }

        public DeviceCodeResult(string accessToken, string refreshToken, string expiresOn, string clientId, string[] scopes)
        {
            AccessToken = accessToken;
            RefreshToken = refreshToken;
            ExpiresOn = expiresOn;
            ClientId = clientId;
            Scopes = scopes;
        }
    }
}
'@

