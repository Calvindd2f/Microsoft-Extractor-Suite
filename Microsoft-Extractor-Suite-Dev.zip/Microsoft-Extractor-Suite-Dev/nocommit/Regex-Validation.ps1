Function ValidateEmail($address)
{
     $address -match "^\\w+([-+.']\\w+)*@\\w+([-.]\\w+)*\\.\\w+([-.]\\w+)*$"
}
Function Assert-FromEmail {
    param([string]$From)

    try {
        $Mail = New-Object Net.Mail.MailAddress($From)
        if ($Mail.Host.Length -gt 0)
        {
            if (ValidateEmail($From) -eq $true)
            {
                Write-Host "Valid Email"
                return $true
            }
            else {
                Write-Warning "Email Invalid"
                return $false
            }
        }
    }
    catch {
        Write-Warning "Email Invalid"
        return $false
    }
 
}