# Issues not available so change logs here. 
- All scripts refactored to a degree. Some do not need to be included in the pull request as it is just unessessary refactoring code that already `just works`. Transport Rules is example.
- Included part of module that automatically imports all functions when .psm1 is imported. 


## Progress on improvements

- Get-ADSignInLogs - Complete.
- Get-ADAuditLogs - Complete.
- Get-RiskyUsers - Complete.
- Get-UALAll - Complete.
- Get-UALGroup - Complete.
- Get-UALSpecific - Complete.
- Get-UALSpecificActivity - Complete.
- Get-UnifiedAuditLogGraph - Complete.
- Fetch-AuditLogRecordsGraph - Complete.
- Get-Users - Complete.
- Get-AdminUsers - Complete.
- \_Get-Users - Complete.
- \_Get-AdminUsers - Complete.
- Get-Rules - Complete.

**Hard Dependencies**

- Better luck using Windows Powershell than PSCore
- `Microsoft.Graph` and `Microsoft.Graph.Beta`
- `ExchangeOnlineManagement`
- `Az`
- `PowerShellGet` & `PackageManagement` modules [this is for using `exchangepowershell` in REST API mode]

```powershell
using module Microsoft.Graph.Authentication;
#using module ExchangeOnlineManagement;
using module Az;
Get-InstalledModule PackageManagement -AllVersions; Get-InstalledModule PowerShellGet -AllVersions
install-package PackageManagement -ProviderName PowerShellGet
install-package PowerShellGet -ForceBootstrap -Force
```
