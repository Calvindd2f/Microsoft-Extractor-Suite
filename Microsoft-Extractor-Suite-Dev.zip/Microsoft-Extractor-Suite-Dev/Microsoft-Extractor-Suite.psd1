@{
RootModule = 'Microsoft-Extractor-Suite.psm1'

# Author of this module
Author = 'Joey Rentenaar & Korstiaan Stam'

# Company of this module
CompanyName = 'Invictus-IR'

# Version number of this module.
ModuleVersion = '1.3.4' 

# ID used to uniquely identify this module
GUID = '4376306b-0078-4b4d-b565-e22804e3be01'

# Copyright statement for this module
Copyright = 'Copyright (c) 2024 Invictus Incident Response'

# Description of the functionality provided by this module
Description = 'Microsoft-Extractor-Suite is a fully-featured, actively-maintained, Powershell tool designed to streamline the process of collecting all necessary data and information from various sources within Microsoft.'	

NestedModules = @('')

FunctionsToExport = @('')

# Variables to export from this module
VariablesToExport = @('')

# Cmdlets to export from this module, for best performance
CmdletsToExport = @()	

# Directory to store all the public functions
ScriptsPath = Join-Path -Path $PSScriptRoot -ChildPath 'Public'

# Directory to store all the help files
HelpPath = Join-Path -Path $PSScriptRoot -ChildPath 'Help'
}
